package cn.edu.whut.evaluate;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class Acc {
	public static float accuracy(String[][] predicted, String[][] known) {
		int max = 0;
		int sumNumi = 0;
		for (int i = 0; i < known.length; i++) {
			sumNumi += known[i].length;
		}
		int molecule = 0;
		for (int i = 0; i < known.length; i++) {
			for (int j = 0; j < predicted.length; j++) {
				List<String> l = new LinkedList<String>();
				Set<String> common = new HashSet<String>();
				for (String str : predicted[j]) {
					if (!l.contains(str)) {
						l.add(str);
					}
				}
				for (String str : known[i]) {
					if (l.contains(str)) {
						common.add(str);
					}
				}
				String[] com = new String[common.size()];
				common.toArray(com);
				if (com.length > max)
					max = com.length;
				l.clear();
				common.clear();
			}
			molecule += max;
			max = 0;
		}
		float Sn = (float) molecule / sumNumi;//以上是计算Sn的过程

		int denominator = 0;
		int max2 = 0;
		int molecule2 = 0;
		for (int i = 0; i < predicted.length; i++) {
			for (int j = 0; j < known.length; j++) {
				List<String> l = new LinkedList<String>();
				Set<String> common = new HashSet<String>();
				for (String str : predicted[i]) {
					if (!l.contains(str)) {
						l.add(str);
					}
				}
				for (String str : known[j]) {
					if (l.contains(str)) {
						common.add(str);
					}
				}
				String[] com = new String[common.size()];
				common.toArray(com);
				denominator += com.length;
				if (com.length > max2)
					max2 = com.length;
				l.clear();
				common.clear();
			}
			molecule2 += max2;
			max2 = 0;
		}
		float PPV = (float) molecule2 / denominator;//以上是计算PPV的过程

		float result = (float) Math.sqrt(Sn * PPV);

		return result;
	}
}
