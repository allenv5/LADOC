package cn.edu.whut.evaluate;

import cn.edu.whut.ladoc.SharedLibrary;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.SQLException;
import java.util.*;

/*
 * 这个是计算f-measure/Accuracy/MMR的类
 * DIP Hsapi 随机复合物的f-measure/Accuracy/MMR值
 */

public class CalcProteins {
	public static void main(String[] args) {
		String rootFolder = "data/dataset/Homo/";
		calc(rootFolder);
	}

	public static void calc(String rootFolder) {

		Set<String> usedProteins = new HashSet<>();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(rootFolder + "ppis"));
			String line;
			while ((line = br.readLine()) != null) {
				String[] vals = line.split("\t");
				usedProteins.addAll(Arrays.asList(vals));
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		String[][] known = null;
		try {
			if (rootFolder.contains("Hsapi") || rootFolder.contains("hsapi") || rootFolder.contains("Homo") || rootFolder.contains("homo")) {
				known = ReadMySQL.readmysql3();
			} else {
				known = ReadMySQL.readmysql2();
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		List<String> allProteinsList = new ArrayList<>();
		for (String[] complex : known) {
			allProteinsList.addAll(new ArrayList<>(Arrays.asList(complex)));
		}

		Set<String> allProteinsSet = new HashSet<>(allProteinsList);

		int match = 0;
		for (String proteins : allProteinsSet) {
			if (usedProteins.contains(proteins)) {
				match++;
			}
		}
		// for (String protein : usedProteins) {
		// 	if (allProteinsSet.contains(protein)) {
		// 		match++;
		// 	}
		// }

		System.out.println("使用的Proteins数量为：" + usedProteins.size());
		System.out.println("已知的Proteins数量为：" + allProteinsSet.size());
		System.out.println("匹配的Proteins数量为：" + match);
	}

	private static String[][] toMatrix(List<List<String>> array) {
		String[][] matrix = new String[array.size()][];
		for (int i = 0; i < array.size(); i++) {
			matrix[i] = new String[array.get(i).size()];
			for (int j = 0; j < array.get(i).size(); j++) {
				matrix[i][j] = array.get(i).get(j);
			}
		}
		return matrix;
	}
}
