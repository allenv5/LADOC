package cn.edu.whut.evaluate;

import cn.edu.whut.ladoc.SharedLibrary;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

/*
 * 这个是计算f-measure/Accuracy/MMR的类
 */

public class FMeasureMatch {
	public static void main(String[] args) {
		// String filePath = "D:\\Users\\VertexZzz\\Desktop\\git\\github\\PC2P\\ClusterResult\\";
		// String filePath = "D:\\Users\\VertexZzz\\Desktop\\process\\Collins\\";
		String filePath = "D:\\Users\\VertexZzz\\Desktop\\datasets\\Homo\\";
		// String filePath = "D:\\OneDrive\\Synchronization\\Resources\\研究生文件\\论文\\小论文-聚类\\论文实验结果\\results\\Collins\\";
		// String filePath = "data/dataset/DIP-Hsapi/";
		String fileName = "PEWCC";
		calc(filePath, fileName);

		// ClusterONE  CorePeel  EGCPI  GMFTP  PEWCC PC2P
	}

	public static String calc(String filePath, String fileName) {
		// gavin
		String[][] Gavinoutput = ReadFile.createArray(filePath + fileName);
		int proteinsNum = getProteinsNum(Gavinoutput);
		int proteinsNum2 = ReadFile.getProteinsNum(filePath + fileName);
		String clusterInfo = "Found " + Gavinoutput.length + " clusters, a total of " + proteinsNum + " proteins";
		System.out.println(clusterInfo);

		String[][] known = null;
		try {
			// known = ReadMySQL.readmysql3();
			if (filePath.contains("Hsapi") || fileName.equals("Hsapi") || filePath.contains("Homo") || filePath.contains("homo")) {
				known = ReadMySQL.readmysql3();
			} else {
				known = ReadMySQL.readmysql2();
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Map<String, Float> f_measure = fmeasure(Gavinoutput, known, true);
		String fMeasureCalcInfo = new ArrayList<>(f_measure.keySet()).get(0);
		float f_measure_co2 = SharedLibrary.roundWithTowDecimalPlaces(f_measure.get(fMeasureCalcInfo));
		// float f_measure_co2 = SharedLibrary.roundWithTowDecimalPlaces(fmeasure(Gavinoutput, known));
		float ACC_co2 = SharedLibrary.roundWithTowDecimalPlaces(Acc.accuracy(Gavinoutput, known));
		float mmr2 = SharedLibrary.roundWithTowDecimalPlaces(MMR.calculate(Gavinoutput, known));
		String f1Info = "f-measure：" + f_measure_co2;
		String accInfo = "   GeoAcc：" + ACC_co2;
		String mmrInfo = "      MMR：" + mmr2;

		System.out.println(f1Info);
		System.out.println(accInfo);
		System.out.println(mmrInfo);
		StringBuffer sb = new StringBuffer();
		sb.append(clusterInfo).append("\n").append(fMeasureCalcInfo).append("\n").append(f1Info).append("\n").append(accInfo).append("\n").append(mmrInfo).append("\n");
		return sb.toString();
	}

	public static String calc(String filePath, String fileName, int groundTruthSize) {
		// gavin
		String[][] Gavinoutput = ReadFile.createArray(filePath + fileName);
		int proteinsNum = getProteinsNum(Gavinoutput);
		int proteinsNum2 = ReadFile.getProteinsNum(filePath + fileName);
		String clusterInfo = "Found " + Gavinoutput.length + " clusters, a total of " + proteinsNum + " proteins";
		System.out.println(clusterInfo);

		String[][] known = null;
		try {
			// known = ReadMySQL.readmysql3();
			if (filePath.contains("Hsapi") || fileName.equals("Hsapi") || filePath.contains("Homo") || filePath.contains("homo")) {
				known = ReadMySQL.readmysql3();
			} else {
				known = ReadMySQL.readmysql2();
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		known = getNewKnownMatrix(known, groundTruthSize);
		System.out.println(known.length);

		float f_measure_co2 = SharedLibrary.roundWithTowDecimalPlaces(fmeasure(Gavinoutput, known));
		float ACC_co2 = SharedLibrary.roundWithTowDecimalPlaces(Acc.accuracy(Gavinoutput, known));
		float mmr2 = SharedLibrary.roundWithTowDecimalPlaces(MMR.calculate(Gavinoutput, known));
		String f1Info = "f-measure：" + f_measure_co2;
		String accInfo = "   GeoAcc：" + ACC_co2;
		String mmrInfo = "      MMR：" + mmr2;

		System.out.println(f1Info);
		System.out.println(accInfo);
		System.out.println(mmrInfo);
		StringBuffer sb = new StringBuffer();
		sb.append(clusterInfo).append("\n").append(f1Info).append("\n").append(accInfo).append("\n").append(mmrInfo).append("\n");
		return sb.toString();
	}

	private static String[][] getNewKnownMatrix(String[][] known, int groundTruthSIze) {
		List<List<String>> knownList = new ArrayList<>();
		for (String[] knownVertex : known) {
			if (knownVertex.length == groundTruthSIze) {
				knownList.add(Arrays.asList(knownVertex));
			}
		}

		return toMatrix(knownList);
	}

	private static int getProteinsNum(String[][] input) {
		Set<String> allProteins = new HashSet<>();
		for (int i = 0; i < input.length; i++) {
			allProteins.addAll(Arrays.asList(input[i]));
		}
		return allProteins.size();
	}

	private static void save(String membershipMatrix[][], String outputFile) {
		// TODO Auto-generated method stub
		String content = "";

		for (int i = 0; i < membershipMatrix.length; i++) {
			content += content.length() == 0 ? "" : "\n";

			for (int j = 0; j < membershipMatrix[i].length; j++) {
				content += (j == 0 ? "" : "\t") + membershipMatrix[i][j];
			}
		}

		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter(outputFile));
			bw.write(content);
			bw.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block

		} finally {
			if (bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block

				}
			}
		}
	}

	private static Map<String, Float> fmeasure(String[][] predicted, String[][] known, boolean returnINFO) {
		Map<String, Float> f1Info = new HashMap<>();
		StringBuffer sb = new StringBuffer();
		String precisionInfo = "";
		String recallInfo = "";
		float result = 0;
		Set<Integer> Ncp = new HashSet<Integer>();
		Set<Integer> Ncg = new HashSet<Integer>();

		int Ncpi = 0, Ncgi = 0;
		// for(int i =0)匹配度超过0.2 两个复合物的交集除于他们各自复合物的蛋白质数目加起来。
		for (int i = 0; i < predicted.length; i++) {

			for (int j = 0; j < known.length; j++) {

				List<String> l = new LinkedList<String>();
				Set<String> common = new HashSet<String>();
				for (String str : predicted[i]) {
					if (!l.contains(str)) {
						l.add(str);
					}
				}
				for (String str : known[j]) {
					if (l.contains(str)) {
						common.add(str);
					}
				}
				String[] com = new String[common.size()];
				common.toArray(com);
				if ((float)((com.length * com.length) / (predicted[i].length) * (known[j].length)) >= 0.3) {
					Ncp.add(i);
					Ncg.add(j);
					// Ncp[Ncpi] = i;
					// Ncg[Ncgi] = j;
					// Ncpi++;
					// Ncgi++;
				}
				l.clear();
				common.clear();
			}
		}

		if (Ncp.size() == 0) {
			result = 0;
		} else {
			float precision = (float) Ncp.size() / predicted.length;
			float recall = (float) Ncg.size() / known.length;
			result = 2 * precision * recall / (precision + recall);
			precisionInfo = "precision：" + SharedLibrary.roundWithTowDecimalPlaces(precision);
			recallInfo = "   recall：" + SharedLibrary.roundWithTowDecimalPlaces(recall);
			System.out.println(precisionInfo);
			System.out.println(recallInfo);
		}

		sb.append(precisionInfo).append("\n").append(recallInfo);
		f1Info.put(sb.toString(), result);
		return f1Info;
	}

	private static float fmeasure(String[][] predicted, String[][] known) {
		float result = 0;
		Set<Integer> Ncp = new HashSet<Integer>();
		Set<Integer> Ncg = new HashSet<Integer>();

		int Ncpi = 0, Ncgi = 0;
		// for(int i =0)匹配度超过0.2 两个复合物的交集除于他们各自复合物的蛋白质数目加起来。
		for (int i = 0; i < predicted.length; i++) {

			for (int j = 0; j < known.length; j++) {

				List<String> l = new LinkedList<String>();
				Set<String> common = new HashSet<String>();
				for (String str : predicted[i]) {
					if (!l.contains(str)) {
						l.add(str);
					}
				}
				for (String str : known[j]) {
					if (l.contains(str)) {
						common.add(str);
					}
				}
				String[] com = new String[common.size()];
				common.toArray(com);
				if ((float)((com.length * com.length) / (predicted[i].length) * (known[j].length)) >= 0.3) {
					Ncp.add(i);
					Ncg.add(j);
					// Ncp[Ncpi] = i;
					// Ncg[Ncgi] = j;
					// Ncpi++;
					// Ncgi++;
				}
				l.clear();
				common.clear();
			}
		}

		if (Ncp.size() == 0) {
			result = 0;
		} else {
			float precision = (float) Ncp.size() / predicted.length;
			float recall = (float) Ncg.size() / known.length;
			result = 2 * precision * recall / (precision + recall);
			System.out.println("precision：" + SharedLibrary.roundWithTowDecimalPlaces(precision));
			System.out.println("   recall：" + SharedLibrary.roundWithTowDecimalPlaces(recall));
		}
		return result;
	}

	private static String[][] toMatrix(List<List<String>> array) {
		String[][] matrix = new String[array.size()][];
		for (int i = 0; i < array.size(); i++) {
			matrix[i] = new String[array.get(i).size()];
			for (int j = 0; j < array.get(i).size(); j++) {
				matrix[i][j] = array.get(i).get(j);
			}
		}
		return matrix;
	}
}
