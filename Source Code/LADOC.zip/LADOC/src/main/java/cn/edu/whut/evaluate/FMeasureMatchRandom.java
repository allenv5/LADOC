package cn.edu.whut.evaluate;

import cn.edu.whut.ladoc.SharedLibrary;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

/*
 * 这个是计算f-measure/Accuracy/MMR的类
 * DIP Hsapi 随机复合物的f-measure/Accuracy/MMR值
 */

public class FMeasureMatchRandom {
	public static void main(String[] args) {
		for (int i = 1; i <= 10; i++) {
			System.out.println("第" + i + "次计算...");
			calc();
		}
	}

	public static void calc() {

		String[][] known = null;
		try {
			// known = ReadMySQL.readmysql3();
			known = ReadMySQL.readmysql3();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		List<String> allHumanProteins = new ArrayList<>();
		for (String[] complex : known) {
			allHumanProteins.addAll(new ArrayList<>(Arrays.asList(complex)));
		}
		List<String> copyList = new ArrayList<>(allHumanProteins);
		// Collections.shuffle(allHumanProteins);
		List<String> shuffledList = shuffle(allHumanProteins);
		Queue<String> queue = new LinkedList<>(shuffledList);
		List<List<String>> randomComplexes = new ArrayList<>();

		for (String[] complex : known) {
			int size = complex.length;
			List<String> randomComplex = new ArrayList<>();
			for (int i = 0; i < size; i++) {
				randomComplex.add(queue.poll());
			}
			randomComplexes.add(randomComplex);
		}

		String[][] Gavinoutput = toMatrix(randomComplexes);

		float f_measure_co2 = SharedLibrary.roundWithTowDecimalPlaces(fmeasure(Gavinoutput, known));
		float ACC_co2 = SharedLibrary.roundWithTowDecimalPlaces(Acc.accuracy(Gavinoutput, known));
		float mmr2 = SharedLibrary.roundWithTowDecimalPlaces(MMR.calculate(Gavinoutput, known));
		String f1Info = "f-measure：" + f_measure_co2;
		String accInfo = "   GeoAcc：" + ACC_co2;
		String mmrInfo = "      MMR：" + mmr2;

		System.out.println(f1Info);
		System.out.println(accInfo);
		System.out.println(mmrInfo);
		// StringBuffer sb = new StringBuffer();
		// sb.append(fMeasureCalcInfo).append("\n").append(f1Info).append("\n").append(accInfo).append("\n").append(mmrInfo).append("\n");
		// return sb.toString();
		System.out.println();
	}

	private static List<String> shuffle(List<String> list) {
		Random random = new Random();
		List<String> copyList = new ArrayList<>(list);
		String[] shuffledNums = new String[list.size()];
		int x, j = 0;
		for (int i = copyList.size() - 1; i >= 0; i = copyList.size() - 1) {
			x = random.nextInt(i + 1);
			shuffledNums[j++] = copyList.get(x);
			copyList.remove(x);
		}
		return new ArrayList<>(Arrays.asList(shuffledNums));
	}

	private static float fmeasure(String[][] predicted, String[][] known) {
		float result = 0;
		Set<Integer> Ncp = new HashSet<Integer>();
		Set<Integer> Ncg = new HashSet<Integer>();

		int Ncpi = 0, Ncgi = 0;
		// for(int i =0)匹配度超过0.2 两个复合物的交集除于他们各自复合物的蛋白质数目加起来。
		for (int i = 0; i < predicted.length; i++) {

			for (int j = 0; j < known.length; j++) {

				List<String> l = new LinkedList<String>();
				Set<String> common = new HashSet<String>();
				for (String str : predicted[i]) {
					if (!l.contains(str)) {
						l.add(str);
					}
				}
				for (String str : known[j]) {
					if (l.contains(str)) {
						common.add(str);
					}
				}
				String[] com = new String[common.size()];
				common.toArray(com);
				if ((float)((com.length * com.length) / (predicted[i].length) * (known[j].length)) >= 0.3) {
					Ncp.add(i);
					Ncg.add(j);
					// Ncp[Ncpi] = i;
					// Ncg[Ncgi] = j;
					// Ncpi++;
					// Ncgi++;
				}
				l.clear();
				common.clear();
			}
		}

		if (Ncp.size() == 0) {
			result = 0;
		} else {
			float precision = (float) Ncp.size() / predicted.length;
			float recall = (float) Ncg.size() / known.length;
			result = 2 * precision * recall / (precision + recall);
			System.out.println("precision：" + SharedLibrary.roundWithTowDecimalPlaces(precision));
			System.out.println("   recall：" + SharedLibrary.roundWithTowDecimalPlaces(recall));
		}
		return result;
	}

	private static String[][] toMatrix(List<List<String>> array) {
		String[][] matrix = new String[array.size()][];
		for (int i = 0; i < array.size(); i++) {
			matrix[i] = new String[array.get(i).size()];
			for (int j = 0; j < array.get(i).size(); j++) {
				matrix[i][j] = array.get(i).get(j);
			}
		}
		return matrix;
	}
}
