package cn.edu.whut.evaluate;

import java.util.*;

public class MMR {
	public static float calculate(String[][] predicted, String[][] known) {
//		double result=0;
//		Integer[][] Tij = Tij(predicted,known);
//		for(int i =0 ;i < predicted.length ; i++)
//		{
//			for(int j =0 ; j < known.length; j++) {
////				if(Sepij(i,j,Tij)>0)
////					System.out.println("asdfsadf");
//				result+=Sepij(i,j,Tij);
//				
//			}
//		}
//		
//		result =Math.sqrt((double)(result/predicted.length)*(double)(result/known.length));
		float[][] mrMatrix = getMatchingRateMatrix(predicted, known);
		float result = getMMRSum(mrMatrix) / known.length;

		return result;
	}

	public static double Sepij(int i, int j, Integer[][] Tij) {
		int thegemai = 0, thegemaj = 0;
		for (int a = 0; a < Tij[0].length; a++) {
			thegemai += Tij[i][a];
		}
		for (int b = 0; b < Tij.length; b++) {
			thegemaj += Tij[b][j];
		}
		if (Tij[i][j].equals(0))
			return 0;
		else
			return ((double) Tij[i][j] / thegemai) * ((double) Tij[i][j] / thegemaj);

	}

	private static float getMMRSum(float[][] mrMatrix) {
		// TODO Auto-generated method stub
		float mmrSum = 0;
		boolean[] markedRowArray = new boolean[mrMatrix.length];
		boolean[] markedColArray = new boolean[mrMatrix[0].length];

		while (true) {
			int maxRowIdx = 0, maxColIdx = 0;
			float mmr = 0;

			for (int i = 0; i < mrMatrix.length; i++) {
				if (markedRowArray[i])
					continue;

				for (int j = 0; j < mrMatrix[i].length; j++) {
					if (markedColArray[j])
						continue;

					if (mrMatrix[i][j] > mmr) {
						mmr = mrMatrix[i][j];
						maxRowIdx = i;
						maxColIdx = j;
					}
				}
			}

			if (mmr == 0) {
				break;
			} else {
				mmrSum += mmr;
				markedColArray[maxColIdx] = true;
				markedRowArray[maxRowIdx] = true;
			}
		}

		return mmrSum;
	}

	private static float[][] getMatchingRateMatrix(String[][] identifiedPCList, String[][] known) {
		// TODO Auto-generated method stub
		float[][] mrMatrix = new float[known.length][];
		int rowIdx = 0;
		for (int i = 0; i < known.length; i++) {
			float[] mmrArray = new float[identifiedPCList.length];
			int colIdx = 0;
			for (int j = 0; j < identifiedPCList.length; j++) {
				int overlappingProteins = getOverlappingProteins(known[i], identifiedPCList[j]);
				mmrArray[colIdx++] = getMatchingRate(identifiedPCList[j].length, known[i].length, overlappingProteins);
			}
			mrMatrix[rowIdx++] = mmrArray;
		}

		return mrMatrix;
	}

	private static float getMatchingRate(int size, int size2, int overlappingProteins) {
		// TODO Auto-generated method stub
//		int totalProteins = size + size2 - overlappingProteins;
//		float mr = overlappingProteins / (float) totalProteins;

		float mr = overlappingProteins * overlappingProteins / (float) (size * size2);
		return mr;
	}

	private static int getOverlappingProteins(String[] benchmarkProteinComplex,
											  String[] identifiedProteinComplex) {
		// TODO Auto-generated method stub
		int num = 0;

		for (int i = 0; i < identifiedProteinComplex.length; i++) {
			if (Arrays.asList(benchmarkProteinComplex).contains(identifiedProteinComplex[i]))
				num++;
		}
		return num;
	}

	public static Integer[][] Tij(String[][] predicted, String[][] known) {

		Integer[][] Tij = new Integer[predicted.length][known.length];
		for (int i = 0; i < predicted.length; i++) {

			for (int j = 0; j < known.length; j++) {

				List<String> l = new LinkedList<String>();
				Set<String> common = new HashSet<String>();
				for (String str : predicted[i]) {
					if (!l.contains(str)) {
						l.add(str);
					}
				}
				for (String str : known[j]) {
					if (l.contains(str)) {
						common.add(str);
					}
				}

				Tij[i][j] = common.size();
//			     if(Tij[i][j]!=0)
//			    	 System.out.println("tij:"+Tij[i][j]+"i:"+i+"j:"+j);
				l.clear();
				common.clear();
			}
		}

		return Tij;


	}
}
