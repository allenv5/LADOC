package cn.edu.whut.evaluate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Merge {
	public static String[][] calculate(String[][] mark, String[][] second, String[][] third) {
		List<String[]> list = new ArrayList<String[]>();
		for (int i = 0; i < mark.length; i++) {
			list.add(mark[i]);
		}
		for (int i = 0; i < second.length; i++) {
			boolean isExist = false;
			for (int j = 0; j < mark.length; j++) {
				if (mark[j].length == second[i].length) {
					for (int k = 0; k < mark[j].length; k++) {
						if (Arrays.asList(mark[j]).indexOf(second[i][k]) == -1) {
							break;
						} else if (k == mark[j].length - 1) {
							isExist = true;
						}
					}
				}
			}
			if (!isExist) {
				list.add(second[i]);
			}
		}
		for (int i = 0; i < third.length; i++) {
			boolean isExist = false;
			for (int j = 0; j < mark.length; j++) {
				if (mark[j].length == third[i].length) {
					for (int k = 0; k < mark[j].length; k++) {
						if (Arrays.asList(mark[j]).indexOf(third[i][k]) == -1) {
							break;
						} else if (k == mark[j].length - 1) {
							isExist = true;
						}
					}
				}
			}
			if (!isExist) {
				list.add(third[i]);
			}
		}
		//ArrayList<String> list=new ArrayList<String>();

		String[][] result = new String[list.size()][];
		list.toArray(result);
		return result;
	}

	public static String[][] linklimit(String[][] mark) {
		int length = mark.length;
		for (int i = 0; i < mark.length; i++) {
			if (mark[i].length < 2)
				length--;
		}
		int index = 0;
		String[][] result = new String[length][];
		for (int i = 0; i < mark.length; i++) {
			if (mark[i].length >= 2) {
				result[index] = mark[i];
				index++;
			}
		}
		return result;
	}

	public static String[][] trilimit(String[][] mark) {
		int length = mark.length;
		for (int i = 0; i < mark.length; i++) {
			if (mark[i].length < 3)
				length--;
		}
		int index = 0;
		String[][] result = new String[length][];
		for (int i = 0; i < mark.length; i++) {
			if (mark[i].length >= 3) {
				result[index] = mark[i];
				index++;
			}
		}
		return result;
	}

	public static String[][] rectlimit(String[][] mark) {
		int length = mark.length;
		for (int i = 0; i < mark.length; i++) {
			if (mark[i].length < 4)
				length--;
		}
		int index = 0;
		String[][] result = new String[length][];
		for (int i = 0; i < mark.length; i++) {
			if (mark[i].length >= 4) {
				result[index] = mark[i];
				index++;
			}
		}
		return result;
	}
}
