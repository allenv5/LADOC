package cn.edu.whut.evaluate;


import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class PPIClusteringPerformanceMMR {
	//public static Logger logger = Logger.getLogger(PPIClusteringPerformanceMMR.class);

	private float mmr;
	private boolean isSC;
	private Set<Set<String>> identifiedProteinComplexSet;
	private Set<Set<String>> geneProteinComplexSet;

	public PPIClusteringPerformanceMMR(boolean isSC, Set<Set<String>> identifiedProteinComplexSet) {
		this.isSC = isSC;
		this.identifiedProteinComplexSet = identifiedProteinComplexSet;
	}

	public void run() {
		// this.setGeneProteinComplexSet();
		this.computeMMR();

//		logger.debug("MMR:\t" + this.mmr);
	}

	private void computeMMR() {
		// TODO Auto-generated method stub
		List<Set<String>> identifiedPCList = new ArrayList<Set<String>>();
		for (Set<String> set : this.identifiedProteinComplexSet)
			identifiedPCList.add(set);

		float[][] mrMatrix = getMatchingRateMatrix(identifiedPCList);

		float mmrSum = getMMRSum(mrMatrix);

		this.mmr = mmrSum / this.geneProteinComplexSet.size();
	}

	private float getMMRSum(float[][] mrMatrix) {
		// TODO Auto-generated method stub
		float mmrSum = 0;
		boolean[] markedRowArray = new boolean[mrMatrix.length];
		boolean[] markedColArray = new boolean[mrMatrix[0].length];

		while (true) {
			int maxRowIdx = 0, maxColIdx = 0;
			float mmr = 0;

			for (int i = 0; i < mrMatrix.length; i++) {
				if (markedRowArray[i])
					continue;

				for (int j = 0; j < mrMatrix[i].length; j++) {
					if (markedColArray[j])
						continue;

					if (mrMatrix[i][j] > mmr) {
						mmr = mrMatrix[i][j];
						maxRowIdx = i;
						maxColIdx = j;
					}
				}
			}

			if (mmr == 0) {
				break;
			} else {
				mmrSum += mmr;
				markedColArray[maxColIdx] = true;
				markedRowArray[maxRowIdx] = true;
			}
		}

		return mmrSum;
	}

	private float[][] getMatchingRateMatrix(List<Set<String>> identifiedPCList) {
		// TODO Auto-generated method stub
		float[][] mrMatrix = new float[this.geneProteinComplexSet.size()][];
		int rowIdx = 0;

		for (Set<String> benchmarkProteinComplex : this.geneProteinComplexSet) {
			float[] mmrArray = new float[identifiedPCList.size()];
			int colIdx = 0;

			for (Set<String> identifiedProteinComplex : identifiedPCList) {
				int overlappingProteins = getOverlappingProteins(benchmarkProteinComplex, identifiedProteinComplex);
				mmrArray[colIdx++] = getMatchingRate(identifiedProteinComplex.size(), benchmarkProteinComplex.size(), overlappingProteins);
			}

			mrMatrix[rowIdx++] = mmrArray;
		}

		return mrMatrix;
	}

	private float getMatchingRate(int size, int size2, int overlappingProteins) {
		// TODO Auto-generated method stub
//		int totalProteins = size + size2 - overlappingProteins;
//		float mr = overlappingProteins / (float) totalProteins;

		float mr = overlappingProteins * overlappingProteins / (float) (size * size2);
		return mr;
	}

	private int getOverlappingProteins(Set<String> benchmarkProteinComplex,
									   Set<String> identifiedProteinComplex) {
		// TODO Auto-generated method stub
		int num = 0;

		for (String protein : identifiedProteinComplex) {
			if (benchmarkProteinComplex.contains(protein))
				num++;
		}

		return num;
	}

	/*
	private void setGeneProteinComplexSet() {
		this.geneProteinComplexSet = new HashSet<Set<String>>();

		Session session = null;
		Map<String, String> idMapping = new HashMap<String, String>();

		try {
			SessionFactory sessionFactory =
					new AnnotationConfiguration().configure().buildSessionFactory();
			session = sessionFactory.openSession();

			StringBuffer stringBuffer = new StringBuffer();
			String sql = ProteinComplexSelectionSQL.getSQL(this.isSC, false);
			Query query = session.createQuery(sql);

			for (Iterator iterator = query.iterate(); iterator.hasNext(); ) {
				String subunits = (String) iterator.next();
				String[] uniproIds = subunits.split(",");

				// set gene protein complex
				Set<String> geneIdSet = new HashSet<String>();

				boolean allMapped = true;
				for (String uniproId : uniproIds) {
					if (!idMapping.containsKey(uniproId)) {
						String sql1 = "select mapped_id from IdMapping where uniprot_id = ?";
						Query query1 = session.createQuery(sql1);
						query1.setParameter(0, uniproId);

						try {
							String geneId = (String) query1.iterate().next();
							idMapping.put(uniproId, geneId);
						} catch (Exception e) {
							//Logger.getLogger(getClass()).error(e.getMessage());
							stringBuffer.append(uniproId + ",");
							allMapped = false;
							break;
						}
					}

					geneIdSet.add(idMapping.get(uniproId));
				}

				if (geneIdSet.size() == 0) {
					//Logger.getLogger(getClass()).error("No Mapped Gene Id Found: " + subunits);
				} else {
					if (allMapped) {
						this.geneProteinComplexSet.add(geneIdSet);
					}
				}
			}

			String notMappedUniprotIds = stringBuffer.toString();
			if (notMappedUniprotIds.length() > 0) {


				//Logger.getLogger(getClass()).error("Not Mapped Uniprot Ids: " 
				//+ notMappedUniprotIds.substring(0, notMappedUniprotIds.length() - 1));
			}
		} catch (Exception e) {
			//Logger.getLogger(getClass()).error(e.getMessage());
		}

		//Logger.getLogger(getClass()).debug("Entrez Gene Protein Complex Size: " + this.geneProteinComplexSet.size());		
	}

	 */
	public float getMMR() {
		return this.mmr;
	}
}

