package cn.edu.whut.evaluate;

import java.io.*;
import java.sql.*;
import java.util.*;

public class ReadFile {
	public static List readTxtFile(String filePath) {
		List<String> list = new ArrayList<String>();
		try {
			String encoding = "UTF-8";
			File file = new File(filePath);
			if (file.isFile() && file.exists()) {
				InputStreamReader read = new InputStreamReader(new FileInputStream(file), encoding);
				BufferedReader bufferedReader = new BufferedReader(read);
				String lineTxt = null;
				while ((lineTxt = bufferedReader.readLine()) != null) {
					if (!lineTxt.startsWith("Cluster") && Arrays.asList(lineTxt.split("\t")).size() >= 3) {
						list.add(lineTxt);
					}
				}
				read.close();
			} else {
				System.out.println("找不到文件");
				System.exit(1);
			}
		} catch (Exception e) {
			System.out.println("出错了");
			e.printStackTrace();
		}
		return list;
	}

	public static int getProteinsNum(String fileName) {
		Set<String> set = new HashSet<>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(fileName));
			String line;
			while ((line = br.readLine()) != null) {
				if (!line.startsWith("Cluster")) {
					String[] items = line.split("\t");
					if (items.length > 2) set.addAll(Arrays.asList(items));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return set.size();
	}

	public static String[][] createArrayMCODE(String filePath) {
		List<String> list = readTxtFile(filePath);
		String array[][] = new String[list.size() - 10][];
		for (int i = 10; i < list.size(); i++) {

			String linetxt = list.get(i);
			String[] myArray =
					linetxt.replaceAll("\t", "@").split("@")[4].replaceAll(", ", "#").split("#");
			array[i - 10] = new String[myArray.length];
			for (int j = 0; j < myArray.length; j++) {
				array[i - 10][j] = myArray[j];
			}
		}
		return array;
	}

	public static String[][] createArrayMCODE2(String filePath)
			throws ClassNotFoundException, SQLException {
		List<String> list = readTxtFile(filePath);
		String array[][] = new String[list.size() - 10][];
		for (int i = 10; i < list.size(); i++) {

			String linetxt = list.get(i);
			String[] myArray =
					linetxt.replaceAll("\t", "@").split("@")[4].replaceAll(", ", "#").split("#");
			array[i - 10] = new String[myArray.length];
			for (int j = 0; j < myArray.length; j++) {
				array[i - 10][j] = myArray[j];
			}
		}

		String driverName = "com.mysql.cj.jdbc.Driver";
		String url1 = "jdbc:mysql://localhost:3307/biodata";
		String url2 = "?user=root&password=admin";
		String url3 = "&useUnicode=true&characterEncoding=UTF-8";
		String url = url1 + url2 + url3 + "&serverTimezone=UTC";

		Class.forName(driverName);

		Connection conn = DriverManager.getConnection(url);

		String sql = "SELECT gene_id FROM biodata.id_mapping where uniprotkb_ac =? ;";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		for (int x = 0; x < array.length; x++) {
			for (int y = 0; y < array[x].length; y++) {
				pstmt.setString(1, array[x][y]);

				ResultSet rs = pstmt.executeQuery();

				rs.beforeFirst();

				while (rs.next()) {
					if (rs.getString(1).equals("")) {

					} else {
						// System.out.println(rs.getString(1));
						array[x][y] = rs.getString(1).split(";")[0];
					}
				}
				rs.beforeFirst();
				rs.close();
			}
		}

		return array;
	}

	public static String[][] createArray(String filePath) {
		List<String> list = readTxtFile(filePath);
		String array[][] = new String[list.size()][];
		for (int i = 0; i < list.size(); i++) {
			// if (list.size() < 2) continue;
			String linetxt = list.get(i);
			String[] myArray = linetxt.replaceAll("\\s+", "@").split("@");
			array[i] = new String[myArray.length];
			for (int j = 0; j < myArray.length; j++) {
				array[i][j] = myArray[j];
			}
		}
		return array;
	}

	public static String[][] createArray2(String filePath)
			throws ClassNotFoundException, SQLException {
		List<String> list = readTxtFile(filePath);
		String array[][] = new String[list.size()][];
		for (int i = 0; i < list.size(); i++) {

			String linetxt = list.get(i);
			String[] myArray = linetxt.replaceAll("\\s+", "@").split("@");
			array[i] = new String[myArray.length];
			for (int j = 0; j < myArray.length; j++) {
				array[i][j] = myArray[j];
			}
		}

		String driverName = "com.mysql.cj.jdbc.Driver";
		String url1 = "jdbc:mysql://localhost:3307/biodata";
		String url2 = "?user=root&password=admin";
		String url3 = "&useUnicode=true&characterEncoding=UTF-8";
		String url = url1 + url2 + url3 + "&serverTimezone=UTC";

		Class.forName(driverName);

		Connection conn = DriverManager.getConnection(url);

		String sql = "SELECT gene_id FROM biodata.id_mapping where uniprotkb_ac =? ;";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		for (int x = 0; x < array.length; x++) {
			for (int y = 0; y < array[x].length; y++) {
				pstmt.setString(1, array[x][y]);

				ResultSet rs = pstmt.executeQuery();

				rs.beforeFirst();

				while (rs.next()) {
					if (rs.getString(1).equals("")) {

					} else {
						// System.out.println(rs.getString(1));
						array[x][y] = rs.getString(1).split(";")[0];
					}
				}
				rs.beforeFirst();
				rs.close();
			}
		}

		return array;
	}
}
