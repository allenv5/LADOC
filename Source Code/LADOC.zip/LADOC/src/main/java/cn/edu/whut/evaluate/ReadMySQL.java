package cn.edu.whut.evaluate;

import java.sql.*;


public class ReadMySQL {
	private static final String DBDRIVER = "com.mysql.jdbc.Driver";
	private static final String DBURL = "jdbc:mysql://localhost:3307/biodata?useSSL=false";
	private static final String DBUSER = "root";
	private static final String DBPASSWORD = "admin";


	public static String[][] readmysql() throws ClassNotFoundException, SQLException {
		// String driverName = "com.mysql.jdbc.Driver";
		// String url1 = "jdbc:mysql://localhost:3306/biodata";
		// String url2 = "?user=root&password=admin";
		// String url3 = "&useUnicode=true&characterEncoding=UTF-8&useSSL=false";
		// String url = url1 + url2 + url3 + "&serverTimezone=UTC";
		Class.forName(DBDRIVER);
		Connection conn = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD);

		Statement stmt = conn.createStatement();

		String sql = "SELECT `subunits(entrez_ids)` FROM biodata.protein_complex";
		ResultSet rs = stmt.executeQuery(sql);
		int lengthtemp = 0;
		while (rs.next()) {

			lengthtemp++;
		}
		String array[] = new String[lengthtemp];
		int i = 0;
		rs.beforeFirst();
		while (rs.next()) {

			array[i] = rs.getString(1);
			i++;
		}


		String result[][] = new String[array.length][];
		for (int j = 0; j < array.length; j++) {
			String[] myArray = array[j].split(";");
			result[j] = new String[myArray.length];
			for (int k = 0; k < myArray.length; k++) {
				result[j][k] = myArray[k];
			}
		}
		return result;
	}


	public static String[][] readmysql2() throws ClassNotFoundException, SQLException {
		Class.forName(DBDRIVER);
		Connection conn = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD);

		Statement stmt = conn.createStatement();

		String sql = "SELECT GROUP_CONCAT(`ORF`) as complex FROM biodata.CYC2008_complex group by Complex";
		ResultSet rs = stmt.executeQuery(sql);
		int lengthtemp = 0;
		while (rs.next()) {
			lengthtemp++;
		}
		String array[] = new String[lengthtemp];
		int i = 0;
		rs.beforeFirst();
		while (rs.next()) {
			array[i] = rs.getString(1);
			i++;
		}
		rs.close();
		stmt.close();
		conn.close();


		String result[][] = new String[array.length][];
		for (int j = 0; j < array.length; j++) {
			String[] myArray = array[j].split(",");
			result[j] = new String[myArray.length];
			for (int k = 0; k < myArray.length; k++) {
				result[j][k] = myArray[k];
			}
		}
		// result 是 gene name;
		Class.forName(DBDRIVER);
		Connection conn2 = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD);

		String sql2 = "SELECT uniprotkb_ac FROM biodata.name_mapping where gene_name =? and typeof_gene_name = 'OrderedLocusNames';";
		PreparedStatement pstmt2 = conn2.prepareStatement(sql2);
		for (int x = 0; x < result.length; x++) {
			for (int y = 0; y < result[x].length; y++) {
				pstmt2.setString(1, result[x][y]);
				ResultSet rs2 = pstmt2.executeQuery();
				while (rs2.next()) {
					// System.out.println(rs2.getString(1));
					result[x][y] = rs2.getString(1);
				}
				rs2.beforeFirst();
				rs2.close();
			}
		}
		pstmt2.close();
		conn2.close();
		//String sql2="SELECT uniprotkb_ac,gene_name FROM biodata.name_mapping";
//		ResultSet rs2 = stmt2.executeQuery(sql2);
////		int lengthtemp2 = 0;
////		while(rs2.next()) {
////			
////			lengthtemp2++;
////		}
//		//String array2[][] = new String[2][];
//		//List<Map<String, Object>> nametoac = new ArrayList<Map<String, Object>>();
//		//int q=0;
//		String name = new String();
//		String ac = new String();
//		Map<String, Object> nametoac = new HashMap<String, Object>();
//		rs2.beforeFirst();
//		while(rs2.next()) {
//			
//			ac =rs2.getString("uniprotkb_ac");
//			name =rs2.getString("gene_name");
//			nametoac.put(name, ac);
//			//nametoac.add(nametoac);
//		}
//		rs2.close();
//		stmt2.close();
//		conn2.close(); 
//		 for(int x=0; x<result.length; x++) {
//	          for(int y=0; y<result[x].length; y++) {
//	                
//	              result[x][y]=nametoac.get(result[x][y]).toString();
//	                
//	          }     
//	      }
//		
		//result 是uniprotkb_ac

//			
//			Class.forName(driverName);
//			
//			Connection conn3=DriverManager.getConnection(url);
//			Statement stmt3 =conn3.createStatement();
//		
//			String sql3="SELECT uniprotkb_ac,gene_id FROM biodata.id_mapping";
//			ResultSet rs3 = stmt2.executeQuery(sql3);
////			int lengthtemp2 = 0;
////			while(rs2.next()) {
////				
////				lengthtemp2++;
////			}
//			String array3[][] = new String[2][];
//			int p=0;
//			rs3.beforeFirst();
//			while(rs3.next()) {
//				
//				array3[1][q] =rs3.getString("uniprotkb_ac");
//				array3[2][q] =rs3.getString("gene_id");
//				p++;
//			}
//			 for(int x=0; x<result.length; x++) {
//		            for(int y=0; y<result[x].length; y++) {
//		                for(int z=0; z<array3[1].length;z++) {
//		                	if(result[x][y].equals(array3[1][z])) {
//		                		result[x][y]=array3[2][z];
//		                	}
//		                }
//		            }     
//		      }
//			 rs3.close();
//				stmt3.close();
//				conn3.close(); 
//		
		Class.forName(DBDRIVER);
		Connection conn3 = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD);

		String sql3 = "SELECT gene_id FROM biodata.id_mapping where uniprotkb_ac = ?;";
		PreparedStatement pstmt3 = conn3.prepareStatement(sql3);
		for (int x = 0; x < result.length; x++) {
			for (int y = 0; y < result[x].length; y++) {
				pstmt3.setString(1, result[x][y]);
				ResultSet rs3 = pstmt3.executeQuery();
				while (rs3.next()) {

					if (rs3.getString(1).contains(";"))
						result[x][y] = rs3.getString(1).split(";")[0];
					else
						result[x][y] = rs3.getString(1);
					// System.out.println(result[x][y]);
				}
				rs3.beforeFirst();
				rs3.close();
			}
		}
		pstmt3.close();
		conn3.close();

		return result;
	}

	public static String[][] readmysql3() throws ClassNotFoundException, SQLException {
		Class.forName(DBDRIVER);
		Connection conn = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD);

		Statement stmt = conn.createStatement();

		String sql = "SELECT `subunits(entrez_ids)` FROM biodata.protein_complex where organism  = 'human'";
		ResultSet rs = stmt.executeQuery(sql);
		int lengthtemp = 0;
		while (rs.next()) {
			lengthtemp++;
		}
		String array[] = new String[lengthtemp];
		int i = 0;
		rs.beforeFirst();
		while (rs.next()) {
			array[i] = rs.getString(1);
			i++;
		}
		rs.close();
		stmt.close();
		conn.close();

		String result[][] = new String[array.length][];
		for (int j = 0; j < array.length; j++) {
			String[] myArray = array[j].split(";");
			result[j] = new String[myArray.length];
			for (int k = 0; k < myArray.length; k++) {
				result[j][k] = myArray[k];
			}
		}
		return result;
		//result 是uniprotkb
//
//		Connection conn2=DriverManager.getConnection(url);
//		String sql2="SELECT gene_id FROM biodata.id_mapping where uniprotkb_ac =? ;";
//		PreparedStatement pstmt2 =conn2.prepareStatement(sql2);
//		for(int x=0; x<result.length; x++) {
//	          for(int y=0; y<result[x].length; y++) {
//	        	  	pstmt2.setString(1, result[x][y]);
//	        	  	ResultSet rs2 = pstmt2.executeQuery();
////	        	  	if(!rs2.next()) {
////	        	  		array[x][y]="null";
////	        	  	}
////	        	  	
////	        	  	rs2.beforeFirst();
////	        	  	if(rs2.next()&&rs2.getString(1).equals("")) {
////	        	  		array[x][y]="null";
////	        	  	}
//	        	  	rs2.beforeFirst();
//	        	  	while(rs2.next()) {
//	        	  		if(rs2.getString(1).equals("")) {
//	        	  			
//	        	  		}else {
//	        	  			System.out.println(rs2.getString(1));
//	        	  			result[x][y]=rs2.getString(1).split(";")[0];
//	        	  		}
//	        	  	}
//	        	  	rs2.beforeFirst();
//	        	  	rs2.close();
//	          }
//		}
//		pstmt2.close();
//		conn2.close();
//		return result;
	}
}
