package cn.edu.whut.evaluate;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;

public class Test {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String[][] known = null;
		try {
			known = ReadMySQL.readmysql2();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//human
		String[][] known2 = null;
		try {
			known2 = ReadMySQL.readmysql();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//

// 		String[][] rect164 = readtxt.createArray("F:\\test\\distinct-clusters\\16429126\\16429126-rect-clusters");
// 		String[][] tri164 = readtxt.createArray("F:\\test\\distinct-clusters\\16429126\\16429126-tri-clusters");
// 		String[][] link164 = readtxt.createArray("F:\\test\\16429126-links-clusters");
// 		String[][] addalllimit = merge.calculate(rect164, tri164, link164);
// 		String[][] rect164limit = merge.rectlimit(rect164);
// 		String[][] tri164limit = merge.trilimit(tri164);
// 		String[][] link164limit = merge.linklimit(link164);
//
// 		String[][] addalllimit2 = merge.calculate(rect164limit, tri164limit, link164limit);
// 		String outfile = "F:\\merge164distinctWithoutLimit";
// 		String outfile2 = "F:\\merge164distinctWithLimit";
// 		save(addalllimit, outfile);
// 		save(addalllimit2, outfile2);
// 		float f_measure_co2 = fmeasure_match.fmeasure(tri164limit, known);
// 		float ACC_co2 = Acc.accuracy(tri164limit, known);
// 		double mmr2 = MMR.calculate(tri164limit, known);
// 		System.out.println("f-measure为：" + f_measure_co2);
// 		System.out.println("fcan的ACC为：" + ACC_co2);
// 		System.out.println("fcan计算所得的MMR的数值为：" + mmr2);
//
// 		String[][] rect165 = readtxt.createArray("F:\\test\\distinct-clusters\\16554755\\16554755-rect-clusters");
// 		String[][] tri165 = readtxt.createArray("F:\\test\\distinct-clusters\\16554755\\16554755-tri-clusters");
// 		String[][] link165 = readtxt.createArray("F:\\test\\16554755-links-clusters");
// 		String[][] addalllimit = merge.calculate(rect165, tri165, link165);
// 		String[][] rect165limit = merge.rectlimit(rect165);
// 		String[][] tri165limit = merge.trilimit(tri165);
// 		String[][] link165limit = merge.linklimit(link165);
// 		String[][] addalllimit2 = merge.calculate(rect165limit, tri165limit, link165limit);
// 		String outfile = "F:\\merge165DistinctWithoutLimit";
// 		String outfile2 = "F:\\merge165DistinctWithLimit";
// 		save(addalllimit, outfile);
// 		save(addalllimit2, outfile2);
// 		float f_measure_co2 = fmeasure_match.fmeasure(rect165limit, known);
// 		float ACC_co2 = Acc.accuracy(rect165limit, known);
// 		double mmr2 = MMR.calculate(rect165limit, known);
// 		System.out.println("f-measure为：" + f_measure_co2);
// 		System.out.println("fcan的ACC为：" + ACC_co2);
// 		System.out.println("fcan计算所得的MMR的数值为：" + mmr2);
//
// 		String[][] rect172 = readtxt.createArray("F:\\test\\distinct-clusters\\17200106\\17200106-rect-clusters");
// 		String[][] tri172 = readtxt.createArray("F:\\test\\distinct-clusters\\17200106\\17200106-tri-clusters");
// 		String[][] link172 = readtxt.createArray("F:\\test\\17200106-links-clusters");
// 		String[][] addalllimit = merge.calculate(rect172, tri172, link172);
// 		String[][] rect172limit = merge.rectlimit(rect172);
// 		String[][] tri172limit = merge.trilimit(tri172);
// 		String[][] link172limit = merge.linklimit(link172);
// 		String[][] addalllimit2 = merge.calculate(rect172limit, tri172limit, link172limit);
// 		String outfile = "F:\\merge172DistinctWithoutLimit";
// 		String outfile2 = "F:\\merge172DistinctWithLimit";
// 		save(addalllimit, outfile);
// 		save(addalllimit2, outfile2);
// 		float f_measure_co2 = fmeasure_match.fmeasure(rect172limit, known);
// 		float ACC_co2 = Acc.accuracy(rect172limit, known);
// 		double mmr2 = MMR.calculate(rect172limit, known);
// 		System.out.println("f-measure为：" + f_measure_co2);
// 		System.out.println("fcan的ACC为：" + ACC_co2);
// 		System.out.println("fcan计算所得的MMR的数值为：" + mmr2);
//
		String[][] rectScere = ReadFile.createArray("F:\\test\\distinct-clusters\\scere\\scere-rect-clusters");
		String[][] triScere = ReadFile.createArray("F:\\test\\distinct-clusters\\scere\\scere-tri-clusters");
		String[][] linkScere = ReadFile.createArray("F:\\test\\scere-links-clusters");
		String[][] addalllimit = Merge.calculate(rectScere, triScere, linkScere);
		String[][] rectScerelimit = Merge.rectlimit(rectScere);
		String[][] triScerelimit = Merge.trilimit(triScere);
		String[][] linkScerelimit = Merge.linklimit(linkScere);
		String[][] addalllimit2 = Merge.calculate(rectScerelimit, triScerelimit, linkScerelimit);
		String outfile = "F:\\mergeScereDistinctWithoutLimit";
		String outfile2 = "F:\\mergeScereDistinctWithLimit";
		save(addalllimit, outfile);
		save(addalllimit2, outfile2);
		// float f_measure_co2 = fmeasure_match.fmeasure(addalllimit, known);
		// float ACC_co2 = Acc.accuracy(addalllimit, known);
		// double mmr2 = MMR.calculate(addalllimit, known);
		// System.out.println("f-measure为：" + f_measure_co2);
		// System.out.println("fcan的ACC为：" + ACC_co2);
		// System.out.println("fcan计算所得的MMR的数值为：" + mmr2);
		//
		// String[][] recthsapi = readtxt.createArray("F:\\test\\distinct-clusters\\hsapi\\hsapi-rect-clusters");
		// String[][] trihsapi = readtxt.createArray("F:\\test\\distinct-clusters\\hsapi\\hsapi-tri-clusters");
		// String[][] linkhsapi = readtxt.createArray("F:\\test\\hsapi-links-clusters");
		// String[][] addalllimit = merge.calculate(recthsapi, trihsapi, linkhsapi);
		// String[][] recthsapilimit = merge.rectlimit(recthsapi);
		// String[][] trihsapilimit = merge.trilimit(trihsapi);
		// String[][] linkhsapilimit = merge.linklimit(linkhsapi);
		// String[][] addalllimit2 = merge.calculate(recthsapilimit, trihsapilimit, linkhsapilimit);
		// String outfile = "F:\\mergeHsapiDistinctWithoutLimit";
		// String outfile2 = "F:\\mergeHsapiDistinctWithLimit";
		// save(addalllimit, outfile);
		// save(addalllimit2, outfile2);
		// float f_measure_co2 = fmeasure_match.fmeasure(linkhsapilimit, known2);
		// float ACC_co2 = Acc.accuracy(linkhsapilimit, known2);
		// double mmr2 = MMR.calculate(linkhsapilimit, known2);
		// System.out.println("f-measure为：" + f_measure_co2);
		// System.out.println("fcan的ACC为：" + ACC_co2);
		// System.out.println("fcan计算所得的MMR的数值为：" + mmr2);
	}

	private static void save(String membershipMatrix[][], String outputFile) {
		// TODO Auto-generated method stub
		String content = "";

		for (int i = 0; i < membershipMatrix.length; i++) {
			content += content.length() == 0 ? "" : "\n";

			for (int j = 0; j < membershipMatrix[i].length; j++) {
				content += (j == 0 ? "" : "\t") + membershipMatrix[i][j];
			}
		}

		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter(outputFile));
			bw.write(content);
			bw.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block

		} finally {
			if (bw != null)
				try {
					bw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block

				}
		}
	}
}
