package cn.edu.whut.evaluate_new;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashSet;
import java.util.Set;

public class CalcCYCProteins {
	public static void main(String[] args) {
		String cyc = "data/databases/CYC2008_complex.tab.txt";
		Set<String> proteins = new HashSet<>();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(cyc));
			String line;
			while ((line = br.readLine()) != null) {
				if (line.startsWith("ORF")) continue;
				String[] vals = line.split("\t");
				proteins.add(vals[1]);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(proteins.size());
	}
}
