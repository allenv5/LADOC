package cn.edu.whut.evaluate_new;

import java.util.*;

public class Evaluate {
	public static void main(String[] args) {
		// cluster file
		String filePath = "data/dataset/DIP-Hsapi/";
		String fileName = "clusters";

		List<List<String>> clustersArray = ReadFile2.getClustersAarry(filePath + fileName);
		List<List<String>> known = ReadFile2.getKnownData();

		// System.out.println(fmeasure(toMatrix(clustersArray), toMatrix(known)));

		Set<String> allProteins = new HashSet<>();
		for (List<String> l : known) {
			allProteins.addAll(l);
		}

		System.out.println(allProteins.size());


		// float fmeasureValue = getFMeasureScore(clustersArray, known);
		// System.out.println(fmeasureValue);


	}

	private static float getFMeasureScore(List<List<String>> clustersArray, List<List<String>> known) {
		float result;
		Set<Integer> Ncp = new HashSet<>();
		Set<Integer> Ncg = new HashSet<>();
		for (int i = 0; i < clustersArray.size(); i++) {
			for (int j = 0; j < known.size(); j++) {
				List<String> tmp = new ArrayList<>();
				Set<String> common = new HashSet<>();
				for (String str : clustersArray.get(i)) {
					if (!tmp.contains(str)) {
						tmp.add(str);
					}
				}
				for (String str : known.get(j)) {
					if (tmp.contains(str)) {
						common.add(str);
					}
				}
				if ((float)(common.size() * common.size() / clustersArray.get(i).size() * known.get(j).size()) >= 0.2) {
					Ncp.add(i);
					Ncg.add(j);
				}
				tmp.clear();
				common.clear();
			}
		}
		if (Ncp.size() == 0) {
			result = 0;
		} else {
			float precision = Ncp.size() / (float) clustersArray.size();
			float recall = Ncg.size() / (float) known.size();
			result = 2 * precision * recall / (precision + recall);
		}
		return result;
	}

	private static float fmeasure(String[][] predicted, String[][] known) {
		float result = 0;
		Set<Integer> Ncp = new HashSet<Integer>();
		Set<Integer> Ncg = new HashSet<Integer>();

		int Ncpi = 0, Ncgi = 0;
		// for(int i =0)匹配度超过0.2 两个复合物的交集除于他们各自复合物的蛋白质数目加起来。
		for (int i = 0; i < predicted.length; i++) {

			for (int j = 0; j < known.length; j++) {

				List<String> l = new LinkedList<String>();
				Set<String> common = new HashSet<String>();
				for (String str : predicted[i]) {
					if (!l.contains(str)) {
						l.add(str);
					}
				}
				for (String str : known[j]) {
					if (l.contains(str)) {
						common.add(str);
					}
				}
				String[] com = new String[common.size()];
				common.toArray(com);
				if ((float)((com.length * com.length) / (predicted[i].length) * (known[j].length)) >= 0.2) {
					Ncp.add(i);
					Ncg.add(j);
					// Ncp[Ncpi] = i;
					// Ncg[Ncgi] = j;
					// Ncpi++;
					// Ncgi++;
				}
				l.clear();
				common.clear();
			}
		}

		if (Ncp.size() == 0) {
			result = 0;
		} else {
			float precision = (float) Ncp.size() / predicted.length;
			float recall = (float) Ncg.size() / known.length;
			result = 2 * precision * recall / (precision + recall);
		}
		return result;
	}

	private static String[][] toMatrix(List<List<String>> array) {
		String[][] matrix = new String[array.size()][];
		for (int i = 0; i < array.size(); i++) {
			matrix[i] = new String[array.get(i).size()];
			for (int j = 0; j < array.get(i).size(); j++) {
				matrix[i][j] = array.get(i).get(j);
			}
		}
		return matrix;
	}
}
