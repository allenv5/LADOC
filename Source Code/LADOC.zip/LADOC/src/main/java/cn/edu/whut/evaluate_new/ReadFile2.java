package cn.edu.whut.evaluate_new;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ReadFile2 {
	private static String DATABASE_FILE = "data/databases/corum_allComplexes.json";

	public static void main(String[] args) {
		List<List<String>> known = getKnownData();
		List<List<String>> clusters = getClustersAarry("data/dataset/DIP-Hsapi/clusters");
	}

	public static List<List<String>> getKnownData() {
		List<List<String>> known = new ArrayList<>();
		JSONArray array = getJSONSArray(DATABASE_FILE);
		for (int i = 0; i < array.length(); i++) {
			JSONObject obj = array.getJSONObject(i);
			List<String> tmp = new ArrayList<>();
			if (obj.getString("Organism").equals("Human")) {
				String[] items = obj.getString("subunits(Entrez IDs)").split(";");
				tmp.addAll(Arrays.asList(items));
				known.add(tmp);
			}
		}
		return known;
	}

	private static JSONArray getJSONSArray(String fileName) {
		String jsonStr = "";
		try {
			File file = new File(fileName);
			Reader reader = new InputStreamReader(new FileInputStream(file), "UTF-8");
			int ch;
			StringBuffer sb = new StringBuffer();
			while ((ch = reader.read()) != -1) {
				sb.append((char) ch);
			}
			reader.close();
			jsonStr = sb.toString();
			return new JSONArray(jsonStr);
		} catch (Exception e) {
			e.printStackTrace();
			return new JSONArray();
		}
	}

	public static List<List<String>> getClustersAarry(String fileName) {
		List<List<String>> allClusters = new ArrayList<>();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(fileName));
			String line;
			while ((line = br.readLine()) != null) {
				if (!line.startsWith("Cluster")) {
					String[] items = line.split("\t");
					List<String> cluster = new ArrayList<>(Arrays.asList(items));
					allClusters.add(cluster);
				}
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return allClusters;
	}
}
