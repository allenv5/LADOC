package cn.edu.whut.function_enrichment_test;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;

public class PValueTest {
	static String filePath = "D:\\Users\\Vertex-Z\\Desktop\\process\\function_enrichment_test\\GMFTP\\Hsapi_all\\output\\";
	// static String filePath = "D:\\Users\\Vertex-Z\\Desktop\\process\\function_enrichment_test\\test_process\\output\\TEST_output\\";


	public static void main(String[] args) throws Exception {
		File file = new File(filePath);
		File[] fileList = file.listFiles();

		double total = 196;
		
		int count1 = 0, count2 = 0, count3 = 0, count4 = 0;

		for (File f : fileList) {
			if (f.isFile()) {
				if (f.getName().endsWith("_tab.txt")) {
					String prefix = f.getName().split("_")[0];
					// System.out.println(f.getName());
					double val = getPValue(filePath + f.getName());
					if (val <= 1e-2) count1++;
					if (val <= 1e-5) count2++;
					if (val <= 1e-10) count3++;
					if (val <= 1e-15) count4++;
				}
			}
		}

		System.out.println("<=E-2: " + count1 + ", " + count1 / total);
		System.out.println("<=E-5: " + count2 + ", " +count2 / total);
		System.out.println("<=E-10: " + count3 + ", " +count3 / total);
		System.out.println("<=E-15: " + count4 + ", " +count4 / total);
	}

	private static boolean exsitFile(String fileNmae) {
		File file = new File(fileNmae);
		return file.isFile();
	}

	private static double getPValue(String fileName) {
		double pValue;
		try {
			BufferedReader br = new BufferedReader(new FileReader(fileName));
			String line;
			while ((line = br.readLine()) != null) {
				if (line.startsWith("Min p-value")) {
					String[] items = line.split("\t");
					pValue = Double.parseDouble(items[1]);
					return pValue;
				}
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 1;
	}
}
