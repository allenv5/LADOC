package cn.edu.whut.ladoc;

import cn.edu.whut.ladoc.experiment.ProteinComplexPredictionWithDCAP;
import org.apache.log4j.Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class App {
	private static Logger logger = Logger.getLogger(App.class);

	public static void main(String[] args) {
		long t1 = System.currentTimeMillis();
		String propertiesFile;
		if (args.length > 0) {
			propertiesFile = args[0];
		} else {
			propertiesFile = "properties.txt";
		}
		float alpha = 0.5F;
		float beta = 0.5F;
		float theta = 1.0F;
		float phi = 1.0F;
		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream(propertiesFile));
			String graphFolder = properties.getProperty("graph_folder");
			float maxChange = Float.parseFloat(properties.getProperty("delta"));
			float minAttributeSimilarity = 0.0F;
			float minTopologyWeight = 0.0F;
			int maxLoops = Integer.parseInt(properties.getProperty("max_loops"));
			int minSize = Integer.parseInt(properties.getProperty("min_cluster_size"));
			float simrankC = Float.parseFloat(properties.getProperty("simrank_c"));
			int numThreads = Integer.parseInt(properties.getProperty("num_threads"));
			int numExecutions = Integer.parseInt(properties.getProperty("num_executions"));
			String saveFolder = graphFolder;
			ProteinComplexPredictionWithDCAP experiment = new ProteinComplexPredictionWithDCAP(
					graphFolder, alpha, beta, theta, phi, maxChange, minAttributeSimilarity,
					minTopologyWeight, maxLoops, minSize, saveFolder, simrankC, numThreads, numExecutions);
			experiment.run();
		} catch (IOException e) {
			e.printStackTrace();
		}
		long t2 = System.currentTimeMillis();
		logger.info("Execute application cost: " + (t2 - t1) / (float)1000 + "s");
	}
}
