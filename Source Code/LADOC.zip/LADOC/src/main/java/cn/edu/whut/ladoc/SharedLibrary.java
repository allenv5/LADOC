package cn.edu.whut.ladoc;

import cn.edu.whut.ladoc.thread.MatrixWriterThread;
import org.apache.log4j.Logger;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class SharedLibrary {
	public static Logger logger = Logger.getLogger(SharedLibrary.class);
	private static int MinNumOfRowsForMultiThread = 500;

	public SharedLibrary() {
	}

	public static void saveMatrixToFile(float[][] matrix, String file) {
		if (matrix.length <= MinNumOfRowsForMultiThread) {
			saveMatrixToFileWithSingleThread(matrix, file);
		} else {
			saveMatrixToFileWithMultipleThreads(matrix, file);
		}

	}

	private static void saveMatrixToFileWithMultipleThreads(float[][] matrix, String file) {
		createFolder(file);
		int threads = (int)Math.ceil((double)matrix.length / (double)MinNumOfRowsForMultiThread);
		logger.debug("We have to save this matrix with " + threads + " threads");
		ExecutorService pool = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

		for(int i = 0; i < threads; ++i) {
			float[][] matrixToBeSaved = (float[][])Arrays.copyOfRange(matrix, i * MinNumOfRowsForMultiThread, (i + 1) * MinNumOfRowsForMultiThread);
			String aFile = file + File.separator + (i + 1);
			MatrixWriterThread aThread = new MatrixWriterThread(matrixToBeSaved, aFile, i + 1);
			pool.execute(aThread);
		}

		pool.shutdown();

		try {
			pool.awaitTermination(9223372036854775807L, TimeUnit.SECONDS);
		} catch (InterruptedException var8) {
			var8.printStackTrace();
		}

	}

	private static void saveMatrixToFileWithSingleThread(float[][] matrix, String file) {
		MatrixWriterThread writer = new MatrixWriterThread(matrix, file, 1);
		writer.run();
	}

	public static void saveToFile(String content, String file) {
		BufferedWriter bw = null;

		try {
			bw = new BufferedWriter(new FileWriter(file));
			bw.write(content);
			bw.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

	}

	public static void normalizeMatrix(float[][] matrix) {

		for (float[] fs : matrix) {
			float sum = 0.0F;

			for (float f : fs) {
				sum += f;
			}

			for (int i = 0; i < fs.length; ++i) {
				fs[i] /= sum;
				fs[i] = roundWithTowDecimalPlaces(fs[i]);
			}
		}

	}

	public static float roundWithTowDecimalPlaces(float valueToBeRounded) {
		// return (float)Math.round(valueToBeRounded * 100.0F) / 100.0F;
		return Math.round(valueToBeRounded * 100) / 100F;
	}

	public static boolean createFolder(String path) {
		File folder = new File(path);
		return folder.isDirectory() || folder.mkdir();
	}

	public static void saveClusteringResult(Set<Set<String>> clusterSet, String folder, String filename) {
		StringBuilder content = new StringBuilder();
		int clusterIdx = 1;

		String setString;
		for(Iterator var6 = clusterSet.iterator(); var6.hasNext(); content.append("\n").append(setString)) {
			Set set = (Set)var6.next();
			content.append(content.length() == 0 ? "" : "\n").append("Cluster #").append(clusterIdx++);
			setString = "";

			String item;
			for(Iterator var9 = set.iterator(); var9.hasNext(); setString = setString + (setString.length() == 0 ? "" : "\t") + item) {
				item = (String)var9.next();
			}
		}

		String file = folder + File.separator + (filename == null ? "clusters" : filename);
		saveToFile(content.toString(), file);
	}

	public static void saveClusterAsGraph(Set<String> cluster, int[][] incidenceMatrix, Map<String, Integer> vertex2IdMap, String folder) {
		StringBuilder vertices = new StringBuilder();
		int vertexId = 0;
		String[] vertexArray = new String[cluster.size()];
		String vertexFile = folder + File.separator + "proteins";

		String edges;
		for(Iterator var9 = cluster.iterator(); var9.hasNext(); vertexArray[vertexId++] = edges) {
			edges = (String)var9.next();
			vertices.append(vertices.length() == 0 ? "" : "\n").append(edges);
		}

		saveToFile(vertices.toString(), vertexFile);
		edges = "";
		String edgeFile = folder + File.separator + "ppis";

		for(int i = 0; i < vertexArray.length - 1; ++i) {
			for(int j = i; j < vertexArray.length; ++j) {
				int vertex = (Integer)vertex2IdMap.get(vertexArray[i]);
				int anotherVertex = (Integer)vertex2IdMap.get(vertexArray[j]);
				if (incidenceMatrix[vertex][anotherVertex] == 1) {
					edges = edges + (edges.length() == 0 ? "" : "\n") + vertexArray[i] + "\t" + vertexArray[j];
				}
			}
		}

		saveToFile(edges, edgeFile);
	}
}
