package cn.edu.whut.ladoc.demo;

import java.util.*;

public class Demo {
	public static void main(String[] args) {
		double d1 = 9.0884656E7;
		double d2 = 9.0884664E7;
		long l1 = (long)d1;
		System.out.println(l1);
	}
}
