package cn.edu.whut.ladoc.experiment;

import cn.edu.whut.ladoc.SharedLibrary;
import cn.edu.whut.ladoc.impl.DataAdapter;
import cn.edu.whut.ladoc.impl.MatrixFactory;
import cn.edu.whut.ladoc.impl.ModelBasedAGCWithMinimumStep;
import cn.edu.whut.ladoc.impl.SimpleClustering;
import cn.edu.whut.ladoc.similarity.JaccardSimilarityMeasure;
import cn.edu.whut.ladoc.similarity.SimilarityMeasure;
import org.apache.log4j.Logger;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class CoraExperiment {
	public static Logger logger = Logger.getLogger(CoraExperiment.class);
	public static int MinImportantClusterSize = 10;
	private String graphDataPath;
	private float alpha;
	private float beta;
	private float theta;
	private float phi;
	private float maxChange;
	private float minAttributeSimilarity;
	private float minTopologyWeight;
	private int numAttributes;
	private int maxLoops;
	private int minSize;
	private String saveFolder;

	public CoraExperiment(String graphDataPath, int numAttributes, float alpha, float beta, float theta, float phi, float maxChange, float minAttributeSimilarity, float minTopologyWeight, int maxLoops, int minSize, String saveFolder) {
		this.graphDataPath = graphDataPath;
		this.numAttributes = numAttributes;
		this.alpha = alpha;
		this.beta = beta;
		this.theta = theta;
		this.phi = phi;
		this.maxChange = maxChange;
		this.minAttributeSimilarity = minAttributeSimilarity;
		this.minTopologyWeight = minTopologyWeight;
		this.maxLoops = maxLoops;
		this.minSize = 2;
		this.saveFolder = saveFolder;
	}

	public void run() {
		String vertexFile = "vertex";
		String edgeFile = "cora.cites";
		String attributePrefix = String.valueOf(this.graphDataPath) + File.separator +
				"attribute-";
		JaccardSimilarityMeasure similarityMeasure = new JaccardSimilarityMeasure();
		DataAdapter adapter = new DataAdapter(this.graphDataPath, vertexFile,
				edgeFile, (SimilarityMeasure)similarityMeasure, attributePrefix,
				this.numAttributes, this.minAttributeSimilarity,
				this.minTopologyWeight);
		adapter.run();
		int numVertices = (adapter.getIncidenceMatrix()).length;
		ModelBasedAGCWithMinimumStep agc = new ModelBasedAGCWithMinimumStep(
				MatrixFactory.generateConstrainedMatrix(numVertices,
						numVertices, 0.0F, 1.0F),
				MatrixFactory.generateNormalizedMatrixWithConstraints(
						numVertices, this.numAttributes, 0.0F, 1.0F),
				adapter.getIncidenceMatrix(),
				adapter.getAttributeWeightMatrix(),
				adapter.getTolopogyWeightMatrix(), this.alpha, this.beta,
				this.theta, this.phi, this.maxChange, this.maxLoops,
				this.saveFolder);
		agc.run();
		SimpleClustering sc = new SimpleClustering(
				adapter.getIncidenceMatrix(), agc.getMatrixL(),
				adapter.getId2VertexMap(), this.minSize);
		sc.run();
		SharedLibrary.saveClusteringResult(sc.getClusterSet(),
				this.graphDataPath, null);
		int clusterIdx = 1;
		for (Set<String> cluster : (Iterable<Set<String>>)sc.getClusterSet()) {
			if (cluster.size() >= MinImportantClusterSize)
				extractInfo(cluster, clusterIdx, adapter.getAttributeWeightMatrix(), adapter.getVertex2IdMap(), adapter.getIncidenceMatrix());
			clusterIdx++;
		}
	}

	private void extractInfo(Set<String> cluster, int clusterIdx, float[][][] attributeWeightMatrix, Map<String, Integer> vertex2IdMap, int[][] incidenceMatrix) {
		String folder = String.valueOf(this.saveFolder) + File.separator + "Cluster-" + clusterIdx;
		SharedLibrary.createFolder(folder);
		String[] itemArray = new String[cluster.size()];
		int itemIdx = 0;
		for (String item : cluster)
			itemArray[itemIdx++] = item;
		Map<String, String> lableMap = readVertexLabelMap();
		saveAttributeWeightFile(folder, attributeWeightMatrix, itemArray, vertex2IdMap);
		saveIncidenceFile(folder, incidenceMatrix, itemArray, vertex2IdMap);
		saveVertexLabelFile(folder, itemArray, lableMap);
	}

	private void saveVertexLabelFile(String folder, String[] itemArray, Map<String, String> lableMap) {
		String content = "";
		byte b;
		int i;
		String[] arrayOfString;
		for (i = (arrayOfString = itemArray).length, b = 0; b < i; ) {
			String item = arrayOfString[b];
			if (lableMap.containsKey(item)) {
				content = String.valueOf(content) + ((content.length() == 0) ? "" : "\n") + item + "," + (String)lableMap.get(item);
			} else {
				logger.error("The label of " + item + " is not found");
			}
			b++;
		}
		SharedLibrary.saveToFile(content, String.valueOf(folder) + File.separator + "label");
	}

	private Map<String, String> readVertexLabelMap() {
		Map<String, String> labelMap = new HashMap<String, String>();
		String labelFile = String.valueOf(this.graphDataPath) + File.separator + "cora-type.csv";
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(labelFile));
			String line;
			while ((line = br.readLine()) != null) {
				String[] items = line.split(",");
				labelMap.put(items[0], items[1]);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		return labelMap;
	}

	private void saveIncidenceFile(String folder, int[][] incidenceMatrix, String[] cluster, Map<String, Integer> vertex2IdMap) {
		String header = "source,target,type,id";
		String content = "";
		int id = 1;
		for (int i = 0; i < cluster.length - 1; i++) {
			int iIndex = ((Integer)vertex2IdMap.get(cluster[i])).intValue();
			for (int j = i + 1; j < cluster.length; j++) {
				int jIndex = ((Integer)vertex2IdMap.get(cluster[j])).intValue();
				if (incidenceMatrix[iIndex][jIndex] == 1)
					content = String.valueOf(content) + ((content.length() == 0) ? "" : "\n") + cluster[i] + "," + cluster[j] + ",Undirected," + id++;
			}
		}
		SharedLibrary.saveToFile(String.valueOf(header) + "\n" + content, String.valueOf(folder) + File.separator + "edges");
	}

	private void saveAttributeWeightFile(String folder, float[][][] attributeWeightMatrix, String[] cluster, Map<String, Integer> vertex2IdMap) {
		String idContent = "";
		String lableContent = "";
		for (int i = 0; i < cluster.length; i++) {
			int iIndex = ((Integer)vertex2IdMap.get(cluster[i])).intValue();
			for (int j = i; j < cluster.length; j++) {
				int jIndex = ((Integer)vertex2IdMap.get(cluster[j])).intValue();
				String attributeInfo = "";
				for (int k = 0; k < attributeWeightMatrix.length; k++) {
					float weight = (i == j) ? 1.0F : (attributeWeightMatrix[k][iIndex][jIndex] + this.minAttributeSimilarity);
					attributeInfo = String.valueOf(attributeInfo) + ((attributeInfo.length() == 0) ? "" : "\t") + weight;
				}
				idContent = String.valueOf(idContent) + ((idContent.length() == 0) ? "" : "\n") + iIndex + "\t" + jIndex + "\t" + attributeInfo;
				lableContent = String.valueOf(lableContent) + ((lableContent.length() == 0) ? "" : "\n") + cluster[i] + "\t" + cluster[j] + "\t" + attributeInfo;
			}
		}
		SharedLibrary.saveToFile(idContent, String.valueOf(folder) + File.separator + "id-attribute-weight");
		SharedLibrary.saveToFile(lableContent, String.valueOf(folder) + File.separator + "label-attribute-weight");
	}

	public static void main(String[] args) {
		String graphFolder = "C:\\Users\\Allen Hu\\Dropbox\\Research\\Working\\Graph Clustering\\Multi-attribute\\Model-based AGC\\Experiments\\Cora";
		int numAttributes = 1;
		float alpha = 1.0F;
		float beta = 1.0F;
		float theta = 1.0F;
		float phi = 1.0F;
		float maxChange = 10.0F;
		float minAttributeSimilarity = 0.2F;
		float minTopologyWeight = 0.35F;
		int maxLoops = 100;
		int minSize = 2;
		String saveFolder = graphFolder;
		CoraExperiment experiment = new CoraExperiment(
				graphFolder, numAttributes, alpha, beta, theta, phi, maxChange,
				minAttributeSimilarity, minTopologyWeight, maxLoops, minSize, saveFolder);
		experiment.run();
	}
}
