package cn.edu.whut.ladoc.experiment;

import cn.edu.whut.ladoc.impl.DataAdapter;
import cn.edu.whut.ladoc.SharedLibrary;
import cn.edu.whut.ladoc.impl.MatrixFactory;
import cn.edu.whut.ladoc.impl.ModelBasedAGCWithMinimumStep;
import cn.edu.whut.ladoc.impl.SimpleClustering;
import cn.edu.whut.ladoc.similarity.JaccardSimilarityMeasure;
import cn.edu.whut.ladoc.similarity.SimilarityMeasure;
import org.apache.log4j.Logger;

import java.io.File;
import java.util.Set;

public class ProteinComplexPredictionExperiment {
	public static Logger logger = Logger.getLogger(ProteinComplexPredictionExperiment.class);
	public static float MaxPercentageOfProteinsInCluster = 0.1F;
	private String graphDataPath;
	private float alpha;
	private float beta;
	private float theta;
	private float phi;
	private float maxChange;
	private float minAttributeSimilarity;
	private float minTopologyWeight;
	private int numAttributes;
	private int maxLoops;
	private int minSize;
	private String saveFolder;

	public ProteinComplexPredictionExperiment(String graphDataPath, int numAttributes, float alpha, float beta, float theta, float phi, float maxChange, float minAttributeSimilarity, float minTopologyWeight, int maxLoops, int minSize, String saveFolder) {
		this.graphDataPath = graphDataPath;
		this.numAttributes = numAttributes;
		this.alpha = alpha;
		this.beta = beta;
		this.theta = theta;
		this.phi = phi;
		this.maxChange = maxChange;
		this.minAttributeSimilarity = minAttributeSimilarity;
		this.minTopologyWeight = minTopologyWeight;
		this.maxLoops = maxLoops;
		this.minSize = 2;
		this.saveFolder = saveFolder;
	}

	public void run() {
		String vertexFile = "proteins";
		String edgeFile = "ppis";
		String attributePrefix = String.valueOf(this.graphDataPath) + File.separator +
				"attribute-";
		JaccardSimilarityMeasure similarityMeasure = new JaccardSimilarityMeasure();
		DataAdapter adapter = new DataAdapter(this.graphDataPath, vertexFile,
				edgeFile, (SimilarityMeasure)similarityMeasure, attributePrefix,
				this.numAttributes, this.minAttributeSimilarity,
				this.minTopologyWeight);
		adapter.run();
		int numVertices = (adapter.getIncidenceMatrix()).length;
		ModelBasedAGCWithMinimumStep agc = new ModelBasedAGCWithMinimumStep(
				MatrixFactory.generateConstrainedMatrix(numVertices,
						numVertices, 0.0F, 1.0F),
				MatrixFactory.generateNormalizedMatrixWithConstraints(
						numVertices, this.numAttributes, 0.0F, 1.0F),
				adapter.getIncidenceMatrix(),
				adapter.getAttributeWeightMatrix(),
				adapter.getTolopogyWeightMatrix(), this.alpha, this.beta,
				this.theta, this.phi, this.maxChange, this.maxLoops,
				this.saveFolder);
		agc.run();
		SimpleClustering sc = new SimpleClustering(
				adapter.getIncidenceMatrix(), agc.getMatrixL(),
				adapter.getId2VertexMap(), this.minSize);
		sc.run();
		SharedLibrary.saveClusteringResult(sc.getClusterSet(),
				this.saveFolder, null);
		int clusterId = 1;
		float maxNumOfProteinsInCluster = (adapter.getIncidenceMatrix()).length * MaxPercentageOfProteinsInCluster;
		for (Set<String> cluster : (Iterable<Set<String>>)sc.getClusterSet()) {
			if (cluster.size() > maxNumOfProteinsInCluster) {
				String folder = String.valueOf(this.saveFolder) + File.separator + "Cluster-" + clusterId;
				SharedLibrary.createFolder(folder);
				SharedLibrary.saveClusterAsGraph(cluster, adapter.getIncidenceMatrix(), adapter.getVertex2IdMap(), folder);
			}
			clusterId++;
		}
	}
}
