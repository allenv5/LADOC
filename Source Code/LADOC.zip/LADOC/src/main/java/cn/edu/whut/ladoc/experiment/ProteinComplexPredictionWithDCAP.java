package cn.edu.whut.ladoc.experiment;

import cn.edu.whut.ladoc.tools.GraphTool;
import cn.edu.whut.ladoc.graph.ProcessCluster;
import cn.edu.whut.ladoc.impl.MatrixFactory;
import cn.edu.whut.ladoc.graph.GraphReader;
import cn.edu.whut.ladoc.impl.dcap.ParrallelDCAPImpl;
import org.apache.log4j.Logger;

import java.io.File;
import java.util.List;

public class ProteinComplexPredictionWithDCAP {
	public static Logger logger = Logger.getLogger(ProteinComplexPredictionWithDCAP.class);
	private String graphDataPath;
	private float alpha;
	private float beta;
	private float theta;
	private float phi;
	private float maxChange;
	private float minAttributeSimilarity;
	private float minTopologyWeight;
	private float wMin;
	private int maxLoops;
	private int minSize;
	private String saveFolder;
	private float simrankC;
	private int numThreads;
	private int numExecutions;

	public ProteinComplexPredictionWithDCAP(String graphDataPath, float alpha, float beta, float theta, float phi,
											float maxChange, float minAttributeSimilarity, float minTopologyWeight,
											int maxLoops, int minSize, String saveFolder, float simrankC, int numThreads, int numExecutions) {
		this.graphDataPath = graphDataPath;
		this.alpha = alpha;
		this.beta = beta;
		this.theta = theta;
		this.phi = phi;
		this.maxChange = maxChange;
		this.minAttributeSimilarity = minAttributeSimilarity;
		this.minTopologyWeight = minTopologyWeight;
		this.maxLoops = maxLoops;
		this.minSize = 2;
		this.saveFolder = saveFolder;
		this.simrankC = simrankC;
		this.numThreads = numThreads;
		this.numExecutions = numExecutions;
	}

	public void run() {
		long t1 = System.currentTimeMillis();
		List<String> allAttributeFilesList = GraphTool.getAllAttributeFilesName(this.graphDataPath);
		GraphReader gr = new GraphReader(this.graphDataPath, allAttributeFilesList, simrankC, numThreads);
		gr.run();
		gr.initMatrix();
		List<List<String>> lineGraphNodes = gr.getLineGraphNodes();
		int[][] incidenceMatrix = gr.getAdjacencyMatrix();
		float[][] topologyMatrix = gr.getSimrankMatrix();
		float[][][] attributeMatrix = gr.getAttributeMatrix();
		int numVertices = lineGraphNodes.size();
		long t2 = System.currentTimeMillis();
		logger.info("Initial input matrix cost: " + (t2 - t1) / (float)1000 + "s");

		for (int i = 1; i <= numExecutions; i++) {
			System.out.println();
			logger.info("正在执行第" + i + "次...");

			float[][] initMatrixR = MatrixFactory.generateNormalizedMatrixWithConstraints(numVertices, allAttributeFilesList.size(), 0.0F, 1.0F);
			float[][] initMatrixW = MatrixFactory.generateConstrainedMatrix(numVertices, numVertices, 0.0F, 1.0F);
			ParrallelDCAPImpl dcap = new ParrallelDCAPImpl(initMatrixR, initMatrixW, incidenceMatrix, attributeMatrix, topologyMatrix,
					this.alpha, this.beta, this.theta, this.phi, this.maxChange, this.maxLoops, this.numThreads, this.saveFolder);
			dcap.run();

			String matrixFolder = "cluster_result_" + i + "/";
			File matrixFolderFile = new File(this.graphDataPath + matrixFolder);
			if (!matrixFolderFile.exists()) {
				matrixFolderFile.mkdirs();
			}
			GraphTool.saveMatrix(dcap.getMatrixW(), this.graphDataPath, matrixFolder + "cluster_matrix");
			ProcessCluster p = new ProcessCluster(this.graphDataPath, dcap.getMatrixW(), gr);
			p.run(matrixFolder);
		}
	}
}