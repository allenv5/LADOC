package cn.edu.whut.ladoc.experiment.toydata;

import cn.edu.whut.ladoc.SharedLibrary;
import org.apache.log4j.Logger;

public class MatlabInputFileGenerator {
	public static Logger logger = Logger.getLogger(MatlabInputFileGenerator.class);

	public static String MatrixDelimiter = "\t";

	public static void generateMatrixFile(float[][] matrix, String file) {
		String content = "";
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < (matrix[i]).length; j++)
				content = String.valueOf(content) + ((j == 0) ? "" : MatrixDelimiter) + matrix[i][j];
			content = String.valueOf(content) + "\n";
		}
		SharedLibrary.saveToFile(content, file);
	}
}
