package cn.edu.whut.ladoc.experiment.toydata;

import cn.edu.whut.ladoc.impl.DataAdapter;
import cn.edu.whut.ladoc.SharedLibrary;
import org.apache.log4j.Logger;

import java.io.File;

public class ToyDataWithDCAPExperiment {
	public static Logger logger = Logger.getLogger(ToyDataWithDCAPExperiment.class);

	private String graphDataPath;
	private float alpha;
	private float beta;
	private float theta;
	private float phi;
	private float maxChange;
	private float minAttributeSimilarity;
	private float minTopologyWeight;
	private float minWeight;
	private int numAttributes;
	private int maxLoops;
	private int minSize;
	private String saveFolder;
	private boolean isAnd;

	public ToyDataWithDCAPExperiment(String graphDataPath, int numAttributes, float alpha, float beta, float theta, float phi, float maxChange, float minAttributeSimilarity, float minTopologyWeight, int maxLoops, int minSize, String saveFolder, float minWeight, boolean isAnd) {
		this.graphDataPath = graphDataPath;
		this.numAttributes = numAttributes;
		this.alpha = alpha;
		this.beta = beta;
		this.theta = theta;
		this.phi = phi;
		this.maxChange = maxChange;
		this.minAttributeSimilarity = minAttributeSimilarity;
		this.minTopologyWeight = minTopologyWeight;
		this.maxLoops = maxLoops;
		this.minSize = 2;
		this.saveFolder = saveFolder;
		this.minWeight = minWeight;
		this.isAnd = isAnd;
	}

	public void run() {
		throw new Error("Unresolved compilation problem: \n\tThe method saveClusteringResult(Set<Set<String>>, String, String) in the type SharedLibrary is not applicable for the arguments (Set<Set<String>>, String)\n");
	}

	private void matlab(DataAdapter adapter, float[][] matrixR) {
		String folder = String.valueOf(this.saveFolder) + File.separator + "matlab";
		SharedLibrary.createFolder(folder);
		float[][][] attributeMatrices = adapter.getAttributeWeightMatrix();
		for (int i = 0; i < attributeMatrices.length; i++) {
			float[][] attributeMatrix = attributeMatrices[i];
			String str = String.valueOf(folder) + File.separator + "attribute-" + (i + 1);
			MatlabInputFileGenerator.generateMatrixFile(attributeMatrix, str);
		}
		String file = String.valueOf(folder) + File.separator + "matrix-r";
		MatlabInputFileGenerator.generateMatrixFile(matrixR, file);
	}

	public static void main(String[] args) {
		String folder = "E:\\Research\\Raw Data\\Toy Data\\Model-based AGC\\Multiple Attributes\\dcap";
		int numClusters = 4, minValues = 6, maxValues = 8, minVertices = 20, maxVertices = 30;
		String graphFolder = String.valueOf(folder) + File.separator + numClusters + "-" +
				minValues + "-" + maxValues + "-" + minVertices + "-" +
				maxVertices;
		int numAttributes = 5;
		float alpha = 1.0F;
		float beta = 1.0F;
		float phi = 1.0F;
		float theta = 1.0F;
		float maxChange = 0.1F;
		float minAttributeSimilarity = 0.0F;
		float minTopologyWeight = 0.0F;
		int maxLoops = 1000;
		int minSize = 2;
		String saveFolder = graphFolder;
		float minWeight = 0.5F;
		boolean isAnd = true;
		ToyDataWithDCAPExperiment experiment = new ToyDataWithDCAPExperiment(
				graphFolder, numAttributes, alpha, beta, theta, phi, maxChange,
				minAttributeSimilarity, minTopologyWeight, maxLoops, minSize, saveFolder,
				minWeight, isAnd);
		experiment.run();
	}
}
