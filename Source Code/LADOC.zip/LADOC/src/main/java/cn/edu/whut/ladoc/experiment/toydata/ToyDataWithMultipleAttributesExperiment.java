package cn.edu.whut.ladoc.experiment.toydata;

import org.apache.log4j.Logger;

import java.io.File;

public class ToyDataWithMultipleAttributesExperiment {
	public static Logger logger = Logger.getLogger(ToyDataWithMultipleAttributesExperiment.class);
	private String graphDataPath;
	private float alpha;
	private float beta;
	private float theta;
	private float phi;
	private float maxChange;
	private float minAttributeSimilarity;
	private float minTopologyWeight;
	private int numAttributes;
	private int maxLoops;
	private int minSize;
	private String saveFolder;

	public ToyDataWithMultipleAttributesExperiment(String graphDataPath, int numAttributes, float alpha, float beta, float theta, float phi, float maxChange, float minAttributeSimilarity, float minTopologyWeight, int maxLoops, int minSize, String saveFolder) {
		this.graphDataPath = graphDataPath;
		this.numAttributes = numAttributes;
		this.alpha = alpha;
		this.beta = beta;
		this.theta = theta;
		this.phi = phi;
		this.maxChange = maxChange;
		this.minAttributeSimilarity = minAttributeSimilarity;
		this.minTopologyWeight = minTopologyWeight;
		this.maxLoops = maxLoops;
		this.minSize = 2;
		this.saveFolder = saveFolder;
	}

	public void run() {
		throw new Error("Unresolved compilation problem: \n\tThe method saveClusteringResult(Set<Set<String>>, String, String) in the type SharedLibrary is not applicable for the arguments (Set<Set<String>>, String)\n");
	}

	public static void main(String[] args) {
		String folder = "E:\\Research\\Raw Data\\Toy Data\\Model-based AGC\\Multiple Attributes";
		int numClusters = 4, minValues = 6, maxValues = 8, minVertices = 20, maxVertices = 30;
		String graphFolder = String.valueOf(folder) + File.separator + numClusters + "-" +
				minValues + "-" + maxValues + "-" + minVertices + "-" +
				maxVertices;
		int numAttributes = 5;
		float alpha = 1.0F;
		float beta = 1.0F;
		float theta = 1.0F;
		float phi = 1.0F;
		float maxChange = 0.01F;
		float minAttributeSimilarity = 0.6F;
		float minTopologyWeight = 0.8F;
		int maxLoops = 1000;
		int minSize = 2;
		String saveFolder = graphFolder;
		ToyDataWithMultipleAttributesExperiment experiment = new ToyDataWithMultipleAttributesExperiment(
				graphFolder, numAttributes, alpha, beta, theta, phi, maxChange,
				minAttributeSimilarity, minTopologyWeight, maxLoops, minSize, saveFolder);
		experiment.run();
	}
}
