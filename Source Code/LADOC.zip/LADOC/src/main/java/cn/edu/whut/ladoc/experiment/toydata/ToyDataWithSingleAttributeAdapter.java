package cn.edu.whut.ladoc.experiment.toydata;

import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ToyDataWithSingleAttributeAdapter {
	public static Logger logger = Logger.getLogger(ToyDataWithSingleAttributeAdapter.class);
	private String vertexFile;
	private String edgeFile;
	private int numOfVertices;
	private int numOfValues;
	private int[][] incidenceMatrix;
	private int[][] valueMatrix;
	private float[][][] weightMatrix;
	private Map<String, Integer> vertexIdMap;
	private float minSimilarity;

	public ToyDataWithSingleAttributeAdapter(String vertexFile, String edgeFile, int numOfVertices, int numOfValues, float minSimilarity) {
		this.vertexFile = vertexFile;
		this.edgeFile = edgeFile;
		this.numOfVertices = numOfVertices;
		this.numOfValues = numOfValues;
		this.minSimilarity = minSimilarity;
	}

	public void run() {
		readVertexFile();
		readEdgeFile();
		setWeightMatrix();
	}

	private void setWeightMatrix() {
		this.weightMatrix = new float[1][this.numOfVertices][];
		for (int i = 0; i < (this.weightMatrix[0]).length; i++) {
			this.weightMatrix[0][i] = new float[this.numOfVertices];
			for (int j = 0; j < this.numOfVertices; j++)
				this.weightMatrix[0][i][j] = getJaccardSimilarity(i, j) - this.minSimilarity;
		}
	}

	private float getJaccardSimilarity(int i, int j) {
		int common = 0, total = 0;
		for (int k = 0; k < this.numOfValues; k++) {
			if (this.valueMatrix[i][k] == 1 ||
					this.valueMatrix[j][k] == 1)
				total++;
			if (this.valueMatrix[i][k] == 1 &&
					this.valueMatrix[j][k] == 1)
				common++;
		}
		return common / total;
	}

	public int[][] getIncidenceMatrix() {
		return this.incidenceMatrix;
	}

	public float[][][] getWeightMatrix() {
		return this.weightMatrix;
	}

	public Map<Integer, String> getId2VertexMap() {
		Map<Integer, String> id2VertexMap = new HashMap<Integer, String>();
		for (String vertex : this.vertexIdMap.keySet()) {
			int id = ((Integer)this.vertexIdMap.get(vertex)).intValue();
			String prevVal = id2VertexMap.put(Integer.valueOf(id), vertex);
			if (prevVal != null)
				logger.error("Previous Value was found for id [" + id + "]: " + prevVal);
		}
		return id2VertexMap;
	}

	private void readEdgeFile() {
		BufferedReader br = null;
		this.incidenceMatrix = new int[this.numOfVertices][this.numOfVertices];
		try {
			br = new BufferedReader(new FileReader(this.edgeFile));
			String line;
			while ((line = br.readLine()) != null) {
				String[] items = line.split("\t");
				if (items.length != 3) {
					logger.error("This line is not well formatted: " + line);
					continue;
				}
				int vertex = ((Integer)this.vertexIdMap.get(items[1])).intValue();
				int anotherVertex = ((Integer)this.vertexIdMap.get(items[2])).intValue();
				this.incidenceMatrix[vertex][anotherVertex] = 1;
				this.incidenceMatrix[anotherVertex][vertex] = 1;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void readVertexFile() {
		this.vertexIdMap = new HashMap<String, Integer>();
		this.valueMatrix = new int[this.numOfVertices][];
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(this.vertexFile));
			int vertexIndex = 0;
			String line;
			while ((line = br.readLine()) != null) {
				String[] items = line.split("\t");
				if (items.length != 3) {
					logger.error("This line is not well formatted: " + line);
					continue;
				}
				this.vertexIdMap.put(items[1], Integer.valueOf(vertexIndex));
				this.valueMatrix[vertexIndex] = new int[this.numOfValues];
				String[] vals = items[2].split(",");
				byte b;
				int i;
				String[] arrayOfString1;
				for (i = (arrayOfString1 = vals).length, b = 0; b < i; ) {
					String val = arrayOfString1[b];
					this.valueMatrix[vertexIndex][Integer.valueOf(val).intValue() - 1] = 1;
					b++;
				}
				vertexIndex++;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
