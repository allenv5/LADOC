package cn.edu.whut.ladoc.experiment.toydata;

import org.apache.log4j.Logger;

public class ToyDataWithSingleAttributeExperiment {
	public static Logger logger = Logger.getLogger(ToyDataWithSingleAttributeExperiment.class);
	private String graphDataPath;
	int numOfVertices;
	int numOfValues;
	private float alpha;
	private float beta;
	private float theta;
	private float phi;
	private float maxChange;
	private float minAttributeSimilarity;
	private float minTopologyWeight;
	private int maxLoops;
	private int minSize;
	private String saveFolder;

	public ToyDataWithSingleAttributeExperiment(String graphDataPath, int numOfVertices, int numOfValues, float alpha, float beta, float theta, float phi, float maxChange, float minAttributeSimilarity, float minTopologyWeight, int maxLoops, int minSize, String saveFolder) {
		this.graphDataPath = graphDataPath;
		this.numOfVertices = numOfVertices;
		this.numOfValues = numOfValues;
		this.alpha = alpha;
		this.beta = beta;
		this.theta = theta;
		this.phi = phi;
		this.maxChange = maxChange;
		this.minAttributeSimilarity = minAttributeSimilarity;
		this.minTopologyWeight = minTopologyWeight;
		this.maxLoops = maxLoops;
		this.minSize = 2;
		this.saveFolder = saveFolder;
	}

	public void run() {
		throw new Error("Unresolved compilation problem: \n\tThe method saveClusteringResult(Set<Set<String>>, String, String) in the type SharedLibrary is not applicable for the arguments (Set<Set<String>>, String)\n");
	}

	public static void main(String[] args) {
		String graphDataPath = "E:\\Research\\Raw Data\\Toy Data\\Model-based AGC\\Single Attribute";
		int numOfVertices = 115;
		int numOfValues = 18;
		float alpha = 1.0F;
		float beta = 1.0F;
		float theta = 1.0F;
		float phi = 1.0F;
		float maxChange = 0.001F;
		float minAttributeSimilarity = 0.5F;
		float minTopologyWeight = 0.5F;
		int maxLoops = 700;
		int minSize = 2;
		String saveFolder = graphDataPath;
		ToyDataWithSingleAttributeExperiment experiment = new ToyDataWithSingleAttributeExperiment(
				graphDataPath, numOfVertices, numOfValues, alpha, beta, theta,
				phi, maxChange, minAttributeSimilarity, minTopologyWeight, maxLoops, minSize, saveFolder);
		experiment.run();
	}
}
