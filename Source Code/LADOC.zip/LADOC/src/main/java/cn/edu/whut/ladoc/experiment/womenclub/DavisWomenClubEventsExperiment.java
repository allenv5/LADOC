package cn.edu.whut.ladoc.experiment.womenclub;

import cn.edu.whut.ladoc.SharedLibrary;
import org.apache.log4j.Logger;

import java.io.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class DavisWomenClubEventsExperiment {
	public static Logger logger = Logger.getLogger(DavisWomenClubEventsExperiment.class);
	private String workingDir;
	private String vertexFile;
	private String edgeFile;
	private String attributeFilePrefix;
	private String saveFolder;
	private int numAttributes;
	private int maxLoops;
	private int minClusterSize;
	private float minAttributeSimilarity;
	private float minTopologyWeight;
	private float alpha;
	private float beta;
	private float theta;
	private float phi;
	private float maxChange;

	public DavisWomenClubEventsExperiment(String workingDir, String vertexFile, String edgeFile, String attributeFilePrefix, int numAttributes, float minAttributeSimilarity, float minTopologyWeight, float alpha, float beta, float theta, float phi, float maxChange, int maxLoops, int minClusterSize, String saveFolder) {
		this.workingDir = workingDir;
		this.vertexFile = vertexFile;
		this.edgeFile = edgeFile;
		this.attributeFilePrefix = attributeFilePrefix;
		this.numAttributes = numAttributes;
		this.minAttributeSimilarity = minAttributeSimilarity;
		this.minTopologyWeight = minTopologyWeight;
		this.alpha = alpha;
		this.beta = beta;
		this.theta = theta;
		this.phi = phi;
		this.maxChange = maxChange;
		this.maxLoops = maxLoops;
		this.minClusterSize = minClusterSize;
		this.saveFolder = saveFolder;
	}

	public static void createEdgeFile(String oriDataFile, String edgeFile, int numVertices, int minCommonAttributes) {
		Map<String, Set<String>> attributeMap = new HashMap<String, Set<String>>();
		String[] vertexArray = new String[numVertices];
		BufferedReader br = null;
		int vertexIdx = 0;
		try {
			br = new BufferedReader(new FileReader(oriDataFile));
			String line;
			while ((line = br.readLine()) != null) {
				String[] items = line.split(",");
				if (line.startsWith("v")) {
					vertexArray[vertexIdx++] = items[1];
					attributeMap.put(items[1], new HashSet<String>());
					continue;
				}
				if (line.startsWith("e")) {
					String vertex = vertexArray[vertexIdx++ - numVertices];
					for (int j = 1; j < items.length; j++) {
						if (items[j].equals("1"))
							((Set<String>)attributeMap.get(vertex)).add(String.valueOf(j));
					}
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String content = "";
		for (int i = 0; i < vertexArray.length - 1; i++) {
			for (int j = i + 1; j < vertexArray.length; j++) {
				int commonAttributes = 0;
				for (String val_i : attributeMap.get(vertexArray[i])) {
					if (((Set)attributeMap.get(vertexArray[j])).contains(val_i))
						commonAttributes++;
				}
				if (commonAttributes >= minCommonAttributes)
					content = String.valueOf(content) + ((content.length() > 0) ? "\n" : "") +
							vertexArray[i] + "\t" + vertexArray[j];
			}
		}
		SharedLibrary.saveToFile(content, edgeFile);
	}

	public void run() {
		throw new Error("Unresolved compilation problem: \n\tThe method saveClusteringResult(Set<Set<String>>, String, String) in the type SharedLibrary is not applicable for the arguments (Set<Set<String>>, String)\n");
	}

	public static void main(String[] args) {
		String workingDir = "C:\\Users\\Allen Hu\\Dropbox\\Research\\Working\\Graph Clustering\\Multi-attribute\\Model-based AGC\\Experiments\\Davis Women Club Events\\Original Data";
		String vertexFile = "vertex";
		String edgeFile = "edge";
		String attributeFilePrefix = "attribute-";
		int numAttributes = 12;
		float alpha = 1.0F;
		float beta = 1.0F;
		float theta = 1.0F;
		float phi = 1.0F;
		float maxChange = 0.01F;
		float minAttributeSimilarity = 0.5F;
		float minTopologyWeight = 0.5F;
		int maxLoops = 500;
		int minClusterSize = 2;
		String saveFolder = workingDir;
		String oriDataFile = "C:\\Users\\Allen Hu\\Dropbox\\Research\\Data\\Davis Women Club Events\\data.txt";
		String edgePath = String.valueOf(workingDir) + File.separator + edgeFile;
		int numVertices = 18, minCommonAttributes = 3;
		createEdgeFile(oriDataFile, edgePath, numVertices, minCommonAttributes);
		DavisWomenClubEventsExperiment experiment = new DavisWomenClubEventsExperiment(workingDir, vertexFile,
				edgeFile, attributeFilePrefix, numAttributes,
				minAttributeSimilarity, minTopologyWeight, alpha, beta, theta,
				phi, maxChange, maxLoops, minClusterSize, saveFolder);
		experiment.run();
	}
}
