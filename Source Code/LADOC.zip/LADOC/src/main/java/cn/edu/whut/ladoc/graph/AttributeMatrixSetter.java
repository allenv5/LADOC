package cn.edu.whut.ladoc.graph;

import cn.edu.whut.ladoc.similarity.SimilarityMeasure;
import cn.edu.whut.ladoc.similarity.SimpleAndSimilatiryMeasure;

import java.util.*;

public class AttributeMatrixSetter {

	private final Map<Integer, Map<String, Set<String>>> allAttributeMap;
	private final List<List<String>> lineGraphNodes;
	float[][][] attributeMatrix;
	boolean useMultiThread;
	SimilarityMeasure sim;

	public AttributeMatrixSetter(Map<Integer, Map<String, Set<String>>> map, List<List<String>> lineGraphNodes, boolean useMultiThread) {
		this.allAttributeMap = map;
		this.lineGraphNodes = lineGraphNodes;
		this.useMultiThread = useMultiThread;
		this.sim = new SimpleAndSimilatiryMeasure();
		this.attributeMatrix = new float[this.allAttributeMap.size()][this.lineGraphNodes.size()][this.lineGraphNodes.size()];
	}

	public void set() {
		if (!useMultiThread) {
			for (int i = 0; i < this.allAttributeMap.size(); i++) {
				ThreadSetter ts = new ThreadSetter(i);
				ts.run();
			}
			return;
		}

		List<Thread> threads = new ArrayList<>();
		for (int i = 0; i < this.allAttributeMap.size(); i++) {
			Runnable run = new ThreadSetter(i);
			threads.add(new Thread(run));
		}
		threads.forEach(Thread::start);
		threads.forEach(thread -> {
			try {
				thread.join();
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	public float[][][] getAttributeMatrix() {
		return this.attributeMatrix;
	}

	class ThreadSetter implements Runnable {
		private final int N;

		public ThreadSetter(int N) {
			this.N = N;
		}

		@Override
		public void run() {
			for (int i = 0; i < lineGraphNodes.size(); i++) {
				for (int j = i; j < lineGraphNodes.size(); j++) {
					attributeMatrix[N][i][j] = getSimilarityScore(i, j);
					attributeMatrix[N][j][i] = attributeMatrix[N][i][j];
				}
			}
		}

		private float getSimilarityScore(int i, int j) {
			List<String> lineGraphNodeI = lineGraphNodes.get(i);
			List<String> lineGraphNodeJ = lineGraphNodes.get(j);
			Set<String> attributeI = new HashSet<>();
			Set<String> attributeJ = new HashSet<>();
			for (String v : lineGraphNodeI) {
				Set<String> set = allAttributeMap.get(N).get(v);
				if (set == null) continue;
				attributeI.addAll(set);
			}
			for (String v : lineGraphNodeJ) {
				Set<String> set = allAttributeMap.get(N).get(v);
				if (set == null) continue;
				attributeJ.addAll(set);
			}
			// return sim.compute(attributeI, attributeJ);
			int total = attributeI.size(), overlap = 0;
			for (String attr : attributeJ) {
				if (attributeI.contains(attr)) {
					overlap++;
					continue;
				}
				total++;
			}
			return total == 0 ? 0 : overlap / (float) total;
		}
	}
}
