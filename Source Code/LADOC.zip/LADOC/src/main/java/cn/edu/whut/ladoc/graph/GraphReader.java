package cn.edu.whut.ladoc.graph;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;

public class GraphReader {
	private final String rootFolder;
	private final List<String> attributeList;

	private final String ppiFile = "ppis";
	private static String edgeLinkFile = "edge_link";
	private static String edgeNodeFile = "edge_node";
	private static String simrankResultFile = "nodesim_naive";

	private final List<List<String>> lineGraphNodes = new ArrayList<>();
	private final Set<Set<List<String>>> lineGraphEdges = new HashSet<>();
	private final Map<List<String>, Set<List<String>>> lineGraphAdjacencyMap = new HashMap<>();
	private final Map<Integer, Map<String, Set<String>>> allAttributeMap = new HashMap<>();
	private final Set<String> vertexSet = new HashSet<>();

	private int[][] adjacencyMatrix;
	private float[][] topologyMatrix;
	private float[][] simrankMatrix;
	private float[][][] attributeMatrix;
	private int numThreads;
	private float simrankC;

	public GraphReader(String rootFolder, List<String> attributeList) {
		this.rootFolder = rootFolder;
		this.attributeList = attributeList;
	}

	public GraphReader(String rootFolder, List<String> attributeList, float simrankC, int numThreads) {
		this.rootFolder = rootFolder;
		this.attributeList = attributeList;
		this.simrankC = simrankC;
		this.numThreads = numThreads;
	}

	public void run() {
		long t1 = System.currentTimeMillis();
		this.constructGraph(rootFolder + ppiFile);
		this.setLineGraphEdges();
		long t2 = System.currentTimeMillis();
		// System.out.println("cost: " + (t2 - t1) / (float)1000 + "s");
	}

	public void initMatrix() {
		this.setAllAttributeMap();
		this.setTopologyMatrix();   // matrix D
		this.setAttributeMatrix();  // matrix S
		this.setSimrankMatrix();    // matrix D (Simrank)
	}

	// 从ppis文件中获取lineGraph的节点信息
	private void constructGraph(String graphFile) {
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(graphFile));
			String line;
			while ((line = br.readLine()) != null) {
				String[] vals = line.split("\t");
				if (vals.length == 2) {
					this.lineGraphNodes.add(new ArrayList<>(Arrays.asList(vals)));
				}
				this.vertexSet.addAll(Arrays.asList(vals));
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 根据节点获取lineGraph边的信息
	private void setLineGraphEdges() {
		this.adjacencyMatrix = new int[this.lineGraphNodes.size()][this.lineGraphNodes.size()];
		for (int i = 0; i < this.lineGraphNodes.size(); i++) {
			List<String> l1 = this.lineGraphNodes.get(i);
			Set<List<String>> adjacencyNodes = new HashSet<>();
			for (int j = i + 1; j < this.lineGraphNodes.size(); j++) {
				List<String> l2 = this.lineGraphNodes.get(j);
				if (this.isEdge(l1, l2)) {
					adjacencyNodes.add(l2);
					this.adjacencyMatrix[i][j] = 1;
					this.adjacencyMatrix[j][i] = 1;
					Set<List<String>> edge = new HashSet<>();
					edge.add(l1);
					edge.add(l2);
					this.lineGraphEdges.add(edge);
				}
			}
			this.lineGraphAdjacencyMap.put(l1, adjacencyNodes);
		}
	}

	private void setAllAttributeMap() {
		this.attributeMatrix = new float[this.lineGraphNodes.size()][this.lineGraphNodes.size()][this.attributeList.size()];
		BufferedReader br;
		for (int i = 0; i < this.attributeList.size(); i++) {
			Map<String, Set<String>> attributeMap = new HashMap<>();
			try {
				br = new BufferedReader(new FileReader(this.rootFolder + this.attributeList.get(i)));
				String line;
				while ((line = br.readLine()) != null) {
					String[] vals = line.split("\t");
					if (vals.length < 2) {
						attributeMap.put(vals[0], null);
						continue;
					}
					String[] attrs = vals[1].split(",");
					attributeMap.put(vals[0], new HashSet<>(Arrays.asList(attrs)));
				}
				allAttributeMap.put(i, attributeMap);
				br.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private boolean isEdge(List<String> l1, List<String> l2) {
		int total = l1.size();
		for (String v : l2) {
			if (!l1.contains(v)) {
				total++;
			}
		}
		return total == 3;
	}

	private void setTopologyMatrix() {
		this.topologyMatrix = new float[this.lineGraphNodes.size()][this.lineGraphNodes.size()];
		for (int i = 0; i < this.lineGraphNodes.size(); i++) {
			for (int j = i; j < this.lineGraphNodes.size(); j++) {
				if (i == j) {
					this.topologyMatrix[i][j] = 0;
					continue;
				}
				Set<List<String>> adjacencyNodesI = this.lineGraphAdjacencyMap.get(this.lineGraphNodes.get(i));
				Set<List<String>> adjacencyNodesJ = this.lineGraphAdjacencyMap.get(this.lineGraphNodes.get(j));
				this.topologyMatrix[i][j] = this.getSimilarityScore(adjacencyNodesI, adjacencyNodesJ);
				this.topologyMatrix[j][i] = this.topologyMatrix[i][j];
			}
		}
	}

	private float getSimilarityScore(Set<List<String>> s1, Set<List<String>> s2) {
		int total = s1.size(), overlap = 0;
		for (List<String> list : s2) {
			if (s1.contains(list)) {
				overlap++;
				continue;
			}
			total++;
		}
		return total == 0 ? 0 : overlap / (float)total;
	}

	private void setSimrankMatrix() {
		this.simrankMatrix = new float[this.lineGraphNodes.size()][this.lineGraphNodes.size()];
		for (int i = 0; i < this.lineGraphNodes.size(); i++) {
			for (int j = i; j < this.lineGraphNodes.size(); j++) {
				float score = getSimrankScore(i, j);
				this.simrankMatrix[i][j] = score;
				this.simrankMatrix[j][i] = score;
			}
		}
	}

	private float getSimrankScore(int i, int j) {
		if (i == j) {
			return 1;
		}
		Set<List<String>> adjacencyNodesI = this.lineGraphAdjacencyMap.get(this.lineGraphNodes.get(i));
		Set<List<String>> adjacencyNodesJ = this.lineGraphAdjacencyMap.get(this.lineGraphNodes.get(j));
		if (adjacencyNodesI.size() == 0 || adjacencyNodesJ.size() == 0) {
			return 0;
		}
		float sum = 0f;
		for (List<String> l1 : adjacencyNodesI) {
			for (List<String> l2 : adjacencyNodesJ) {
				if (this.isEdge(l1, l2)) {
					sum += 1 / (float)(adjacencyNodesI.size() * adjacencyNodesJ.size());
				}
			}
		}
		return sum;
	}

	private void setAttributeMatrix() {
		AttributeMatrixSetter setter = new AttributeMatrixSetter(this.allAttributeMap, this.lineGraphNodes, true);
		setter.set();
		this.attributeMatrix = setter.getAttributeMatrix();
	}

	public float[][] getSimrankMatrix() {
		LinkGraphSimrankSetter s = new LinkGraphSimrankSetter(this.adjacencyMatrix, this.lineGraphNodes, this.lineGraphAdjacencyMap, this.simrankC, this.numThreads);
		s.init();
		s.run();
		return s.getSimrankMatrix();
	}

	public int[][] getAdjacencyMatrix() {
		return this.adjacencyMatrix;
	}

	public float[][] getTopologyMatrix() {
		return this.topologyMatrix;
	}

	// public float[][] getSimrankMatrix() {
	// 	return this.simrankMatrix;
	// }

	public float[][][] getAttributeMatrix() {
		return this.attributeMatrix;
	}

	public List<List<String>> getLineGraphNodes() {
		return this.lineGraphNodes;
	}

	public Set<Set<List<String>>> getLineGraphEdges() {
		return this.lineGraphEdges;
	}

	public Set<String> getVertexSet() {
		return this.vertexSet;
	}

	public Map<List<String>, Set<List<String>>> getLineGraphAdjacencyMap() {
		return this.lineGraphAdjacencyMap;
	}
}
