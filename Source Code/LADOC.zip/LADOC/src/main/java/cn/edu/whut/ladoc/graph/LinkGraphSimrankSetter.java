package cn.edu.whut.ladoc.graph;

import java.util.*;

public class LinkGraphSimrankSetter {

	private int[][] adjacencyMatrix;
	private List<List<String>> lineGraphNodes;
	private Map<List<String>, Set<List<String>>> lineGraphAdjacencyMap;
	private int numThreads;
	private float C;
	private Map<List<String>, Integer> node2IdMap;

	private float[][] querySim;
	private float[][] newQeurySim;
	private float[][] simrankMatrix;

	public LinkGraphSimrankSetter(int[][] adjacencyMatrix, List<List<String>> lineGraphNodes, Map<List<String>, Set<List<String>>> lineGraphAdjacencyMap, float C, int numThreads) {
		this.adjacencyMatrix = adjacencyMatrix;
		this.lineGraphNodes = lineGraphNodes;
		this.lineGraphAdjacencyMap = lineGraphAdjacencyMap;
		this.C = C;
		this.numThreads = numThreads;
	}

	public static void main(String[] args) {
		test();
	}

	public static void test() {

		String rootFolder = "data/dataset/Demo/";
		int numThread = 12;
		List<String> attrs = new ArrayList<>();
		Collections.addAll(attrs, "attribute-1", "attribute-2", "attribute-3");
		GraphReader gr = new GraphReader(rootFolder, attrs);
		gr.run();
		int[][] adjacencyMatrix = gr.getAdjacencyMatrix();
		List<List<String>> lineGraphNodes = gr.getLineGraphNodes();
		Map<List<String>, Set<List<String>>> lineGraphAdjacencyMap = gr.getLineGraphAdjacencyMap();
		LinkGraphSimrankSetter s = new LinkGraphSimrankSetter(adjacencyMatrix, lineGraphNodes, lineGraphAdjacencyMap, 0.8f, numThread);
		s.init();
		long t1 = System.currentTimeMillis();
		for (int i = 0; i < 10; i++) {
			s.run();
		}
		long t2 = System.currentTimeMillis();
		// System.out.println("Cost: " + (t2 - t1) / (float)1000 + "s");
		System.out.println();
	}

	public void init() {
		querySim = new float[lineGraphNodes.size()][lineGraphNodes.size()];
		for (int i1 = 0; i1 < lineGraphNodes.size(); i1++) {
			querySim[i1][i1] = 1;
		}

		this.node2IdMap = new HashMap<>();
		for (int i = 0; i < this.lineGraphNodes.size(); i++) {
			node2IdMap.put(this.lineGraphNodes.get(i), i);
		}
	}

	public void run() {
		newQeurySim = new float[lineGraphNodes.size()][lineGraphNodes.size()];
		for (int i1 = 0; i1 < lineGraphNodes.size(); i1++) {
			newQeurySim[i1][i1] = 1;
		}
		int[][] threadSlots = getThreadSlots(this.lineGraphNodes.size());
		List<Thread> threads = new ArrayList<>();

		for (int i = 0; i < threadSlots.length; i++) {
			int beginIndex = threadSlots[i][0];
			int endIndex = threadSlots[i][1];

			Runnable run = new ThreadSetter(beginIndex, endIndex);
			threads.add(new Thread(run));
		}

		threads.forEach(thread -> thread.start());
		threads.forEach(thread -> {
			try {
				thread.join();
			} catch (Exception e) {
				e.printStackTrace();
			}
		});

		querySim = newQeurySim;
	}

	public float[][] getSimrankMatrix() {
		return this.querySim;
	}

	class ThreadSetter implements Runnable {
		private int beginIdx;
		private int endIdx;

		public ThreadSetter(int beginIdx, int endIdx) {
			this.beginIdx = beginIdx;
			this.endIdx = endIdx;
		}

		public float querySimrank(int i, int j, float C) {
			if (i == j) return 1;
			List<String> node1 = lineGraphNodes.get(i);
			List<String> node2 = lineGraphNodes.get(j);

			Set<List<String>> adjacencyNodes1 = lineGraphAdjacencyMap.get(node1);
			if (adjacencyNodes1.size() == 0) {
				return 0;
			}
			Set<List<String>> adjacencyNodes2 = lineGraphAdjacencyMap.get(node2);
			if (adjacencyNodes2.size() == 0) {
				return 0;
			}

			float prefix = C / (adjacencyNodes1.size() * adjacencyNodes2.size());
			float postfix = 0;

			for (List<String> n1 : adjacencyNodes1) {
				for (List<String> n2 : adjacencyNodes2) {
					int idx1 = node2IdMap.get(n1);
					int idx2 = node2IdMap.get(n2);
					postfix += querySim[idx1][idx2];
				}
			}
			return prefix * postfix;
		}

		private void simrank(int beginIdx, int endIdx, float C) {

			for (int i = beginIdx; i < endIdx; i++) {
				for (int j = i; j < lineGraphNodes.size(); j++) {
					newQeurySim[i][j] = querySimrank(i, j, C);
					newQeurySim[j][i] = newQeurySim[i][j];
				}
			}
		}

		@Override
		public void run() {
			simrank(this.beginIdx, this.endIdx, C);
		}
	}

	private int[][] getThreadSlots(int numInstances) {
		// TODO Auto-generated method stub
		int[][] threadSlots;

		if (numInstances <= this.numThreads) {
			threadSlots = new int[numInstances][2];

			for (int i = 0; i < numInstances; i++) {
				threadSlots[i][0] = i;
				threadSlots[i][1] = i + 1;
			}
		} else {
			threadSlots = new int[this.numThreads][2];
			// int numItemsInEachThread = Math.round(numInstances / this.numThreads);
			int numItemsInEachThread = numInstances / this.numThreads;
			int remainder = numInstances - numItemsInEachThread * this.numThreads;

			// setup thread pool
			for (int i = 0; i < this.numThreads; i++) {
				int extra = i < remainder ? i : remainder;
				int beginIndex = numItemsInEachThread * i + extra;
				int increment = numItemsInEachThread + (i < remainder ? 1 : 0);
				int endIndex = i == this.numThreads - 1 ? numInstances : (beginIndex + increment);

				threadSlots[i][0] = beginIndex;
				threadSlots[i][1] = endIndex;
			}
		}

		return threadSlots;
	}

}
