package cn.edu.whut.ladoc.graph;

import cn.edu.whut.evaluate.FMeasureMatch;
import cn.edu.whut.tools.GraphTool;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.math.BigDecimal;
import java.util.*;

/*
 * 2021-04-20
 * 不需要K了
 */

public class ProcessCluster {

	private String rootFolder;
	private String clusterMatrixFile;
	private String matrixFolder;

	private float[][] clusterMatrix;
	private List<List<String>> lineGraphNodes;
	private Set<Set<List<String>>> lineGraphEdges;

	private GraphReader gr;
	private Map<Set<List<String>>, Float> lineGraphEdgeWeight;
	private List<Map.Entry<Set<List<String>>, Float>> list;

	private Set<Set<String>> allClusters;
	private Set<List<String>> accessedEdges;

	private StringBuffer processClusterINFO;

	public ProcessCluster(String rootFolder, String clusterMatrixFile, GraphReader gr) {
		this.rootFolder = rootFolder;
		this.clusterMatrixFile = clusterMatrixFile;
		this.gr = gr;
	}

	public ProcessCluster(String rootFolder, float[][] clusterMatrix, GraphReader gr) {
		this.rootFolder = rootFolder;
		this.clusterMatrix = clusterMatrix;
		this.gr = gr;
	}

	public static void main(String[] args) {
		String rootFolder = "data/dataset/Homo/";
		String matrixFolder = "matrix/";
		String clusterMatrixFile = rootFolder + matrixFolder + "cluster_matrix";
		List<String> attrs = GraphTool.getAllAttributeFilesName(rootFolder);
		GraphReader gr = new GraphReader(rootFolder, attrs);
		gr.run();
		float[][] clusterMatrix = GraphTool.readMatrix(gr.getLineGraphNodes().size(), clusterMatrixFile);
		ProcessCluster p = new ProcessCluster(rootFolder, clusterMatrix, gr);
		p.run(matrixFolder);
	}

	private void init() {
		if (this.clusterMatrix == null) {
			this.clusterMatrix = GraphTool.readMatrix(this.gr.getLineGraphNodes().size(), this.clusterMatrixFile);
		}
		this.lineGraphNodes = gr.getLineGraphNodes();
		this.lineGraphEdges = gr.getLineGraphEdges();
		this.lineGraphEdgeWeight = new HashMap<>();
		this.processClusterINFO = new StringBuffer();

		for (int i = 0; i < this.lineGraphNodes.size(); i++) {
			for (int j = i; j < this.lineGraphNodes.size(); j++) {
				if (gr.getAdjacencyMatrix()[i][j] == 0) continue;
				Set<List<String>> link = new HashSet<>();
				link.add(this.lineGraphNodes.get(i));
				link.add(this.lineGraphNodes.get(j));
				float w1 = clusterMatrix[i][j];
				float w2 = clusterMatrix[j][i];
				float weight = Math.max(w1, w2);
				lineGraphEdgeWeight.put(link, weight);
			}
		}
		list = new ArrayList<>(lineGraphEdgeWeight.entrySet());
		list.sort((o1, o2) -> o2.getValue().compareTo(o1.getValue()));
	}

	public void run(String matrixFolder) {
		this.matrixFolder = matrixFolder;
		this.init();
		int minOSMaxValue = 5;
		int maxOSMaxValue = 10;
		int minSigmaValue = 5;
		int maxSigmaValue = 10;
		for (int i = minSigmaValue; i <= maxSigmaValue; i++) {
			for (int j = minOSMaxValue; j <= maxOSMaxValue; j++) {
				float osMax = new BigDecimal(i).multiply(new BigDecimal("0.1")).floatValue();
				float sigma = new BigDecimal(j).multiply(new BigDecimal("0.1")).floatValue();
				cluster(osMax, sigma);
			}
		}
		this.saveProcessClusterINFO(this.rootFolder + "EvaluateINFO.txt");
	}

	private void cluster(float osMax, float sigma) {
		this.allClusters = new HashSet<>();
		this.accessedEdges = new HashSet<>();
		for (Map.Entry<Set<List<String>>, Float> s : list) {
			Set<List<String>> link = s.getKey();
			float weight = s.getValue();
			if (weight < 0) {
				break;
			}
			Set<String> cluster = new HashSet<>();
			if (this.accessedEdges.containsAll(link)) continue;
			for (List<String> lineGraphNode : link) {
				if (!this.accessedEdges.contains(lineGraphNode)) {
					cluster.addAll(lineGraphNode);
					this.accessedEdges.add(lineGraphNode);
				}
			}
			for (Set<List<String>> anEdge : lineGraphEdges) {
				if (!isAdjacencyEdge(link, anEdge)) {
					continue;
				}
				float w = this.lineGraphEdgeWeight.get(anEdge);
				float val = weight * sigma;
				if (!accessedEdges.containsAll(anEdge) && w >= val) {
					for (List<String> lineGraphNode : anEdge) {
						if (!accessedEdges.contains(lineGraphNode)) {
							cluster.addAll(lineGraphNode);
							accessedEdges.add(lineGraphNode);
						}
					}
				}
			}
			if (cluster.size() >= 3) {
				this.allClusters.add(cluster);
			}
		}
		Set<Set<String>> anotherClusters = copyClusters(this.allClusters);
		processClusters(this.allClusters, anotherClusters, osMax);
		String clusterResultName = "cluster_osmax_" + osMax + "_sigma_" + sigma;
		String clusterResultFolder = rootFolder + matrixFolder;
		GraphTool.saveClusterFile(clusterResultFolder, clusterResultName, anotherClusters);
		String info1 = "处理前簇的个数共: " + allClusters.size();
		String info2 = "osMax: " + osMax + ", sigma: " + sigma;
		System.out.println(info1);
		System.out.println(info2);
		String evaluateInfo = FMeasureMatch.calc(clusterResultFolder, clusterResultName);
		this.processClusterINFO.append("\n").append(info1).append("\n").append(info2).append("\n").append(evaluateInfo);
		System.out.println();
	}

	private void saveProcessClusterINFO(String infoFile) {
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter(infoFile));
			bw.write(this.processClusterINFO.toString());
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private float getOverlappingScore(Set<String> aCluster, Set<String> anotherCluster) {
		int total = aCluster.size(), overlap = 0;
		for (String protein : anotherCluster) {
			if (aCluster.contains(protein)) {
				overlap++;
				continue;
			}
			total++;
		}
		return overlap / (float)total;
	}

	private boolean isAdjacencyEdge(Set<List<String>> l1, Set<List<String>> l2) {
		int total = l1.size();
		for (List<String> l : l2) {
			if (!l1.contains(l)) {
				total++;
			}
		}
		return total == 3;
	}

	private Set<Set<String>> copyClusters(Set<Set<String>> aClusters) {
		Set<Set<String>> anotherClusters = new HashSet<>();
		for (Set<String> aCluster : aClusters) {
			Set<String> anotherCluster = new HashSet<>(aCluster);
			anotherClusters.add(anotherCluster);
		}
		return anotherClusters;
	}

	private void processClusters(Set<Set<String>> aClusters, Set<Set<String>> anotherClusters, float osMax) {
		for (Set<String> aCluster : aClusters) {
			for (Set<String> anotherCluster : anotherClusters) {
				if (aCluster.equals(anotherCluster)) continue;
				float overlappingScore = getOverlappingScore(aCluster, anotherCluster);
				if (aCluster.containsAll(anotherCluster) || anotherCluster.containsAll(aCluster)
						|| overlappingScore >= osMax) {
					Set<String> newCluster = new HashSet<>(aCluster);
					newCluster.addAll(anotherCluster);
					anotherClusters.remove(aCluster);
					anotherClusters.remove(anotherCluster);
					anotherClusters.add(newCluster);
					break;
				}
			}
		}
	}

	private Set<String> mergeClusters(Set<Set<String>> clustersToBeMerged) {
		Set<String> cluster = new HashSet<>();
		for (Set<String> aCluster : clustersToBeMerged)
			cluster.addAll(aCluster);
		return cluster;
	}

	private Set<Set<String>> getClustersToBeMerged(Set<Set<String>> mergedClusters, float osMax) {
		long t1 = System.currentTimeMillis();
		float maxOverlappingScore = 0.0F;
		Set<Set<String>> clustersToBeMerged = new HashSet<>();
		for (Set<String> aCluster : mergedClusters) {
			for (Set<String> anotherCluster : mergedClusters) {
				if (aCluster != anotherCluster) {
					float overlappingScore = getOverlappingScore(aCluster, anotherCluster);
					if (overlappingScore > maxOverlappingScore) {
						maxOverlappingScore = overlappingScore;
						clustersToBeMerged.clear();
						clustersToBeMerged.add(aCluster);
						clustersToBeMerged.add(anotherCluster);
					}
				}
			}
		}
		long t2 = System.currentTimeMillis();
		System.out.println((t2 - t1) / (float) 1000);
		return (maxOverlappingScore >= osMax) ? clustersToBeMerged : null;
	}
}
