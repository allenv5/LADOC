package cn.edu.whut.ladoc.graph;

import cn.edu.whut.evaluate.FMeasureMatch;
import cn.edu.whut.tools.GraphTool;

import java.math.BigDecimal;
import java.util.*;

/*
 * 2021-04-20
 * 不需要K了
 */

public class ProcessClusterA {

	private String rootFolder;
	private String clusterMatrixFile;
	private String matrixFolder;

	private float[][] clusterMatrix;
	private List<List<String>> lineGraphNodes;
	private Set<Set<List<String>>> lineGraphEdges;

	private GraphReader gr;
	private Map<Set<List<String>>, Float> lineGraphEdgeWeight;
	private List<Map.Entry<Set<List<String>>, Float>> list;

	private Set<Set<String>> allClusters = new HashSet<>();
	private Set<List<String>> accessedEdges = new HashSet<>();

	public ProcessClusterA(String rootFolder, String clusterMatrixFile, GraphReader gr) {
		this.rootFolder = rootFolder;
		this.clusterMatrixFile = clusterMatrixFile;
		this.gr = gr;
	}

	public ProcessClusterA(String rootFolder, float[][] clusterMatrix, GraphReader gr) {
		this.rootFolder = rootFolder;
		this.clusterMatrix = clusterMatrix;
		this.gr = gr;
	}

	public static void main(String[] args) {
		String rootFolder = "data/dataset/Krogan/";
		String matrixFolder = "simrank_0622/";
		String clusterMatrixFile = rootFolder + matrixFolder + "0_result_matrix_simrank";
		List<String> attrs = GraphTool.getAllAttributeFilesName(rootFolder);
		GraphReader gr = new GraphReader(rootFolder, attrs);
		ProcessClusterA p = new ProcessClusterA(rootFolder, clusterMatrixFile, gr);
		p.run(matrixFolder);
	}

	private void init() {
		gr.run();
		if (this.clusterMatrix == null) {
			this.clusterMatrix = GraphTool.readMatrix(this.gr.getLineGraphNodes().size(), this.clusterMatrixFile);
		}
		this.lineGraphNodes = gr.getLineGraphNodes();
		this.lineGraphEdges = gr.getLineGraphEdges();
		this.lineGraphEdgeWeight = new HashMap<>();

		for (int i = 0; i < this.lineGraphNodes.size(); i++) {
			for (int j = i; j < this.lineGraphNodes.size(); j++) {
				if (gr.getAdjacencyMatrix()[i][j] == 0) continue;
				Set<List<String>> link = new HashSet<>();
				link.add(this.lineGraphNodes.get(i));
				link.add(this.lineGraphNodes.get(j));
				float w1 = clusterMatrix[i][j];
				float w2 = clusterMatrix[j][i];
				float weight = Math.max(w1, w2);
				lineGraphEdgeWeight.put(link, weight);
			}
		}
		list = new ArrayList<>(lineGraphEdgeWeight.entrySet());
		list.sort((o1, o2) -> o2.getValue().compareTo(o1.getValue()));
	}

	public void run(String matrixFolder) {
		this.matrixFolder = matrixFolder;
		this.init();
		int minOSMaxValue = 8;
		int maxOSMaxValue = 10;
		int minSigmaValue = 1;
		int maxSigmaValue = 10;
		for (int i = minOSMaxValue; i < maxOSMaxValue; i++) {
			for (int j = minSigmaValue; j < maxSigmaValue; j++) {
				float osMax = new BigDecimal(i).multiply(new BigDecimal("0.1")).floatValue();
				float sigma = new BigDecimal(j).multiply(new BigDecimal("0.1")).floatValue();
				cluster(osMax, sigma);
			}
		}
	}

	private void cluster(float osMax, float sigma) {
		for (Map.Entry<Set<List<String>>, Float> s : list) {
			Set<List<String>> link = s.getKey();
			float weight = s.getValue();
			if (weight < 0) {
				break;
			}
			Set<String> cluster = new HashSet<>();
			if (this.accessedEdges.containsAll(link)) continue;
			for (List<String> lineGraphNode : link) {
				if (!this.accessedEdges.contains(lineGraphNode)) {
					cluster.addAll(lineGraphNode);
					this.accessedEdges.add(lineGraphNode);
				}
			}
			for (Set<List<String>> anEdge : lineGraphEdges) {
				if (!isAdjacencyEdge(link, anEdge)) continue;
				float w = this.lineGraphEdgeWeight.get(anEdge);
				float val = weight * sigma;
				if (!accessedEdges.containsAll(anEdge) && w >= val) {
					for (List<String> lineGraphNode : anEdge) {
						if (!accessedEdges.contains(lineGraphNode)) {
							cluster.addAll(lineGraphNode);
							accessedEdges.add(lineGraphNode);
						}
					}
				}
			}
			if (cluster.size() >= 3) {
				this.allClusters.add(cluster);
			}
		}
		String clusterResultName = "cluster_osmax_" + osMax + "_sigma_" + sigma;
		String clusterResultFolder = rootFolder + matrixFolder;
		Set<Set<String>> clusterSet = this.merge(allClusters, osMax);
		GraphTool.saveClusterFile(clusterResultFolder, clusterResultName, clusterSet);
		System.out.println("处理前簇的个数共: " + allClusters.size());
		System.out.println("osMax: " + osMax + ", sigma: " + sigma);
		FMeasureMatch.calc(clusterResultFolder, clusterResultName);
		System.out.println();
	}

	private float getOverlappingScore(Set<String> aCluster, Set<String> anotherCluster) {
		int total = aCluster.size(), overlap = 0;
		for (String protein : anotherCluster) {
			if (aCluster.contains(protein)) {
				overlap++;
				continue;
			}
			total++;
		}
		return overlap / (float)total;
	}

	private boolean isAdjacencyEdge(Set<List<String>> l1, Set<List<String>> l2) {
		int total = l1.size();
		for (List<String> l : l2) {
			if (!l1.contains(l)) {
				total++;
			}
		}
		return total == 3;
	}

	private Set<Set<String>> merge(Set<Set<String>> iniClusters, float osMax) {
		Set<Set<String>> mergedClusters = iniClusters;

		Set<Set<String>> clustersToBeMerged;
		while((clustersToBeMerged = this.getClustersToBeMerged(mergedClusters, osMax)) != null) {
			Set<String> mergedCluster = this.mergeClusters(clustersToBeMerged);
			for (Set<String> cluster : clustersToBeMerged)
				mergedClusters.remove(cluster);
			mergedClusters.add(mergedCluster);
		}
		return mergedClusters;
	}

	private Set<String> mergeClusters(Set<Set<String>> clustersToBeMerged) {
		Set<String> cluster = new HashSet<>();
		for (Set<String> aCluster : clustersToBeMerged)
			cluster.addAll(aCluster);
		return cluster;
	}

	private Set<Set<String>> getClustersToBeMerged(Set<Set<String>> mergedClusters, float osMax) {
		float maxOverlappingScore = 0.0F;
		Set<Set<String>> clustersToBeMerged = new HashSet<>();
		for (Set<String> aCluster : mergedClusters) {
			for (Set<String> anotherCluster : mergedClusters) {
				if (aCluster != anotherCluster) {
					float overlappingScore = getOverlappingScore(aCluster, anotherCluster);
					if (overlappingScore > maxOverlappingScore) {
						maxOverlappingScore = overlappingScore;
						clustersToBeMerged.clear();
						clustersToBeMerged.add(aCluster);
						clustersToBeMerged.add(anotherCluster);
					}
				}
			}
		}
		return (maxOverlappingScore >= osMax) ? clustersToBeMerged : null;
	}
}
