package cn.edu.whut.ladoc.graph;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;

public class SimRankScoreCalc {

	String rootFolder;
	String graphFile;

	private static Map<String, Set<String>> adjacencyMap = new HashMap<>();
	private static Set<List<String>> edges = new HashSet<>();
	private static List<String> nodes = new ArrayList<>();

	private float[][] query_sim;
	private float[][] ad_sim;
	private List<String> queries;
	private List<String> ads;
	private float[][] simrankMatrix;

	public SimRankScoreCalc(String rootFolder, String graphFile) {
		this.rootFolder = rootFolder;
		this.graphFile = graphFile;
	}

	public static void main(String[] args) {

		String rootFolder = "data/dataset/Homo/";
		String graphFile = "edge_link";

		SimRankScoreCalc ssc = new SimRankScoreCalc(rootFolder, graphFile);
		ssc.readGraph();
		ssc.init();
		ssc.simrank(0.8f, 10);
		// ssc.setSimrank();
	}

	private void readGraph() {
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(rootFolder + graphFile));
			String line;
			while ((line = br.readLine()) != null) {
				String[] vals = line.split("\t");
				List<String> edge = new ArrayList<>();
				edge.add(vals[0]);
				edge.add(vals[1]);
				edges.add(edge);
				if (!nodes.contains(vals[0])) {
					nodes.add(vals[0]);
				}
				if (!nodes.contains(vals[1])) {
					nodes.add(vals[1]);
				}
				if (!adjacencyMap.containsKey(vals[0])) {
					adjacencyMap.put(vals[0], new HashSet<>());
				}
				if (!adjacencyMap.containsKey(vals[1])) {
					adjacencyMap.put(vals[1], new HashSet<>());
				}
				adjacencyMap.get(vals[0]).add(vals[1]);
				adjacencyMap.get(vals[1]).add(vals[0]);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void init() {

		this.queries = new ArrayList<>(nodes);
		this.ads = new ArrayList<>(nodes);

		this.query_sim = new float[nodes.size()][nodes.size()];
		for (int i1 = 0; i1 < nodes.size(); i1++) {
			query_sim[i1][i1] = 1;
		}

		this.ad_sim = new float[nodes.size()][nodes.size()];
		for (int i1 = 0; i1 < nodes.size(); i1++) {
			ad_sim[i1][i1] = 1;
		}
	}

	public float querySimrank(int i, int j, float C) {
		long t1 = System.currentTimeMillis();
		if (i == j) return 1;
		String node1 = nodes.get(i);
		String node2 = nodes.get(j);

		float prefix = C / (adjacencyMap.get(node1).size() * adjacencyMap.get(node2).size());
		float postfix = 0;

		for (String n1 : adjacencyMap.get(node1)) {
			for (String n2 : adjacencyMap.get(node2)) {
				int idx1 = ads.indexOf(n1);
				int idx2 = ads.indexOf(n2);
				postfix += ad_sim[idx1][idx2];
			}
		}
		long t2 = System.currentTimeMillis();
		System.out.println("Cost: " + (t2 - t1) + "ms");
		return prefix * postfix;
	}

	public float adSimrank(int i, int j, float C) {
		if (i == j) return 1;
		String node1 = nodes.get(i);
		String node2 = nodes.get(j);

		float prefix = C / (adjacencyMap.get(node1).size() * adjacencyMap.get(node2).size());
		float postfix = 0;

		for (String n1 : adjacencyMap.get(node1)) {
			for (String n2 : adjacencyMap.get(node2)) {
				int idx1 = queries.indexOf(n1);
				int idx2 = queries.indexOf(n2);
				postfix += ad_sim[idx1][idx2];
			}
		}
		return prefix * postfix;
	}
	
	private void simrank(float C, int times) {
		for (int i = 0; i < times; i++) {

			float[][] newQeurySim = new float[nodes.size()][nodes.size()];
			for (int i1 = 0; i1 < nodes.size(); i1++) {
				newQeurySim[i1][i1] = 1;
			}

			for (String node1 : queries) {
				for (String node2 : queries) {
					int idx1 = nodes.indexOf(node1);
					int idx2 = nodes.indexOf(node2);
					newQeurySim[idx1][idx2] = querySimrank(idx1, idx2, C);
				}
			}

			float[][] newAdSim = new float[nodes.size()][nodes.size()];
			for (int i1 = 0; i1 < nodes.size(); i1++) {
				newAdSim[i1][i1] = 1;
			}

			for (String node1 : queries) {
				for (String node2 : queries) {
					int idx1 = nodes.indexOf(node1);
					int idx2 = nodes.indexOf(node2);
					newAdSim[idx1][idx2] = adSimrank(idx1, idx2, C);
				}
			}

			query_sim = newQeurySim;
			ad_sim = newAdSim;
		}
	}

	private void setSimrank() {
		this.simrankMatrix = new float[nodes.size()][nodes.size()];
		for (int i = 0; i < nodes.size(); i++) {
			for (int j = 0; j < nodes.size(); j++) {
				float score = getSimrankScore(i, j, 0.8f);
				this.simrankMatrix[i][j] = score;
				this.simrankMatrix[j][i] = score;
			}
		}
	}

	private float getSimrankScore(int i, int j, float C) {
		if (i == j) {
			return 1;
		}
		String nodeI = nodes.get(i);
		String nodeJ = nodes.get(j);
		Set<String> adjacencyNodesI = adjacencyMap.get(nodeI);
		Set<String> adjacencyNodesJ = adjacencyMap.get(nodeJ);
		if (adjacencyNodesI.size() == 0 || adjacencyNodesJ.size() == 0) {
			return 0;
		}
		float sum = 0;
		for (String n1 : adjacencyNodesI) {
			for (String n2 : adjacencyNodesJ) {
				if (adjacencyMap.get(n1).contains(n2) || adjacencyMap.get(n2).contains(n1)) {
					sum += 1;
				}
			}
		}
		return C * sum / (float) (adjacencyNodesI.size() * adjacencyNodesJ.size());
	}

}
