package cn.edu.whut.ladoc.graph;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;

public class SimRankScoreCalc2 {

	private String rootFolder;
	private String graphFile;
	private int numThreads;

	private static Map<String, Set<String>> adjacencyMap = new HashMap<>();
	private static Set<List<String>> edges = new HashSet<>();
	private static List<String> nodes = new ArrayList<>();

	private float[][] query_sim;
	private List<String> queries;
	private float[][] simrankMatrix;

	public SimRankScoreCalc2(String rootFolder, String graphFile) {
		this.rootFolder = rootFolder;
		this.graphFile = graphFile;
	}

	public static void main(String[] args) {

		String rootFolder = "data/dataset/Homo/";
		String graphFile = "edge_link";

		SimRankScoreCalc2 ssc = new SimRankScoreCalc2(rootFolder, graphFile);
		ssc.readGraph();
		ssc.init();
		ssc.simrank(0.8f, 20);
		// ssc.setSimrank();
	}

	private void readGraph() {
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(rootFolder + graphFile));
			String line;
			while ((line = br.readLine()) != null) {
				String[] vals = line.split("\t");
				List<String> edge = new ArrayList<>();
				edge.add(vals[0]);
				edge.add(vals[1]);
				edges.add(edge);
				if (!nodes.contains(vals[0])) {
					nodes.add(vals[0]);
				}
				if (!nodes.contains(vals[1])) {
					nodes.add(vals[1]);
				}
				if (!adjacencyMap.containsKey(vals[0])) {
					adjacencyMap.put(vals[0], new HashSet<>());
				}
				if (!adjacencyMap.containsKey(vals[1])) {
					adjacencyMap.put(vals[1], new HashSet<>());
				}
				adjacencyMap.get(vals[0]).add(vals[1]);
				adjacencyMap.get(vals[1]).add(vals[0]);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void init() {
		this.queries = new ArrayList<>(nodes);
		this.query_sim = new float[nodes.size()][nodes.size()];
		for (int i1 = 0; i1 < nodes.size(); i1++) {
			query_sim[i1][i1] = 1;
		}
	}

	public float querySimrank(int i, int j, float C) {
		long t1 = System.currentTimeMillis();
		if (i == j) return 1;
		String node1 = nodes.get(i);
		String node2 = nodes.get(j);

		Set<String> adjacencyNodes1 = adjacencyMap.get(node1);
		Set<String> adjacencyNodes2 = adjacencyMap.get(node2);

		float prefix = C / (adjacencyNodes1.size() * adjacencyNodes2.size());
		float postfix = 0;

		for (String n1 : adjacencyNodes1) {
			for (String n2 : adjacencyNodes2) {
				int idx1 = queries.indexOf(n1);
				int idx2 = queries.indexOf(n2);
				postfix += query_sim[idx1][idx2];
			}
		}
		long t2 = System.currentTimeMillis();
		System.out.println("Cost: " + (t2 - t1) + "ms");
		return prefix * postfix;
	}
	
	private void simrank(float C, int times) {
		for (int i = 0; i < times; i++) {

			float[][] newQeurySim = new float[nodes.size()][nodes.size()];
			for (int i1 = 0; i1 < nodes.size(); i1++) {
				newQeurySim[i1][i1] = 1;
			}

			for (String node1 : queries) {
				for (String node2 : queries) {
					int idx1 = nodes.indexOf(node1);
					int idx2 = nodes.indexOf(node2);
					newQeurySim[idx1][idx2] = querySimrank(idx1, idx2, C);
				}
			}
			query_sim = newQeurySim;
		}
	}

	private int[][] getThreadSlots(int numInstances) {
		// TODO Auto-generated method stub
		int[][] threadSlots;

		if (numInstances <= this.numThreads) {
			threadSlots = new int[numInstances][2];

			for (int i = 0; i < numInstances; i++) {
				threadSlots[i][0] = i;
				threadSlots[i][1] = i + 1;
			}
		} else {
			threadSlots = new int[this.numThreads][2];
			// int numItemsInEachThread = Math.round(numInstances / this.numThreads);
			int numItemsInEachThread = numInstances / this.numThreads;
			int remainder = numInstances - numItemsInEachThread * this.numThreads;

			// setup thread pool
			for (int i = 0; i < this.numThreads; i++) {
				int extra = i < remainder ? i : remainder;
				int beginIndex = numItemsInEachThread * i + extra;
				int increment = numItemsInEachThread + (i < remainder ? 1 : 0);
				int endIndex = i == this.numThreads - 1 ? numInstances : (beginIndex + increment);

				threadSlots[i][0] = beginIndex;
				threadSlots[i][1] = endIndex;
			}
		}

		return threadSlots;
	}

}
