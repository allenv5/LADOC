package cn.edu.whut.ladoc.graph;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SimrankMatrixSetter {
	private List<String> nodeList = new ArrayList<>();
	private List<List> edgeLinks = new ArrayList<>();
	private Map<String, String> simrankValueMap = new HashMap<>();
	private float[][] simrankMatrix;
	private String filePath, nodeFile, edgeFile, simrankFile;

	public SimrankMatrixSetter(String filePath, String nodeFile, String edgeFile, String simrankFile) {
		this.filePath = filePath;
		this.nodeFile = nodeFile;
		this.edgeFile = edgeFile;
		this.simrankFile = simrankFile;
	}

	public void run() {
		setNodeList(this.nodeFile);
		setEdgeLinks(this.edgeFile);
		setSimrankMap(this.simrankFile);
		setSimrankMatrix();
	}

	public float[][] getSimrankMatrix() {
		return this.simrankMatrix;
	}

	private void setNodeList(String fileName) {
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(filePath + fileName));
			String line;
			while ((line = br.readLine()) != null && !"".equals(line)) {
				String[] items = line.split("\t");
				nodeList.add(items[0] + "," + items[1]);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void setEdgeLinks(String fileName) {
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(this.filePath + fileName));
			String line;
			while ((line = br.readLine()) != null && !"".equals(line)) {
				String[] items = line.split("\t");
				List<String> tmpList = new ArrayList<>();
				if (items.length == 2) {
					tmpList.add(items[0]);
					tmpList.add(items[1]);
					this.edgeLinks.add(tmpList);
				}
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void setSimrankMap(String fileName) {
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(this.filePath + fileName));
			String line;
			while ((line = br.readLine()) != null && !"".equals(line)) {
				String[] items = line.split("\t");
				if (items.length >= 2) {
					for (int i = 1; i < items.length; i++) {
						String key = items[0] + ":" + items[i].split(":")[0];
						simrankValueMap.put(key, items[i].split(":")[1]);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Map<String, String> getSimrankValueMap() {
		return this.simrankValueMap;
	}

	public void setSimrankMatrix() {
		simrankMatrix = new float[nodeList.size()][nodeList.size()];
		for (int i = 0; i < simrankMatrix.length; i++) {
			for (int j = 0; j < simrankMatrix.length; j++) {
				if (i == j) {
					simrankMatrix[i][j] = 1;
				} else {
					String node1 = nodeList.get(i);
					String node2 = nodeList.get(j);
					String edgeLink = node1 + ":" + node2;
					if (simrankValueMap.containsKey(edgeLink)) {
						simrankMatrix[i][j] = Float.parseFloat(simrankValueMap.get(edgeLink));
					}
				}
			}
		}
	}
}
