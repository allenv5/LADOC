package cn.edu.whut.ladoc.graph;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SimrankMatrixSetter2 {
	private List<List<String>> edgeList;
	private float[][] simrankMatrix;
	private String filePath, simrankFile;

	public SimrankMatrixSetter2(List<List<String>> edgeList, String filePath, String simrankFile) {
		this.edgeList = edgeList;
		this.filePath = filePath;
		this.simrankFile = simrankFile;
	}

	public void run() {
		this.simrankMatrix = new float[this.edgeList.size()][this.edgeList.size()];
		try {
			BufferedReader br = new BufferedReader(new FileReader(this.filePath + this.simrankFile));
			String line;
			while ((line = br.readLine()) != null) {
				String[] items = line.split("\t");
				List<String> l1 = new ArrayList<>(Arrays.asList(items[0].split(",")));
				int idx1 = this.edgeList.indexOf(l1);
				for (int i = 1; i < items.length; i++) {
					String[] vals = items[i].split(":");
					List<String> l2 = new ArrayList<>(Arrays.asList(vals[0].split(",")));
					int idx2 = this.edgeList.indexOf(l2);
					float value = Float.parseFloat(vals[1]);
					this.simrankMatrix[idx1][idx2] = value;
				}
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		for (int i = 0; i < simrankMatrix.length; i++) {
			this.simrankMatrix[i][i] = 1;
		}
	}

	public float[][] getSimrankMatrix() {
		return this.simrankMatrix;
	}
}
