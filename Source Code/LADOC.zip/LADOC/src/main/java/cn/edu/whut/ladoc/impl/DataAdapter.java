package cn.edu.whut.ladoc.impl;

import cn.edu.whut.ladoc.SharedLibrary;
import cn.edu.whut.ladoc.similarity.SimilarityMeasure;
import org.apache.log4j.Logger;

import java.io.*;
import java.util.*;

public class DataAdapter {
	public static Logger logger = Logger.getLogger(DataAdapter.class);
	public static String AttributeFilePrefix = "attribute-similairty-matrix-";
	public static String TopologyWeightFile = "topology-weight-matrix";
	private String workingDir;
	private String vertexFile;
	private String edgeFile;
	private String attributeFilePrefix;
	private int numOfAttributes;
	private int[][] incidenceMatrix;
	private float[][][] attributeWeightMatrix;
	private float[][] topologyWeightMatrix;
	private Map<String, Integer> vertexIdMap;
	private float minAttributeSimilarity;
	private float minTopologyWeight;
	private SimilarityMeasure measure;

	public DataAdapter(String workingDir, String vertexFile, String edgeFile, SimilarityMeasure measure, String attributeFilePrefix, int numOfAttributes, float minAttributeSimilarity, float minTopologyWeight) {
		this.workingDir = workingDir;
		this.vertexFile = vertexFile;
		this.edgeFile = edgeFile;
		this.attributeFilePrefix = attributeFilePrefix;
		this.numOfAttributes = numOfAttributes;
		this.minAttributeSimilarity = minAttributeSimilarity;
		this.minTopologyWeight = minTopologyWeight;
		this.measure = measure;
	}

	public void run() {
		this.readVertexFile();
		this.readEdgeFile();
		this.setAttributeWeightMatrix();
		this.setTopologyWeightMatrix();
		this.statistics();
	}

	private void statistics() {
		this.avgTopologyWeight();
		this.avgNeighbors();
		this.avgAttributeWeight();
	}

	private void avgAttributeWeight() {
		float total = 0.0F;
		int count = 0;

		for(int i = 0; i < this.attributeWeightMatrix.length; ++i) {
			for(int j = 0; j < this.attributeWeightMatrix[i].length; ++j) {
				for(int k = 0; k < this.attributeWeightMatrix[i][j].length; ++k) {
					total += this.attributeWeightMatrix[i][j][k];
					++count;
				}
			}
		}

		logger.info("Avg attribute weight: " + total / (float)count);
	}

	private void avgNeighbors() {
		int total = 0;
		int count = 0;

		for(int i = 0; i < this.incidenceMatrix.length - 1; ++i) {
			for(int j = i + 1; j < this.incidenceMatrix[i].length; ++j) {
				int subTotal = 0;

				for(int k = 0; k < this.incidenceMatrix[i].length; ++k) {
					if (this.incidenceMatrix[i][k] == 1 && this.incidenceMatrix[j][k] == 1) {
						++subTotal;
					}
				}

				total += subTotal;
				++count;
			}
		}

		logger.info("Avg neighbors: " + (float)total / (float)count);
	}

	private void avgTopologyWeight() {
		float total = 0.0F;
		int count = 0;

		for(int i = 0; i < this.topologyWeightMatrix.length - 1; ++i) {
			for(int j = i + 1; j < this.topologyWeightMatrix[i].length; ++j) {
				total += this.topologyWeightMatrix[i][j];
				++count;
			}
		}

		logger.info("Avg topology weight: " + total / (float)count);
	}

	private void saveTopologyWeightMatrix() {
		String file = this.workingDir + File.separator + TopologyWeightFile;
		SharedLibrary.saveMatrixToFile(this.topologyWeightMatrix, file);
	}

	private void saveAttributeWeightMatrix() {
		for(int i = 1; i <= this.attributeWeightMatrix.length; ++i) {
			String file = this.workingDir + File.separator + AttributeFilePrefix + i;
			SharedLibrary.saveMatrixToFile(this.attributeWeightMatrix[i - 1], file);
		}

	}

	private void setTopologyWeightMatrix() {
		int numOfVertices = this.incidenceMatrix.length;
		this.topologyWeightMatrix = new float[numOfVertices][numOfVertices];

		for(int i = 0; i < numOfVertices - 1; ++i) {
			for(int j = i + 1; j < numOfVertices; ++j) {
				float percentage = this.getPercentageOfNeighborsInCommon(i, j, numOfVertices);
				percentage -= this.minTopologyWeight;
				this.topologyWeightMatrix[i][j] = percentage;
				this.topologyWeightMatrix[j][i] = percentage;
			}
		}

	}

	private float getPercentageOfNeighborsInCommon(int i, int j, int numOfVertices) {
		int total = 0;
		int commonNeighbors = 0;

		for(int k = 0; k < numOfVertices; ++k) {
			if (this.incidenceMatrix[i][k] == 1 && this.incidenceMatrix[j][k] == 1) {
				++commonNeighbors;
			}

			if (this.incidenceMatrix[i][k] == 1 || this.incidenceMatrix[j][k] == 1) {
				++total;
			}
		}

		return commonNeighbors == 0 ? 0.0F : (float)commonNeighbors / (float)total;
	}

	private void postprocessTopologyWeightMatrix() {
		for(int i = 0; i < this.topologyWeightMatrix.length; ++i) {
			float max = 0.0F;
			float min = (float)this.topologyWeightMatrix.length;

			int j;
			for(j = 0; j < this.topologyWeightMatrix[i].length; ++j) {
				float val = this.topologyWeightMatrix[i][j];
				max = Math.max(max, val);
				min = Math.min(min, val);
			}

			for(j = 0; j < this.topologyWeightMatrix[i].length; ++j) {
				float[] var10000;
				if (max > 0.0F) {
					var10000 = this.topologyWeightMatrix[i];
					var10000[j] /= max;
				} else if (max == 0.0F) {
					this.topologyWeightMatrix[i][j] = 0.0F;
				} else {
					logger.error("Max is " + max + " for " + i + " column of topology weight matrix");
				}

				var10000 = this.topologyWeightMatrix[i];
				var10000[j] -= this.minTopologyWeight;
				this.topologyWeightMatrix[i][j] = SharedLibrary.roundWithTowDecimalPlaces(this.topologyWeightMatrix[i][j]);
			}
		}

	}

	private int getNeighborsInCommon(int i, int j, int numOfVertices) {
		int commonNeighbors = 0;

		for(int k = 0; k < numOfVertices; ++k) {
			if (this.incidenceMatrix[i][k] == 1 && this.incidenceMatrix[j][k] == 1) {
				++commonNeighbors;
			}
		}

		return commonNeighbors;
	}

	private void setAttributeWeightMatrix() {
		this.attributeWeightMatrix = new float[this.numOfAttributes][][];
		for (int i = 0; i < this.numOfAttributes; i++) {
			this.attributeWeightMatrix[i] = new float[this.vertexIdMap.size()][this.vertexIdMap.size()];
			Map<String, Set<String>> valueMap = readAttributeValues(i + 1);

			for (String edgeNode : this.vertexIdMap.keySet()) {
				int index = this.vertexIdMap.get(edgeNode);
				String[] items = edgeNode.split(",");
				Set<String> set1 = new HashSet<>();
				set1.addAll(valueMap.get(items[0]));
				set1.addAll(valueMap.get(items[1]));
				for (String anotherEdgeNode : this.vertexIdMap.keySet()) {
					int anotherIndex = this.vertexIdMap.get(anotherEdgeNode);
					String[] items2 = anotherEdgeNode.split(",");
					Set<String> set2 = new HashSet<>();
					set2.addAll(valueMap.get(items2[0]));
					set2.addAll(valueMap.get(items2[1]));
					float weight = this.measure.compute(set1, set2) - this.minAttributeSimilarity;
					this.attributeWeightMatrix[i][index][anotherIndex] = SharedLibrary.roundWithTowDecimalPlaces(weight);
				}
			}
		}
	}

	private void setAttributeWeightMatrix2() {
		this.attributeWeightMatrix = new float[this.numOfAttributes][this.vertexIdMap.size()][];
		for (int i = 0; i < this.numOfAttributes; i++) {
			this.attributeWeightMatrix[i] = new float[this.vertexIdMap.size()][this.vertexIdMap.size()];
			Map<String, Set<String>> valueMap = readAttributeValues(i + 1);
			for (String vertex : valueMap.keySet()) {
				if (!this.vertexIdMap.containsKey(vertex))
					continue;
				Set<String> values = valueMap.get(vertex);
				int index = this.vertexIdMap.get(vertex);
				for (String anotherVertex : valueMap.keySet()) {
					if (!this.vertexIdMap.containsKey(anotherVertex))
						continue;
					Set<String> anotherValues = valueMap.get(anotherVertex);
					int anotherIndex = this.vertexIdMap.get(anotherVertex);
					float weight = this.measure.compute(values, anotherValues) - this.minAttributeSimilarity;
					this.attributeWeightMatrix[i][index][anotherIndex] = SharedLibrary.roundWithTowDecimalPlaces(weight);
				}
			}
		}
	}

	private Map<String, Set<String>> readAttributeValues(int index) {
		Map<String, Set<String>> valueMap = new HashMap();
		String attributeFile = this.attributeFilePrefix + index;
		BufferedReader br = null;

		try {
			br = new BufferedReader(new FileReader(attributeFile));

			while(true) {
				String line;
				while((line = br.readLine()) != null) {
					String[] items = line.split("\t");
					if (items.length > 0 && items.length <= 2) {
						Set<String> values = new HashSet();
						String vertex = items[0];
						if (items.length == 2) {
							String[] valueArray = items[1].split(",");
							String[] var13 = valueArray;
							int var12 = valueArray.length;

							for(int var11 = 0; var11 < var12; ++var11) {
								String value = var13[var11];
								values.add(value);
							}
						}

						valueMap.put(vertex, values);
					} else {
						logger.error("This line is not well formatted: " + line);
					}
				}

				return valueMap;
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException var23) {
					var23.printStackTrace();
				}
			}

		}

		return valueMap;
	}

	public int[][] getIncidenceMatrix() {
		return this.incidenceMatrix;
	}

	public float[][][] getAttributeWeightMatrix() {
		return this.attributeWeightMatrix;
	}

	public float[][] getTolopogyWeightMatrix() {
		return this.topologyWeightMatrix;
	}

	public Map<String, Integer> getVertex2IdMap() {
		return this.vertexIdMap;
	}

	public Map<Integer, String> getId2VertexMap() {
		Map<Integer, String> id2VertexMap = new HashMap();
		Iterator iter = this.vertexIdMap.keySet().iterator();

		while(iter.hasNext()) {
			String vertex = (String)iter.next();
			int id = this.vertexIdMap.get(vertex);
			String prevVal = id2VertexMap.put(id, vertex);
			if (prevVal != null) {
				logger.error("Previous Value was found for id [" + id + "]: " + prevVal);
			}
		}

		return id2VertexMap;
	}

	private void readEdgeFile() {
		String file = this.workingDir + File.separator + this.edgeFile;
		this.incidenceMatrix = new int[this.vertexIdMap.size()][this.vertexIdMap.size()];
		BufferedReader br = null;

		try {
			br = new BufferedReader(new FileReader(file));

			String line;
			while((line = br.readLine()) != null) {
				String[] items = line.split("\t");
				if (items.length != 2) {
					logger.error("This line is not well formatted: " + line);
				} else {
					int vertex = this.vertexIdMap.get(items[0]);
					int anotherVertex = this.vertexIdMap.get(items[1]);
					this.incidenceMatrix[vertex][anotherVertex] = 1;
					this.incidenceMatrix[anotherVertex][vertex] = 1;
				}
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private void readVertexFile() {
		String file = this.workingDir + File.separator + this.vertexFile;
		this.vertexIdMap = new HashMap<>();
		BufferedReader br = null;

		try {
			br = new BufferedReader(new FileReader(file));
			int n = 0;

			String line;
			while((line = br.readLine()) != null) {
				this.vertexIdMap.put(line, n++);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
