package cn.edu.whut.ladoc.impl;

import cn.edu.whut.ladoc.SharedLibrary;
import org.apache.log4j.Logger;

public class MatrixFactory {
  public static Logger logger = Logger.getLogger(MatrixFactory.class);

  public MatrixFactory() {
  }

  public static float[][] generateConstrainedMatrix(int numOfRows, int numOfCols, float min, float max) {
    float[][] matrix = new float[numOfRows][numOfCols];

    for (float[] fs : matrix) {
      for (int i = 0; i < fs.length; ++i) {
        fs[i] = (float) (Math.random() * (double) (max - min));
        fs[i] = SharedLibrary.roundWithTowDecimalPlaces(fs[i]);
        if (fs[i] < min) {
          fs[i] = min;
        }
      }
    }

    return matrix;
  }

  public static float[][] generateNormalizedMatrixWithConstraints(int numOfRows, int numOfCols, float min, float max) {
    float[][] matrix = generateConstrainedMatrix(numOfRows, numOfCols, min, max);
    SharedLibrary.normalizeMatrix(matrix);
    return matrix;
  }
}
