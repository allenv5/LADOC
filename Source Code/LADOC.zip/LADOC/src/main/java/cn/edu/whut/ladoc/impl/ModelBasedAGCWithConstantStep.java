package cn.edu.whut.ladoc.impl;

import cn.edu.whut.ladoc.SharedLibrary;
import org.apache.log4j.Logger;

import java.io.File;

public class ModelBasedAGCWithConstantStep {
	public static Logger logger = Logger.getLogger(ModelBasedAGCWithConstantStep.class);
	public static String MatrixLFilename = "matrx-L";
	public static String MatrixWFilename = "matrx-W";
	private float[][] prevMatrixL;
	private float[][] prevMatrixW;
	private float[][] matrixL;
	private float[][] matrixW;
	private int[][] incidenceMatrix;
	private float[][][] weightMatrix;
	private float alpha;
	private float beta;
	private float theta;
	private float phi;
	private float maxChange;
	private float step;
	private int maxLoops;
	private String saveFolder;

	public ModelBasedAGCWithConstantStep(float[][] initMatrixL, float[][] initMatrixW, int[][] incidenceMatrix, float[][][] weightMatrix, float alpha, float beta, float theta, float phi, float maxChange, float step, int maxLoops, String saveFolder) {
		this.matrixL = initMatrixL;
		this.matrixW = initMatrixW;
		this.incidenceMatrix = incidenceMatrix;
		this.weightMatrix = weightMatrix;
		this.alpha = alpha;
		this.beta = beta;
		this.theta = theta;
		this.phi = phi;
		this.maxChange = maxChange;
		this.step = step;
		this.maxLoops = maxLoops;
		this.saveFolder = saveFolder;
	}

	public void run() {
		int currLoop = 1;
		this.prevMatrixL = new float[this.matrixL.length][(this.matrixL[0]).length];
		this.prevMatrixW = new float[this.matrixW.length][(this.matrixW[0]).length];
		float[][] lagGOfMatrixW = new float[this.matrixW.length][(this.matrixW[0]).length];
		float[][] lagGOfMatrixL = new float[this.matrixL.length][(this.matrixL[0]).length];
		float[][] lagLOfMatrixL = new float[this.matrixL.length][(this.matrixL[0]).length];
		float[][] optimalDirectionOfMatrixW = new float[this.matrixW.length][(this.matrixW[0]).length];
		float[][] optimalDirectionOfMatrixL = new float[this.matrixL.length][(this.matrixL[0]).length];
		float[][] prevOptimalDirectionOfMatrixL = new float[this.matrixL.length][(this.matrixL[0]).length];
		while (!terminate(currLoop, optimalDirectionOfMatrixL,
				prevOptimalDirectionOfMatrixL, lagGOfMatrixW, lagGOfMatrixL,
				lagLOfMatrixL)) {
			copy(this.prevMatrixL, this.matrixL);
			copy(this.prevMatrixW, this.matrixW);
			copy(prevOptimalDirectionOfMatrixL, optimalDirectionOfMatrixL);
			if (this.phi > 0.0F) {
				updateOptimalDirectionOfMatrixW(optimalDirectionOfMatrixW,
						lagGOfMatrixW);
				updateMatrix(this.matrixW, this.prevMatrixW,
						optimalDirectionOfMatrixW);
				SharedLibrary.normalizeMatrix(this.matrixW);
			}
			updateOptimalDirectionOfMatrixL(optimalDirectionOfMatrixL,
					lagGOfMatrixL, lagLOfMatrixL);
			float stepL = getStepOfG(this.prevMatrixL,
					optimalDirectionOfMatrixL);
			stepL = Math.min(stepL,
					getStepOfL(this.prevMatrixL, optimalDirectionOfMatrixL));
			updateMatrix(this.matrixL, this.prevMatrixL,
					optimalDirectionOfMatrixL, stepL);
			float objectiveScore = obtainObjectiveScore();
			logger.debug("The score at #" + currLoop++ + " loop: " +
					objectiveScore);
		}
		if (this.saveFolder != null)
			save();
	}

	private void copy(float[][] destMatrix, float[][] sourceMatrix) {
		for (int i = 0; i < sourceMatrix.length; i++) {
			for (int j = 0; j < (sourceMatrix[i]).length; j++)
				destMatrix[i][j] = sourceMatrix[i][j];
		}
	}

	public float[][] getMatrixL() {
		return this.matrixL;
	}

	public float[][] getMatrixW() {
		return this.matrixW;
	}

	private void save() {
		String filePath = String.valueOf(this.saveFolder) + File.separator + MatrixLFilename;
		SharedLibrary.saveMatrixToFile(this.matrixL, filePath);
		filePath = String.valueOf(this.saveFolder) + File.separator + MatrixWFilename;
		SharedLibrary.saveMatrixToFile(this.matrixW, filePath);
	}

	private float obtainObjectiveScore() {
		float score = 0.0F;
		float attributePart = 0.0F;
		for (int i = 0; i < this.matrixL.length; i++) {
			for (int k = 0; k < (this.matrixL[i]).length; k++) {
				for (int m = 0; m < this.weightMatrix.length; m++)
					attributePart = this.matrixL[i][k] * this.matrixW[i][m] *
							this.weightMatrix[m][i][k];
			}
		}
		float topologyPart = 0.0F;
		for (int j = 0; j < this.matrixL.length; j++) {
			for (int k = 0; k < (this.matrixL[j]).length; k++)
				topologyPart += this.matrixL[j][k] * this.incidenceMatrix[j][k] *
						this.matrixL[k][j];
		}
		float restrictionL = getSquareOfFrobenius(this.matrixL);
		float restrictionW = getSquareOfFrobenius(this.matrixW);
		score = this.alpha * attributePart + this.beta * topologyPart -
				this.theta * restrictionL / 2.0F - this.phi * restrictionW / 2.0F;
		return score;
	}

	private float getSquareOfFrobenius(float[][] matrix) {
		float sum = 0.0F;
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < (matrix[i]).length; j++)
				sum += matrix[i][j] * matrix[i][j];
		}
		return sum;
	}

	private void updateOptimalDirectionOfMatrixL(float[][] optimalDirectionOfMatrixL, float[][] lagGOfMatrixL, float[][] lagLOfMatrixL) {
		for (int i = 0; i < optimalDirectionOfMatrixL.length; i++) {
			for (int j = 0; j < (optimalDirectionOfMatrixL[i]).length; j++) {
				float l_i_j = this.prevMatrixL[i][j];
				if (l_i_j == 0.0F) {
					optimalDirectionOfMatrixL[i][j] = 0.0F;
					lagLOfMatrixL[i][j] = 0.0F;
					lagGOfMatrixL[i][j] = derivativeOverL_i_j(i, j);
				} else if (l_i_j == 1.0F) {
					optimalDirectionOfMatrixL[i][j] = 0.0F;
					lagLOfMatrixL[i][j] = derivativeOverL_i_j(i, j);
					lagGOfMatrixL[i][j] = 0.0F;
				} else if (l_i_j > 0.0F && l_i_j < 1.0F) {
					optimalDirectionOfMatrixL[i][j] = derivativeOverL_i_j(i, j);
					lagLOfMatrixL[i][j] = 0.0F;
					lagGOfMatrixL[i][j] = 0.0F;
				} else {
					logger.error("l_i_j is not correct: " + i + "-" + j +
							" is " + l_i_j);
				}
			}
		}
	}

	private float derivativeOverL_i_j(int i, int j) {
		float result = 0.0F;
		float sum_m = 0.0F;
		for (int m = 0; m < this.weightMatrix.length; m++)
			sum_m += this.matrixW[i][m] * this.weightMatrix[m][i][j];
		float incidenceWeight = this.incidenceMatrix[i][j] * this.matrixL[j][i];
		result = this.alpha * sum_m + this.beta * incidenceWeight - this.theta *
				this.prevMatrixL[i][j];
		return result;
	}

	private void updateMatrix(float[][] matrix, float[][] prevMatrix, float[][] directionMatrix) {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < (matrix[i]).length; j++)
				matrix[i][j] = prevMatrix[i][j] + directionMatrix[i][j] * this.step;
		}
	}

	private void updateMatrix(float[][] matrix, float[][] prevMatrix, float[][] directionMatrix, float minStep) {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < (matrix[i]).length; j++) {
				matrix[i][j] = prevMatrix[i][j] + directionMatrix[i][j] * minStep;
				if (matrix[i][j] <= 0.0F)
					matrix[i][j] = 0.0F;
			}
		}
	}

	private void updateOptimalDirectionOfMatrixW(float[][] optimalDirectionOfMatrixW, float[][] lagGOfMatrixW) {
		for (int i = 0; i < this.prevMatrixW.length; i++) {
			float[] prevRowW = this.prevMatrixW[i];
			float[] optimalDirectionOfRowW = optimalDirectionOfMatrixW[i];
			float[] lagGOfRowW = lagGOfMatrixW[i];
			float[] derivativeOverRowW = new float[prevRowW.length];
			float v_w_i = calV_W_I(prevRowW, i, derivativeOverRowW);
			for (int m = 0; m < prevRowW.length; m++) {
				if (prevRowW[m] > 0.0F) {
					lagGOfRowW[m] = 0.0F;
					optimalDirectionOfRowW[m] = (v_w_i - derivativeOverRowW[m]) /
							this.phi;
				} else if (prevRowW[m] == 0.0F) {
					lagGOfRowW[m] = derivativeOverRowW[m] - v_w_i;
					optimalDirectionOfRowW[m] = 0.0F;
				} else {
					lagGOfRowW[m] = 0.0F;
					optimalDirectionOfRowW[m] = 0.0F;
				}
			}
		}
	}

	private float calV_W_I(float[] rowW, int rowIndex, float[] derivativeOverRowW) {
		float v_w_i = 0.0F;
		for (int m = 0; m < rowW.length; m++) {
			derivativeOverRowW[m] = derivativeOverW_i_m(rowIndex, m);
			if (rowW[m] > 0.0F) {
				v_w_i += derivativeOverRowW[m];
			} else if (rowW[m] < 0.0F) {
				logger.error("w_i_m is less then 0 when i is " + rowIndex +
						" and m is " + m);
			}
		}
		return v_w_i;
	}

	private float derivativeOverW_i_m(int rowIndex, int m) {
		float result = 0.0F;
		float sum_j = 0.0F;
		for (int j = 0; j < (this.prevMatrixL[rowIndex]).length; j++)
			sum_j += this.prevMatrixL[rowIndex][j] *
					this.weightMatrix[m][rowIndex][j];
		result = this.alpha * sum_j - this.phi * this.prevMatrixW[rowIndex][m];
		return result;
	}

	private boolean terminate(int currLoop, float[][] optimalDirectionOfMatrixL, float[][] prevOptimalDirectionOfMatrixL, float[][] lagGOfMatrixW, float[][] lagGOfMatrixL, float[][] lagLOfMatrixL) {
		if (currLoop > 1) {
			if (currLoop == this.maxLoops)
				return true;
			if (distanceBtwMatrices(optimalDirectionOfMatrixL, prevOptimalDirectionOfMatrixL) <= this.maxChange &&
					satisfySignRestriction(lagGOfMatrixW, lagGOfMatrixL,
							lagLOfMatrixL))
				return true;
		}
		return false;
	}

	private boolean satisfySignRestriction(float[][] lagGOfMatrixW, float[][] lagGOfMatrixL, float[][] lagLOfMatrixL) {
		return (checkGSigns(this.prevMatrixW, lagGOfMatrixW, 0.0F) &&
				checkGSigns(this.prevMatrixL, lagGOfMatrixL, 0.0F) &&
				checkLSigns(this.prevMatrixL, lagLOfMatrixL, 1.0F));
	}

	private boolean checkLSigns(float[][] matrix, float[][] lagLMatrix, float threshold) {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < (matrix[i]).length; j++) {
				float val = matrix[i][j];
				float lagL = lagLMatrix[i][j];
				if (val == threshold && lagL < 0.0F)
					return false;
			}
		}
		return true;
	}

	private boolean checkGSigns(float[][] matrix, float[][] lagGMatrix, float threshold) {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < (matrix[i]).length; j++) {
				float val = matrix[i][j];
				float lagG = lagGMatrix[i][j];
				if (val == threshold && lagG > 0.0F)
					return false;
			}
		}
		return true;
	}

	private float distanceBtwMatrices(float[][] matrix, float[][] anotherMatrix) {
		float distance = 0.0F;
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < (matrix[i]).length; j++)
				distance = (float)(distance + Math.pow((matrix[i][j] - anotherMatrix[i][j]), 2.0D));
		}
		distance = (float)Math.sqrt(distance);
		logger.debug("Distance: " + distance);
		return distance;
	}

	private float getStepOfL(float[][] matrix, float[][] optimalDirectionMatrix) {
		float step = 1.0F;
		for (int i = 0; i < optimalDirectionMatrix.length; i++) {
			for (int m = 0; m < (optimalDirectionMatrix[i]).length; m++) {
				if (optimalDirectionMatrix[i][m] > 0.0F) {
					float aStep = (1.0F - matrix[i][m]) /
							optimalDirectionMatrix[i][m];
					step = Math.min(step, aStep);
				}
			}
		}
		return step;
	}

	private float getStepOfG(float[][] matrix, float[][] optimalDirectionMatrix) {
		float step = 1.0F;
		for (int i = 0; i < optimalDirectionMatrix.length; i++) {
			for (int m = 0; m < (optimalDirectionMatrix[i]).length; m++) {
				if (optimalDirectionMatrix[i][m] < 0.0F) {
					float aStep = -matrix[i][m] / optimalDirectionMatrix[i][m];
					step = Math.min(step, aStep);
				}
			}
		}
		return step;
	}
}
