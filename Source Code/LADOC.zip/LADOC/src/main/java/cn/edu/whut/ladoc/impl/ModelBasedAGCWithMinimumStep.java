package cn.edu.whut.ladoc.impl;

import cn.edu.whut.ladoc.SharedLibrary;
import org.apache.log4j.Logger;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

public class ModelBasedAGCWithMinimumStep {
	public static Logger logger = Logger.getLogger(ModelBasedAGCWithMinimumStep.class);
	public static String MatrixLFilename = "matrx-L";
	public static String MatrixWFilename = "matrx-W";
	public static String MatrixLIdentifier = "L";
	public static String MatrixWIdentifier = "W";
	private float[][] prevMatrixL;
	private float[][] prevMatrixW;
	private float[][] matrixL;
	private float[][] matrixW;
	private float[][] topologyWeightMatrix;
	private int[][] incidenceMatrix;
	private float[][][] attributeWeightMatrix;
	private float alpha;
	private float beta;
	private float theta;
	private float phi;
	private float maxChange;
	private int maxLoops;
	private String saveFolder;
	boolean[][] droppedActiveGConstraintsOfMatrixW;
	boolean[][] droppedActiveGConstraintsOfMatrixL;
	boolean[][] droppedActiveLConstraintsOfMatrixL;

	public ModelBasedAGCWithMinimumStep(float[][] initMatrixL, float[][] initMatrixW, int[][] incidenceMatrix, float[][][] attributeWeightMatrix, float[][] topologyWeightMatrix, float alpha, float beta, float theta, float phi, float maxChange, int maxLoops, String saveFolder) {
		this.matrixL = initMatrixL;
		this.matrixW = initMatrixW;
		this.incidenceMatrix = incidenceMatrix;
		this.attributeWeightMatrix = attributeWeightMatrix;
		this.topologyWeightMatrix = topologyWeightMatrix;
		this.alpha = alpha;
		this.beta = beta;
		this.theta = theta;
		this.phi = phi;
		this.maxChange = maxChange;
		this.maxLoops = maxLoops;
		this.saveFolder = saveFolder;
	}

	public void run() {
		int currLoop = 1;
		this.prevMatrixL = new float[this.matrixL.length][(this.matrixL[0]).length];
		this.prevMatrixW = new float[this.matrixW.length][(this.matrixW[0]).length];
		this.droppedActiveGConstraintsOfMatrixW = new boolean[this.matrixL.length][(this.matrixL[0]).length];
		this.droppedActiveGConstraintsOfMatrixL = new boolean[this.matrixL.length][(this.matrixL[0]).length];
		this.droppedActiveLConstraintsOfMatrixL = new boolean[this.matrixL.length][(this.matrixL[0]).length];
		float[][] lagGOfMatrixW = new float[this.matrixW.length][(this.matrixW[0]).length];
		float[][] lagGOfMatrixL = new float[this.matrixL.length][(this.matrixL[0]).length];
		float[][] lagLOfMatrixL = new float[this.matrixL.length][(this.matrixL[0]).length];
		float[][] optimalDirectionOfMatrixW = new float[this.matrixW.length][(this.matrixW[0]).length];
		float[][] optimalDirectionOfMatrixL = new float[this.matrixL.length][(this.matrixL[0]).length];
		float[][] prevOptimalDirectionOfMatrixL = new float[this.matrixL.length][(this.matrixL[0]).length];
		boolean dropAllEligibleConstraints = true;
		while (!terminate(currLoop, optimalDirectionOfMatrixL,
				prevOptimalDirectionOfMatrixL, lagGOfMatrixW, lagGOfMatrixL,
				lagLOfMatrixL)) {
			boolean needUpdateW = false;
			if (distanceBtwMatrices(optimalDirectionOfMatrixL,
					prevOptimalDirectionOfMatrixL) > this.maxChange ||
					currLoop == 1) {
				regularUpdate(optimalDirectionOfMatrixL,
						prevOptimalDirectionOfMatrixL,
						optimalDirectionOfMatrixW, lagGOfMatrixW,
						lagGOfMatrixL, lagLOfMatrixL);
			} else if (!checkGSigns(this.matrixW, lagGOfMatrixW, 0.0F, null,
					dropAllEligibleConstraints, this.droppedActiveGConstraintsOfMatrixW)) {
				updateOptimalDirectionOfMatrixW(optimalDirectionOfMatrixW,
						lagGOfMatrixW);
				needUpdateW = true;
			} else {
				if (needUpdateW) {
					updateW(optimalDirectionOfMatrixW);
					needUpdateW = false;
				}
				if (checkGSigns(this.matrixL, lagGOfMatrixL, 0.0F, null,
						dropAllEligibleConstraints, this.droppedActiveGConstraintsOfMatrixL) &&
						checkLSigns(this.matrixL, lagLOfMatrixL, 1.0F, null,
								dropAllEligibleConstraints, this.droppedActiveLConstraintsOfMatrixL)) {
					logger.error("No violations of sign restriction are found for matrix L");
					continue;
				}
				updateOptimalDirectionOfMatrixL(optimalDirectionOfMatrixL,
						prevOptimalDirectionOfMatrixL, lagGOfMatrixL,
						lagLOfMatrixL);
				if (checkGSigns(this.matrixL, lagGOfMatrixL, 0.0F, null, false, null) &&
						checkLSigns(this.matrixL, lagLOfMatrixL, 1.0F, null,
								false, null))
					updateL(optimalDirectionOfMatrixL);
			}
			float objectiveScore = obtainObjectiveScore();
			logger.info("The score at #" + currLoop++ + " loop: " +
					objectiveScore);
		}
		if (this.saveFolder != null)
			save();
	}

	private void updateW(float[][] optimalDirectionOfMatrixW) {
		copy(this.prevMatrixW, this.matrixW);
		float[] stepWArray = getStepArrayOfGConstraints(this.prevMatrixW, optimalDirectionOfMatrixW);
		updateMatrix(this.matrixW, this.prevMatrixW, optimalDirectionOfMatrixW,
				stepWArray);
		checkMatrixW();
	}

	private void regularUpdate(float[][] optimalDirectionOfMatrixL, float[][] prevOptimalDirectionOfMatrixL, float[][] optimalDirectionOfMatrixW, float[][] lagGOfMatrixW, float[][] lagGOfMatrixL, float[][] lagLOfMatrixL) {
		if (this.phi > 0.0F) {
			updateOptimalDirectionOfMatrixW(optimalDirectionOfMatrixW,
					lagGOfMatrixW);
			updateW(optimalDirectionOfMatrixW);
		}
		updateOptimalDirectionOfMatrixL(optimalDirectionOfMatrixL,
				prevOptimalDirectionOfMatrixL, lagGOfMatrixL, lagLOfMatrixL);
		updateL(optimalDirectionOfMatrixL);
	}

	private void updateL(float[][] optimalDirectionOfMatrixL) {
		copy(this.prevMatrixL, this.matrixL);
		float[] stepArrayOfGConstraints = getStepArrayOfGConstraints(this.prevMatrixL, optimalDirectionOfMatrixL);
		float[] stepArrayOfLConstraints = getStepArrayOfLConstraints(this.prevMatrixL, optimalDirectionOfMatrixL);
		float[] stepArrayOfL = new float[stepArrayOfGConstraints.length];
		for (int i = 0; i < stepArrayOfL.length; i++)
			stepArrayOfL[i] = Math.min(stepArrayOfGConstraints[i], stepArrayOfLConstraints[i]);
		updateMatrix(this.matrixL, this.prevMatrixL, optimalDirectionOfMatrixL,
				stepArrayOfL);
		logger.debug("L step: " + stepArrayOfL);
	}

	private void checkMatrixW() {
		boolean needRenormalize = false;
		float sum = 0.0F;
		for (int i = 0; i < this.matrixW.length; i++) {
			needRenormalize = false;
			for (int j = 0; j < (this.matrixW[i]).length; j++) {
				if (this.matrixW[i][j] < 0.0F || this.matrixW[i][j] > 1.0F) {
					needRenormalize = true;
					break;
				}
				sum += this.matrixW[i][j];
			}
			if (!needRenormalize && sum != 1.0F)
				needRenormalize = true;
			if (needRenormalize)
				normalizeMatrxAtRow(this.matrixW, i);
		}
	}

	private void normalizeMatrxAtRow(float[][] matrix, int row) {
		float sum = 0.0F;
		int i;
		for (i = 0; i < (matrix[row]).length; i++) {
			if (matrix[row][i] > 0.0F)
				sum += matrix[row][i];
		}
		for (i = 0; i < (matrix[row]).length; i++) {
			if (matrix[row][i] > 0.0F) {
				matrix[row][i] = matrix[row][i] / sum;
			} else {
				matrix[row][i] = 0.0F;
			}
		}
	}

	private void copy(float[][] destMatrix, float[][] sourceMatrix) {
		for (int i = 0; i < sourceMatrix.length; i++) {
			for (int j = 0; j < (sourceMatrix[i]).length; j++)
				destMatrix[i][j] = sourceMatrix[i][j];
		}
	}

	public float[][] getMatrixL() {
		return this.matrixL;
	}

	public float[][] getMatrixW() {
		return this.matrixW;
	}

	private void save() {
		String filePath = String.valueOf(this.saveFolder) + File.separator + MatrixLFilename;
		SharedLibrary.saveMatrixToFile(this.matrixL, filePath);
		filePath = String.valueOf(this.saveFolder) + File.separator + MatrixWFilename;
		SharedLibrary.saveMatrixToFile(this.matrixW, filePath);
	}

	private float obtainObjectiveScore() {
		float score = 0.0F;
		float attributePart = 0.0F;
		for (int i = 0; i < this.matrixL.length; i++) {
			for (int k = 0; k < (this.matrixL[i]).length; k++) {
				for (int m = 0; m < this.attributeWeightMatrix.length; m++)
					attributePart = this.matrixL[i][k] * this.matrixW[i][m] *
							this.attributeWeightMatrix[m][i][k];
			}
		}
		float topologyPart = 0.0F;
		for (int j = 0; j < this.matrixL.length; j++) {
			for (int k = 0; k < (this.matrixL[j]).length; k++)
				topologyPart += this.matrixL[j][k] * this.incidenceMatrix[j][k] *
						this.matrixL[k][j] + this.topologyWeightMatrix[j][k];
		}
		float restrictionL = getSquareOfFrobenius(this.matrixL);
		float restrictionW = getSquareOfFrobenius(this.matrixW);
		score = this.alpha * attributePart + this.beta * topologyPart -
				this.theta * restrictionL / 2.0F - this.phi * restrictionW / 2.0F;
		return score;
	}

	private float getSquareOfFrobenius(float[][] matrix) {
		float sum = 0.0F;
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < (matrix[i]).length; j++)
				sum += matrix[i][j] * matrix[i][j];
		}
		return sum;
	}

	private float[] getStepArrayOfLConstraints(float[][] matrix, float[][] optimalDirectionMatrix) {
		float[] stepArray = new float[matrix.length];
		for (int i = 0; i < matrix.length; i++) {
			float stepL = getStepOfLConstraints(matrix[i], optimalDirectionMatrix[i], i);
			stepArray[i] = stepL;
		}
		return stepArray;
	}

	private float getStepOfLConstraints(float[] valArray, float[] optimalDirectionArray, int row) {
		float step = 1.0F;
		int minI = 0;
		boolean found = false;
		for (int i = 0; i < valArray.length; i++) {
			if (optimalDirectionArray[i] > 0.0F) {
				float aStep = (1.0F - valArray[i]) /
						optimalDirectionArray[i];
				aStep = SharedLibrary.roundWithTowDecimalPlaces(aStep);
				if (aStep < step) {
					minI = i;
					found = true;
				}
				step = Math.min(step, aStep);
			}
		}
		if (found)
			logger.debug("Min step of L constraints at " + row + " row is found at " +
					valArray[minI] + " with direction " +
					optimalDirectionArray[minI]);
		return step;
	}

	private void updateOptimalDirectionOfMatrixL(float[][] optimalDirectionOfMatrixL, float[][] prevOptimalDirectionOfMatrixL, float[][] lagGOfMatrixL, float[][] lagLOfMatrixL) {
		copy(prevOptimalDirectionOfMatrixL, optimalDirectionOfMatrixL);
		for (int i = 0; i < optimalDirectionOfMatrixL.length; i++) {
			for (int j = 0; j < (optimalDirectionOfMatrixL[i]).length; j++) {
				float l_i_j = this.matrixL[i][j];
				if (l_i_j == 0.0F &&
						!this.droppedActiveGConstraintsOfMatrixL[i][j]) {
					optimalDirectionOfMatrixL[i][j] = 0.0F;
					lagLOfMatrixL[i][j] = 0.0F;
					lagGOfMatrixL[i][j] = derivativeOverL_i_j(i, j);
				} else if (l_i_j == 1.0F &&
						!this.droppedActiveLConstraintsOfMatrixL[i][j]) {
					optimalDirectionOfMatrixL[i][j] = 0.0F;
					lagLOfMatrixL[i][j] = derivativeOverL_i_j(i, j);
					lagGOfMatrixL[i][j] = 0.0F;
				} else {
					optimalDirectionOfMatrixL[i][j] = derivativeOverL_i_j(i, j) /
							2.0F * this.theta;
					lagLOfMatrixL[i][j] = 0.0F;
					lagGOfMatrixL[i][j] = 0.0F;
				}
			}
		}
	}

	private float derivativeOverL_i_j(int i, int j) {
		float result = 0.0F;
		float sum_m = 0.0F;
		for (int m = 0; m < this.attributeWeightMatrix.length; m++)
			sum_m += this.matrixW[i][m] * this.attributeWeightMatrix[m][i][j];
		float incidenceWeight = this.incidenceMatrix[i][j] *
				this.prevMatrixL[j][i];
		result = this.alpha * sum_m +
				this.beta * (incidenceWeight + this.topologyWeightMatrix[i][j]) -
				this.theta * this.prevMatrixL[i][j];
		return SharedLibrary.roundWithTowDecimalPlaces(result);
	}

	private void updateMatrix(float[][] matrix, float[][] prevMatrix, float[][] directionMatrix, float[] stepArray) {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < (matrix[i]).length; j++) {
				matrix[i][j] = prevMatrix[i][j] + directionMatrix[i][j] * stepArray[i];
				matrix[i][j] =
						SharedLibrary.roundWithTowDecimalPlaces(matrix[i][j]);
			}
		}
	}

	private float[] getStepArrayOfGConstraints(float[][] matrix, float[][] optimalDirectionMatrix) {
		float[] stepArray = new float[matrix.length];
		for (int i = 0; i < matrix.length; i++) {
			float stepG = getStepOfGContraints(matrix[i], optimalDirectionMatrix[i], i);
			stepArray[i] = stepG;
		}
		return stepArray;
	}

	private float getStepOfGContraints(float[] valArray, float[] optimalDirectionArray, int row) {
		float step = 1.0F;
		int minI = 0;
		boolean found = false;
		for (int i = 0; i < valArray.length; i++) {
			if (optimalDirectionArray[i] < 0.0F) {
				float aStep = -valArray[i] / optimalDirectionArray[i];
				aStep = SharedLibrary.roundWithTowDecimalPlaces(aStep);
				if (aStep < step) {
					minI = i;
					found = true;
				}
				step = Math.min(step, aStep);
			}
		}
		if (found)
			logger.debug("Min step of G constraints at " + row + " row is found at " +
					valArray[minI] + " with direction " +
					optimalDirectionArray[minI]);
		return step;
	}

	private void updateOptimalDirectionOfMatrixW(float[][] optimalDirectionOfMatrixW, float[][] lagGOfMatrixW) {
		for (int i = 0; i < this.matrixW.length; i++) {
			float[] rowW = this.matrixW[i];
			float[] optimalDirectionOfRowW = optimalDirectionOfMatrixW[i];
			float[] lagGOfRowW = lagGOfMatrixW[i];
			float[] derivativeOverRowW = new float[rowW.length];
			float v_w_i = calV_W_I(rowW, i, derivativeOverRowW);
			for (int m = 0; m < rowW.length; m++) {
				if (rowW[m] > 0.0F ||
						this.droppedActiveGConstraintsOfMatrixW[i][m]) {
					lagGOfRowW[m] = 0.0F;
					optimalDirectionOfRowW[m] = (derivativeOverRowW[m] - v_w_i) /
							2.0F * this.phi;
				} else if (rowW[m] == 0.0F) {
					lagGOfRowW[m] = derivativeOverRowW[m] - v_w_i;
					optimalDirectionOfRowW[m] = 0.0F;
				} else {
					lagGOfRowW[m] = 0.0F;
					optimalDirectionOfRowW[m] = 0.0F;
				}
			}
		}
	}

	private float calV_W_I(float[] rowW, int rowIndex, float[] derivativeOverRowW) {
		float v_w_i = 0.0F;
		int count = 0;
		for (int m = 0; m < rowW.length; m++) {
			derivativeOverRowW[m] = derivativeOverW_i_m(rowIndex, m);
			if (rowW[m] > 0.0F ||
					this.droppedActiveGConstraintsOfMatrixW[rowIndex][m]) {
				v_w_i += derivativeOverRowW[m];
				count++;
			} else if (rowW[m] < 0.0F) {
				logger.error("w_i_m is less then 0 when i is " + rowIndex +
						" and m is " + m);
			}
		}
		if (count > 0)
			v_w_i /= count;
		return SharedLibrary.roundWithTowDecimalPlaces(v_w_i);
	}

	private float derivativeOverW_i_m(int rowIndex, int m) {
		float result = 0.0F;
		float sum_j = 0.0F;
		for (int j = 0; j < (this.prevMatrixL[rowIndex]).length; j++)
			sum_j += this.prevMatrixL[rowIndex][j] *
					this.attributeWeightMatrix[m][rowIndex][j];
		result = this.alpha * sum_j - this.phi * this.prevMatrixW[rowIndex][m];
		return SharedLibrary.roundWithTowDecimalPlaces(result);
	}

	private boolean terminate(int currLoop, float[][] optimalDirectionOfMatrixL, float[][] prevOptimalDirectionOfMatrixL, float[][] lagGOfMatrixW, float[][] lagGOfMatrixL, float[][] lagLOfMatrixL) {
		if (currLoop > 1) {
			if (currLoop == this.maxLoops)
				return true;
			if (distanceBtwMatrices(optimalDirectionOfMatrixL,
					prevOptimalDirectionOfMatrixL) <= this.maxChange &&
					satisfySignRestriction(lagGOfMatrixW, lagGOfMatrixL,
							lagLOfMatrixL))
				return true;
		}
		return false;
	}

	private boolean satisfySignRestriction(float[][] lagGOfMatrixW, float[][] lagGOfMatrixL, float[][] lagLOfMatrixL) {
		return (checkGSigns(this.prevMatrixW, lagGOfMatrixW, 0.0F,
				MatrixWIdentifier, false, null) &&
				checkGSigns(this.prevMatrixL, lagGOfMatrixL, 0.0F,
						MatrixLIdentifier, false, null) &&
				checkLSigns(this.prevMatrixL, lagLOfMatrixL, 1.0F,
						MatrixLIdentifier, false, null));
	}

	private boolean checkLSigns(float[][] matrix, float[][] lagLMatrix, float threshold, String matrixIdentifier, boolean checkAll, boolean[][] droppedActiveConstraintsOfMatrix) {
		Set<String> constraintsToBeDropped = new HashSet<String>();
		boolean result = true;
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < (matrix[i]).length; j++) {
				float val = matrix[i][j];
				float lagL = lagLMatrix[i][j];
				if (val == threshold && lagL < 0.0F) {
					String constraintString = String.valueOf(i) + "-" + j;
					if (result)
						result = false;
					if (matrixIdentifier != null)
						logger.debug("L sign restriction of matrix " +
								matrixIdentifier + " is not satisfied at " +
								constraintString);
					if (droppedActiveConstraintsOfMatrix != null &&
							!droppedActiveConstraintsOfMatrix[i][j] &&
							!constraintsToBeDropped.contains(constraintString))
						droppedActiveConstraintsOfMatrix[i][j] = true;
					if (checkAll) {
						constraintsToBeDropped.add(constraintString);
						constraintsToBeDropped.add(String.valueOf(j) + "-" + i);
					} else {
						return result;
					}
				}
			}
		}
		return result;
	}

	private boolean checkGSigns(float[][] matrix, float[][] lagGMatrix, float threshold, String matrixIdentifier, boolean checkAll, boolean[][] droppedActiveConstraintsOfMatrix) {
		Set<String> constraintsToBeDropped = new HashSet<String>();
		boolean result = true;
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < (matrix[i]).length; j++) {
				float val = matrix[i][j];
				float lagG = lagGMatrix[i][j];
				if (val == threshold && lagG > 0.0F) {
					String constraintString = String.valueOf(i) + "-" + j;
					if (result)
						result = false;
					if (matrixIdentifier != null)
						logger.debug("G sign restriction of matrix " +
								matrixIdentifier + " is not satisfied at " +
								constraintString);
					if (droppedActiveConstraintsOfMatrix != null &&
							!droppedActiveConstraintsOfMatrix[i][j] &&
							!constraintsToBeDropped.contains(constraintString))
						droppedActiveConstraintsOfMatrix[i][j] = true;
					if (checkAll) {
						constraintsToBeDropped.add(constraintString);
						constraintsToBeDropped.add(String.valueOf(j) + "-" + i);
					} else {
						return result;
					}
				}
			}
		}
		return result;
	}

	private float distanceBtwMatrices(float[][] matrix, float[][] anotherMatrix) {
		float distance = 0.0F;
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < (matrix[i]).length; j++)
				distance = (float)(distance + Math.pow((matrix[i][j] - anotherMatrix[i][j]), 2.0D));
		}
		distance = (float)Math.sqrt(distance);
		logger.debug("Distance: " + distance);
		return distance;
	}
}
