package cn.edu.whut.ladoc.impl;

import org.apache.log4j.Logger;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class SimpleClustering {
	public static Logger logger = Logger.getLogger(SimpleClustering.class);
	private int minSize;
	private int[][] incidenceMatrix;
	private float[][] matrixL;
	private Map<Integer, String> id2VertexMap;
	private Set<Set<String>> clusterSet;
	private float minWeight;
	private boolean isAnd;

	public SimpleClustering(int[][] incidenceMatrix, float[][] matrixL, Map<Integer, String> id2VertexMap, int minSize) {
		this.incidenceMatrix = incidenceMatrix;
		this.matrixL = matrixL;
		this.id2VertexMap = id2VertexMap;
		this.minSize = minSize;
		this.isAnd = false;
		this.minWeight = 0.0F;
	}

	public SimpleClustering(int[][] incidenceMatrix, float[][] matrixL, Map<Integer, String> id2VertexMap, int minSize, float minWeight, boolean isAnd) {
		this.incidenceMatrix = incidenceMatrix;
		this.matrixL = matrixL;
		this.id2VertexMap = id2VertexMap;
		this.minSize = minSize;
		this.minWeight = minWeight;
		this.isAnd = isAnd;
	}

	public void run() {
		this.clusterSet = new HashSet<Set<String>>();
		Set<Integer> processedVertexSet = new HashSet<Integer>();
		for (int i = 0; i < this.incidenceMatrix.length; i++) {
			if (!processedVertexSet.contains(Integer.valueOf(i))) {
				processedVertexSet.add(Integer.valueOf(i));
				Set<String> cluster = new HashSet<String>();
				cluster.add(this.id2VertexMap.get(Integer.valueOf(i)));
				dfs(i, processedVertexSet, cluster);
				if (cluster.size() >= this.minSize)
					this.clusterSet.add(cluster);
			}
		}
		logger.info("Total " + this.clusterSet.size() +
				" clusters are discovered");
	}

	private void dfs(int vIndex, Set<Integer> processedVertexSet, Set<String> cluster) {
		for (int vertex = 0; vertex < (this.incidenceMatrix[vIndex]).length; vertex++) {
			if (vertex != vIndex && !processedVertexSet.contains(Integer.valueOf(vertex)))
				if (checkEligibility(vIndex, vertex)) {
					processedVertexSet.add(Integer.valueOf(vertex));
					cluster.add(this.id2VertexMap.get(Integer.valueOf(vertex)));
					dfs(vertex, processedVertexSet, cluster);
				}
		}
	}

	private boolean checkEligibility(int vIndex, int vertex) {
		if (this.isAnd)
			return (this.incidenceMatrix[vIndex][vertex] == 1 &&
					this.matrixL[vIndex][vertex] >= this.minWeight && this.matrixL[vertex][vIndex] >= this.minWeight);
		return (this.incidenceMatrix[vIndex][vertex] == 1 && (
				this.matrixL[vIndex][vertex] >= this.minWeight || this.matrixL[vertex][vIndex] >= this.minWeight));
	}

	public Set<Set<String>> getClusterSet() {
		return this.clusterSet;
	}
}
