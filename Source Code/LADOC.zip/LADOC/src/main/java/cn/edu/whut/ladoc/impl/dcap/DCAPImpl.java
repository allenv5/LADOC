package cn.edu.whut.ladoc.impl.dcap;

import cn.edu.whut.ladoc.SharedLibrary;
import org.apache.log4j.Logger;

import java.io.File;

public class DCAPImpl {
	public static Logger logger = Logger.getLogger(DCAPImpl.class);
	public static String MatrixRFilename = "matrix-R";
	public static String MatrixWFilename = "matrix-W";
	public static String MatrixRIdentifier = "R";
	public static String MatrixWIdentifier = "W";
	private float[][] matrixR;
	private float[][] matrixW;
	private float[][] matrixD;
	private float[][] prevMatrixR;
	private float[][] prevMatrixW;
	private int[][] matrixT;
	private float[][][] matrixA;
	private float alpha;
	private float beta;
	private float phi;
	private float theta;
	private float maxChange;
	private int maxLoops;
	private String saveFolder;
	boolean multiTasking;

	public DCAPImpl(float[][] initMatrixR, float[][] initMatrixW, int[][] matrixT, float[][][] matrixA,
					float[][] matrixD, float alpha, float beta, float phi, float theta, float maxChange,
					int maxLoops, String saveFolder, boolean multiTasking) {
		this.matrixR = initMatrixR;
		this.matrixW = initMatrixW;
		this.matrixT = matrixT;
		this.matrixA = matrixA;
		this.matrixD = matrixD;
		this.alpha = alpha;
		this.beta = beta;
		this.phi = phi;
		this.theta = theta;
		this.maxChange = maxChange;
		this.maxLoops = maxLoops;
		this.saveFolder = saveFolder;
		this.multiTasking = multiTasking;
	}

	public void run() {
		int currLoop = 1;
		this.prevMatrixR = new float[this.matrixR.length][(this.matrixR[0]).length];
		this.prevMatrixW = new float[this.matrixW.length][(this.matrixW[0]).length];
		float prevObjectiveScore = 0.0F, currObjectiveScore = 0.0F;
		float[][] lagGOfMatrixR = new float[this.matrixR.length][(this.matrixR[0]).length];
		float[][] optimalDirectionOfMatrixR = new float[this.matrixR.length][(this.matrixR[0]).length];
		while (!terminate(currLoop, Math.abs(currObjectiveScore - prevObjectiveScore))) {
			copy(this.prevMatrixR, this.matrixR);
			copy(this.prevMatrixW, this.matrixW);
			prevObjectiveScore = currObjectiveScore;
			int i;
			for (i = 0; i < this.matrixT.length; i++) {
				boolean[] activeConstraints = new boolean[(this.matrixR[i]).length];
				boolean satisfySignRestrictions = true;
				setActiveConstraints(activeConstraints, this.prevMatrixR[i]);
				do {
					updateDeltaR_iAndLagranges(i, activeConstraints, lagGOfMatrixR, optimalDirectionOfMatrixR);
					satisfySignRestrictions = checkSignRestrictions(activeConstraints, lagGOfMatrixR[i]);
				} while (zero(optimalDirectionOfMatrixR[i]) && !satisfySignRestrictions);
				float lambda_i = getLambda_i(this.matrixR[i], optimalDirectionOfMatrixR[i]);
				updateR_i(i, optimalDirectionOfMatrixR[i], lambda_i);
			}
			SharedLibrary.normalizeMatrix(this.matrixR);
			for (i = 0; i < this.matrixW.length; i++) {
				for (int j = 0; j < (this.matrixW[i]).length; j++) {
					float derivativeOverW_i_j = derivativeOverW_i_j(i, j);
					if (derivativeOverW_i_j > 1.0F) {
						this.matrixW[i][j] = 1.0F;
					} else if (derivativeOverW_i_j < 0.0F) {
						this.matrixW[i][j] = 0.0F;
					} else {
						this.matrixW[i][j] = roundTo2Decimals(derivativeOverW_i_j);
					}
				}
			}
			currObjectiveScore = obtainObjectiveScore();
			logger.info("The score at #" + currLoop++ + " loop: " + currObjectiveScore);
		}
	}

	private float derivativeOverW_i_j(int i, int j) {
		float alphaPart = 0.0F;
		for (int k = 0; k < this.matrixW.length; k++)
			alphaPart += this.prevMatrixW[i][k] * this.prevMatrixW[j][k] *
					this.matrixT[i][k] * this.matrixT[j][k];
		alphaPart *= this.matrixD[i][j];
		float betaPart = 0.0F;
		for (int m = 0; m < this.matrixA.length; m++)
			betaPart += this.matrixA[m][i][j] * this.matrixR[i][m];
		float derivativeOverW_i_j = (this.alpha * alphaPart + this.beta *
				betaPart) /
				this.phi;
		return derivativeOverW_i_j;
	}

	private void updateR_i(int i, float[] optimalDirectionOfR_i, float lambda_i) {
		for (int m = 0; m < (this.matrixR[i]).length; m++)
			this.matrixR[i][m] = this.prevMatrixR[i][m] + lambda_i *
					optimalDirectionOfR_i[m];
		normalizeR_iWith2Decimals(i);
	}

	private void normalizeR_iWith2Decimals(int i) {
		float total = 0.0F;
		byte b;
		int j;
		float[] arrayOfFloat;
		for (j = (arrayOfFloat = this.matrixR[i]).length, b = 0; b < j; ) {
			float element = arrayOfFloat[b];
			total += element;
			b++;
		}
		for (int m = 0; m < (this.matrixR[i]).length; m++)
			this.matrixR[i][m] = roundTo2Decimals(this.matrixR[i][m] / total);
	}

	private float roundTo2Decimals(float f) {
		return (int)(f * 100.0F) / 100.0F;
	}

	private float getLambda_i(float[] r_i, float[] delta_r_i) {
		float lambda_i = 1.0F;
		for (int m = 0; m < delta_r_i.length; m++) {
			float delta_r_i_m = delta_r_i[m];
			if (delta_r_i_m < 0.0F)
				lambda_i = Math.min(lambda_i, -r_i[m] / delta_r_i_m);
		}
		return lambda_i;
	}

	private boolean zero(float[] fs) {
		byte b;
		int i;
		float[] arrayOfFloat;
		for (i = (arrayOfFloat = fs).length, b = 0; b < i; ) {
			float f = arrayOfFloat[b];
			if (f != 0.0F)
				return false;
			b++;
		}
		return true;
	}

	private boolean checkSignRestrictions(boolean[] activeConstraints, float[] lagGOfR_i) {
		for (int m = 0; m < activeConstraints.length; m++) {
			if (activeConstraints[m] && lagGOfR_i[m] > 0.0F) {
				activeConstraints[m] = false;
				return false;
			}
		}
		return true;
	}

	private void updateDeltaR_iAndLagranges(int i, boolean[] activeConstraints, float[][] lagGOfMatrixR, float[][] optimalDirectionOfMatrixR) {
		float lagrangeForEqualityOfDeltaR_i = getLagrangeForEqualityOfDeltaR_i(i, activeConstraints);
		for (int m = 0; m < activeConstraints.length; m++) {
			float result = derivativeOverR_i_m(i, m) - lagrangeForEqualityOfDeltaR_i;
			result = roundTo2Decimals(result);
			if (activeConstraints[m]) {
				optimalDirectionOfMatrixR[i][m] = 0.0F;
				lagGOfMatrixR[i][m] = result;
			} else {
				result /= this.theta;
				result = roundTo2Decimals(result);
				optimalDirectionOfMatrixR[i][m] = result;
				lagGOfMatrixR[i][m] = 0.0F;
			}
		}
	}

	private float getLagrangeForEqualityOfDeltaR_i(int i, boolean[] activeConstraints) {
		float lagrange = 0.0F;
		int count = 0;
		for (int m = 0; m < activeConstraints.length; m++) {
			if (!activeConstraints[m]) {
				lagrange += derivativeOverR_i_m(i, m);
				count++;
			}
		}
		if (count > 0) {
			lagrange /= count;
		} else {
			logger.error("The lagrange for equality of delta r_" + i +
					" is zero ");
		}
		return lagrange;
	}

	private float derivativeOverR_i_m(int i, int m) {
		float derivative = 0.0F;
		float c_i_m = 0.0F;
		for (int j = 0; j < (this.prevMatrixW[i]).length; j++)
			c_i_m += this.prevMatrixW[i][j] * this.matrixA[m][i][j];
		derivative = c_i_m - this.theta * this.prevMatrixR[i][m];
		return derivative;
	}

	private void setActiveConstraints(boolean[] activeConstraints, float[] preferenceVector) {
		for (int i = 0; i < preferenceVector.length; i++)
			activeConstraints[i] = (preferenceVector[i] == 0.0F);
	}

	private void copy(float[][] destMatrix, float[][] sourceMatrix) {
		for (int i = 0; i < sourceMatrix.length; i++) {
			for (int j = 0; j < (sourceMatrix[i]).length; j++)
				destMatrix[i][j] = sourceMatrix[i][j];
		}
	}

	public float[][] getMatrixR() {
		return this.matrixR;
	}

	public float[][] getMatrixW() {
		return this.matrixW;
	}

	private void save() {
		String filePath = String.valueOf(this.saveFolder) + File.separator + MatrixRFilename;
		SharedLibrary.saveMatrixToFile(this.matrixR, filePath);
		filePath = String.valueOf(this.saveFolder) + File.separator + MatrixWFilename;
		SharedLibrary.saveMatrixToFile(this.matrixW, filePath);
	}

	private float obtainObjectiveScore() {
		float score = 0.0F;
		float alphaPart = 0.0F;
		for (int i = 0; i < this.matrixW.length; i++) {
			for (int k = 0; k < (this.matrixW[i]).length; k++) {
				for (int m = 0; m < (this.matrixW[i]).length; m++)
					alphaPart += this.matrixD[i][k] * this.matrixW[i][k] *
							this.matrixW[i][m] * this.matrixW[k][m] *
							this.matrixT[i][m] * this.matrixT[k][m];
			}
		}
		float betaPart = 0.0F;
		for (int j = 0; j < this.matrixW.length; j++) {
			for (int k = 0; k < (this.matrixW[j]).length; k++) {
				for (int m = 0; m < this.matrixA.length; m++)
					betaPart += this.matrixW[j][k] * this.matrixA[m][j][k] + this.matrixR[j][m];
			}
		}
		float restrictionR = getSquareOfFrobenius(this.matrixR);
		float restrictionW = getSquareOfFrobenius(this.matrixW);
		score = this.alpha * alphaPart + this.beta * betaPart -
				this.phi * restrictionW / 2.0F - this.theta * restrictionR / 2.0F;
		return score;
	}

	private float getSquareOfFrobenius(float[][] matrix) {
		float sum = 0.0F;
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < (matrix[i]).length; j++)
				sum += matrix[i][j] * matrix[i][j];
		}
		return sum;
	}

	private boolean terminate(int currLoop, float diffInObjScore) {
		if (currLoop > 1) {
			if (currLoop >= this.maxLoops)
				return true;
			if (diffInObjScore <= this.maxChange)
				return true;
		}
		return false;
	}
}
