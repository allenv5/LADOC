package cn.edu.whut.ladoc.impl.dcap;

import java.io.File;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import hk.polyu.cslhu.model_based_agc.SharedLibrary;

public class ParrallelDCAPImpl {
	public static Logger logger = Logger.getLogger(ParrallelDCAPImpl.class);
	public static String MatrixRFilename = "matrx-R";
	public static String MatrixWFilename = "matrx-W";
	public static String MatrixRIdentifier = "R";
	public static String MatrixWIdentifier = "W";

	private float[][] matrixR, matrixW, matrixD;
	private float[][] prevMatrixR, prevMatrixW;
	private int[][] matrixT;
	private float[][][] matrixA;
	private float alpha, beta, phi, theta, maxChange;
	private int maxLoops, numThreads;
	private String saveFolder;

	/**
	 * Constructor
	 * 
	 * @param initMatrixR
	 * @param initMatrixW
	 * @param incidenceMatrix
	 * @param attributeWeightMatrix
	 * @param alpha
	 * @param beta
	 * @param theta
	 * @param phi
	 * @param maxChange
	 * @param maxLoops
	 * @param saveFolder
	 */
	public ParrallelDCAPImpl(float[][] initMatrixR, float[][] initMatrixW, int[][] matrixT, float[][][] matrixA,
			float[][] matrixD, float alpha, float beta, float phi, float theta, float maxChange, int maxLoops,
			int numThreads, String saveFolder) {
		this.matrixR = initMatrixR;
		this.matrixW = initMatrixW;
		this.matrixT = matrixT;
		this.matrixA = matrixA;
		this.matrixD = matrixD;
		this.alpha = alpha;
		this.beta = beta;
		this.phi = phi;
		this.theta = theta;
		this.maxChange = maxChange;
		this.maxLoops = maxLoops;
		this.numThreads = numThreads;
		this.saveFolder = saveFolder;
	}

	/**
	 * The main flow of DCAP
	 */
	public void run() {
		int currLoop = 1;

		this.prevMatrixR = new float[this.matrixR.length][this.matrixR[0].length];
		this.prevMatrixW = new float[this.matrixW.length][this.matrixW[0].length];

		float prevObjectiveScore = 0, currObjectiveScore = 0;
		float[][] lagGOfMatrixR = new float[this.matrixR.length][this.matrixR[0].length];
		float[][] optimalDirectionOfMatrixR = new float[this.matrixR.length][this.matrixR[0].length];

		while (!terminate(currLoop, Math.abs(currObjectiveScore - prevObjectiveScore))) {
			copy(this.prevMatrixR, this.matrixR);
			copy(this.prevMatrixW, this.matrixW);
			prevObjectiveScore = currObjectiveScore;

			// update the preference vector in R for each vertex
			updateR(optimalDirectionOfMatrixR, lagGOfMatrixR);

			// update matrix W
			updateW();

			// calculate the objective function
			currObjectiveScore = obtainObjectiveScore();
			logger.info("The score at #" + currLoop++ + " loop: " + currObjectiveScore + " at " + new Date().toString());
		}

		// if (this.saveFolder != null)
		// this.save();
	}

	private void updateW() {
		// TODO Auto-generated method stub
		int[][] threadSlots = getThreadSlots(this.matrixW.length, this.numThreads);

		// setup thread pool
		ExecutorService executor = Executors.newFixedThreadPool(this.numThreads);
		for (int i = 0; i < threadSlots.length; i++) {
			int beginIndex = threadSlots[i][0];
			int endIndex = threadSlots[i][1];

			Runnable aThread = new UpdateWThread(beginIndex, endIndex, this.matrixR, this.matrixW, this.matrixD,
					this.prevMatrixW, this.matrixT, this.matrixA, this.alpha, this.beta, this.phi);
			executor.execute(aThread);
		}

		// wait till the executor finishes all threads
		executor.shutdown();
		while (!executor.isTerminated()) {
			try {
				executor.awaitTermination(10, TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private void updateR(float[][] optimalDirectionOfMatrixR, float[][] lagGOfMatrixR) {
		// TODO Auto-generated method stub
		int[][] threadSlots = getThreadSlots(this.matrixT.length, this.numThreads);

		// setup thread pool
		ExecutorService executor = Executors.newFixedThreadPool(this.numThreads);
		for (int i = 0; i < threadSlots.length; i++) {
			int beginIndex = threadSlots[i][0];
			int endIndex = threadSlots[i][1];

			Runnable aThread = new UpdateRThread(beginIndex, endIndex, this.matrixR, this.prevMatrixR, this.prevMatrixW,
					optimalDirectionOfMatrixR, lagGOfMatrixR, threadSlots, this.matrixA, this.theta);
			executor.execute(aThread);
		}

		// wait till the executor finishes all threads
		executor.shutdown();
		while (!executor.isTerminated()) {
			try {
				executor.awaitTermination(10, TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private int[][] getThreadSlots(int numInstances, int numThreads2) {
		// TODO Auto-generated method stub
		int[][] threadSlots = null;

		if (numInstances <= numThreads) {
			threadSlots = new int[numInstances][2];

			for (int i = 0; i < numInstances; i++) {
				threadSlots[i][0] = i;
				threadSlots[i][1] = i + 1;
			}
		} else {
			threadSlots = new int[numThreads][2];
			int numItemsInEachThread = Math.round(numInstances / numThreads);
			int remainder = numInstances - numItemsInEachThread * numThreads;

			// setup thread pool
			for (int i = 0; i < numThreads; i++) {
				int extra = i < remainder ? i : remainder;
				int beginIndex = numItemsInEachThread * i + extra;
				int increasement = numItemsInEachThread + (i < remainder ? 1 : 0);
				int endIndex = i == numThreads - 1 ? numInstances : (beginIndex + increasement);

				threadSlots[i][0] = beginIndex;
				threadSlots[i][1] = endIndex;
			}
		}

		return threadSlots;
	}

	public static float roundTo2Decimals(float f) {
		// TODO Auto-generated method stub
		return ((int) (f * 100)) / 100f;
	}

	private void copy(float[][] destMatrix, float[][] sourceMatrix) {
		// TODO Auto-generated method stub
		for (int i = 0; i < sourceMatrix.length; i++) {
			for (int j = 0; j < sourceMatrix[i].length; j++) {
				destMatrix[i][j] = sourceMatrix[i][j];
			}
		}
	}

	/**
	 * Get matrix R
	 * 
	 * @return
	 */
	public float[][] getMatrixR() {
		return matrixR;
	}

	/**
	 * Get matrix W
	 * 
	 * @return
	 */
	public float[][] getMatrixW() {
		return matrixW;
	}

	private void save() {
		// TODO Auto-generated method stub

		// save matrx L
		String filePath = this.saveFolder + File.separator + MatrixRFilename;
		SharedLibrary.saveMatrixToFile(this.matrixR, filePath);

		// save matrx W
		filePath = this.saveFolder + File.separator + MatrixWFilename;
		SharedLibrary.saveMatrixToFile(this.matrixW, filePath);
	}

	private float obtainObjectiveScore() {
		// TODO Auto-generated method stub
		// compute the parts of alpha and beta
		float[] alphaBetaScoreArray = new float[this.numThreads];

		int[][] threadSlots = getThreadSlots(this.matrixW.length, this.numThreads);

		// setup thread pool
		ExecutorService executor = Executors.newFixedThreadPool(this.numThreads);
		for (int i = 0; i < threadSlots.length; i++) {
			int beginIndex = threadSlots[i][0];
			int endIndex = threadSlots[i][1];

			Runnable aThread = new ComputeObjScoreThread(beginIndex, endIndex, i, alphaBetaScoreArray, this.matrixR,
					this.matrixW, this.matrixD, this.matrixT, this.matrixA, this.alpha, this.beta);
			executor.execute(aThread);
		}

		// wait till the executor finishes all threads
		executor.shutdown();
		while (!executor.isTerminated()) {
			try {
				executor.awaitTermination(10, TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		// score
		float alphaBetaScoreSumArray = 0;
		for (float score : alphaBetaScoreArray)
			alphaBetaScoreSumArray += score;

		// restrictions
		float restrictionR = getSquareOfFrobenius(this.matrixR);
		float restrictionW = getSquareOfFrobenius(this.matrixW);

		// the score
		float score = alphaBetaScoreSumArray - this.phi * restrictionW / 2 - this.theta * restrictionR / 2;

		return score;
	}

	private float getSquareOfFrobenius(float[][] matrix) {
		// TODO Auto-generated method stub
		float sum = 0;

		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				sum += matrix[i][j] * matrix[i][j];
			}
		}

		return sum;
	}

	/**
	 * Check whether the loop should be terminated
	 * 
	 * @param currLoop
	 * @param optimalDirectionOfMatrixL
	 * @param prevOptimalDirectionOfMatrixL
	 * @param lagGOfMatrixW
	 * @param lagGOfMatrixL
	 * @param lagLOfMatrixL
	 * @return true if terminate conditions are satisfied; false otherwise
	 */
	private boolean terminate(int currLoop, float diffInObjScore) {
		// TODO Auto-generated method stub
		if (currLoop > 1) {
			if (currLoop == this.maxLoops)
				return true;

			if (diffInObjScore <= this.maxChange)
				return true;
		}

		return false;
	}
}

class UpdateRThread implements Runnable {
	public static Logger logger = Logger.getLogger(UpdateRThread.class);

	private int beginIndex, endIndex;
	private float[][] matrixR;
	private float[][] prevMatrixR, prevMatrixW, optimalDirectionOfMatrixR, lagGOfMatrixR;
	private int[][] matrixT;
	private float[][][] matrixA;
	private float theta;

	public UpdateRThread(int beginIndex, int endIndex, float[][] matrixR, float[][] prevMatrixR, float[][] prevMatrixW,
			float[][] optimalDirectionOfMatrixR, float[][] lagGOfMatrixR, int[][] matrixT, float[][][] matrixA,
			float theta) {
		this.beginIndex = beginIndex;
		this.endIndex = endIndex;
		this.matrixR = matrixR;
		this.prevMatrixR = prevMatrixR;
		this.prevMatrixW = prevMatrixW;
		this.optimalDirectionOfMatrixR = optimalDirectionOfMatrixR;
		this.lagGOfMatrixR = lagGOfMatrixR;
		this.matrixT = matrixT;
		this.matrixA = matrixA;
		this.theta = theta;
	}

	public void run() {
		// TODO Auto-generated method stub
		for (int i = this.beginIndex; i < this.endIndex; i++) {
			boolean[] activeConstraints = new boolean[this.matrixR[i].length];
			boolean satisfySignRestrictions = true;

			// update active constraints
			setActiveConstraints(activeConstraints, this.prevMatrixR[i]);

			do {
				// obtain optimal directions and lagarange multipliers
				updateDeltaR_iAndLagranges(i, activeConstraints, lagGOfMatrixR, optimalDirectionOfMatrixR);

				satisfySignRestrictions = checkSignRestrictions(activeConstraints, lagGOfMatrixR[i]);
			} while (zero(optimalDirectionOfMatrixR[i]) && !satisfySignRestrictions);

			// obtain lambda_i
			float lambda_i = getLambda_i(this.matrixR[i], optimalDirectionOfMatrixR[i]);

			// update r_i
			updateR_i(i, optimalDirectionOfMatrixR[i], lambda_i);
		}
	}

	private void setActiveConstraints(boolean[] activeConstraints, float[] preferenceVector) {
		// the elements equal to zero will be considered as active constraints
		for (int i = 0; i < preferenceVector.length; i++)
			activeConstraints[i] = preferenceVector[i] == 0;
	}

	private void updateDeltaR_iAndLagranges(int i, boolean[] activeConstraints, float[][] lagGOfMatrixR,
			float[][] optimalDirectionOfMatrixR) {
		// TODO Auto-generated method stub
		float lagrangeForEqualityOfDeltaR_i = getLagrangeForEqualityOfDeltaR_i(i, activeConstraints);

		for (int m = 0; m < activeConstraints.length; m++) {
			float result = derivativeOverR_i_m(i, m) - lagrangeForEqualityOfDeltaR_i;
			result = ParrallelDCAPImpl.roundTo2Decimals(result);

			// for active constraints
			if (activeConstraints[m]) {
				optimalDirectionOfMatrixR[i][m] = 0;
				lagGOfMatrixR[i][m] = result;
			}
			// for inactive constraints
			else {
				result /= this.theta;
				result = ParrallelDCAPImpl.roundTo2Decimals(result);

				optimalDirectionOfMatrixR[i][m] = result;
				lagGOfMatrixR[i][m] = 0;
			}
		}
	}

	private float getLagrangeForEqualityOfDeltaR_i(int i, boolean[] activeConstraints) {
		// TODO Auto-generated method stub
		float lagrange = 0;
		int count = 0;

		for (int m = 0; m < activeConstraints.length; m++) {
			if (!activeConstraints[m]) {
				lagrange += derivativeOverR_i_m(i, m);
				count++;
			}
		}

		if (count > 0)
			lagrange = lagrange / count;
		else
			logger.error("The lagrange for equality of delta r_" + i + " is zero ");

		return lagrange;
	}

	private float derivativeOverR_i_m(int i, int m) {
		// TODO Auto-generated method stub
		float derivative = 0;

		// c_i_m
		float c_i_m = 0;
		for (int j = 0; j < this.prevMatrixW[i].length; j++)
			c_i_m += this.prevMatrixW[i][j] * this.matrixA[m][i][j];

		derivative = c_i_m - this.theta * this.prevMatrixR[i][m];

		return derivative;
	}

	private boolean checkSignRestrictions(boolean[] activeConstraints, float[] lagGOfR_i) {
		// TODO Auto-generated method stub
		for (int m = 0; m < activeConstraints.length; m++) {
			if (activeConstraints[m] && lagGOfR_i[m] > 0) {
				activeConstraints[m] = false;
				return false;
			}
		}

		return true;
	}

	private float getLambda_i(float[] r_i, float[] delta_r_i) {
		// TODO Auto-generated method stub
		float lambda_i = 1;

		for (int m = 0; m < delta_r_i.length; m++) {
			float delta_r_i_m = delta_r_i[m];

			if (delta_r_i_m < 0)
				lambda_i = Math.min(lambda_i, -r_i[m] / delta_r_i_m);
		}

		return lambda_i;
	}

	private boolean zero(float[] fs) {
		// TODO Auto-generated method stub
		for (float f : fs)
			if (f != 0)
				return false;

		return true;
	}

	private void updateR_i(int i, float[] optimalDirectionOfR_i, float lambda_i) {
		// TODO Auto-generated method stub
		for (int m = 0; m < this.matrixR[i].length; m++)
			this.matrixR[i][m] = this.prevMatrixR[i][m] + lambda_i * optimalDirectionOfR_i[m];

		normalizeR_iWith2Decimals(i);
	}

	private void normalizeR_iWith2Decimals(int i) {
		// TODO Auto-generated method stub
		float total = 0;

		for (float element : this.matrixR[i])
			total += element;

		for (int m = 0; m < this.matrixR[i].length; m++)
			this.matrixR[i][m] = ParrallelDCAPImpl.roundTo2Decimals(this.matrixR[i][m] / total);
	}

}

class UpdateWThread implements Runnable {
	public static Logger logger = Logger.getLogger(UpdateWThread.class);

	private float[][] matrixR, matrixW, matrixD;
	private float[][] prevMatrixW;
	private int[][] matrixT;
	private float[][][] matrixA;
	private float alpha, beta, phi;
	private int beginIndex, endIndex;

	public UpdateWThread(int beginIndex, int endIndex, float[][] matrixR, float[][] matrixW, float[][] matrixD,
			float[][] prevMatrixW, int[][] matrixT, float[][][] matrixA, float alpha, float beta, float phi) {
		this.beginIndex = beginIndex;
		this.endIndex = endIndex;
		this.matrixR = matrixR;
		this.matrixW = matrixW;
		this.matrixD = matrixD;
		this.prevMatrixW = prevMatrixW;
		this.matrixT = matrixT;
		this.matrixA = matrixA;
		this.alpha = alpha;
		this.beta = beta;
		this.phi = phi;
	}

	public void run() {
		// TODO Auto-generated method stub
		for (int i = this.beginIndex; i < this.endIndex; i++) {
			for (int j = 0; j < this.matrixW[i].length; j++) {
				float derivativeOverW_i_j = derivativeOverW_i_j(i, j);

				if (derivativeOverW_i_j > 1)
					this.matrixW[i][j] = 1;
				else if (derivativeOverW_i_j < 0)
					this.matrixW[i][j] = 0;
				else
					this.matrixW[i][j] = ParrallelDCAPImpl.roundTo2Decimals(derivativeOverW_i_j);
			}
		}
	}

	private float derivativeOverW_i_j(int i, int j) {
		// alpha part
		float alphaPart = 0;
		for (int k = 0; k < this.matrixW.length; k++)
			alphaPart += this.prevMatrixW[i][k] * this.prevMatrixW[j][k] * this.matrixT[i][k] * this.matrixT[j][k];
		alphaPart *= this.matrixD[i][j];

		// beta part
		float betaPart = 0;
		for (int m = 0; m < this.matrixA.length; m++)
			betaPart += this.matrixA[m][i][j] * this.matrixR[i][m];

		// get derivative
		float derivativeOverW_i_j = (this.alpha * alphaPart + this.beta * betaPart) / this.phi;

		return derivativeOverW_i_j;
	}

}

class ComputeObjScoreThread implements Runnable {
	public static Logger logger = Logger.getLogger(ComputeObjScoreThread.class);

	private int beginIndex, endIndex, threadId;
	private float[] scoreArray;
	private float[][] matrixR, matrixW, matrixD;
	private int[][] matrixT;
	private float[][][] matrixA;
	private float alpha, beta;

	public ComputeObjScoreThread(int beginIndex, int endIndex, int threadId, float[] scoreArray, float[][] matrixR,
			float[][] matrixW, float[][] matrixD, int[][] matrixT, float[][][] matrixA, float alpha, float beta) {
		this.beginIndex = beginIndex;
		this.endIndex = endIndex;
		this.threadId = threadId;
		this.scoreArray = scoreArray;
		this.matrixR = matrixR;
		this.matrixW = matrixW;
		this.matrixD = matrixD;
		this.matrixT = matrixT;
		this.matrixA = matrixA;
		this.alpha = alpha;
		this.beta = beta;
	}

	public void run() {
		// TODO Auto-generated method stub
		float alphaPart = 0, betaPart = 0;
		for (int i = this.beginIndex; i < this.endIndex; i++) {
			for (int j = 0; j < this.matrixW[i].length; j++) {
				// alpha part
				for (int k = 0; k < this.matrixW[i].length; k++) {
					alphaPart += this.matrixD[i][j] * this.matrixW[i][j] * this.matrixW[i][k] * this.matrixW[j][k]
							* this.matrixT[i][k] * this.matrixT[j][k];
				}

				// beta part
				for (int m = 0; m < this.matrixA.length; m++) {
					betaPart += this.matrixW[i][j] * this.matrixA[m][i][j] + this.matrixR[i][m];
				}
			}
		}

		// the score
		this.scoreArray[threadId] = this.alpha * alphaPart + this.beta * betaPart;
	}

}
