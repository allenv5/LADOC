package cn.edu.whut.ladoc.similarity;

import java.util.Set;

public class JaccardSimilarityMeasure implements SimilarityMeasure {
	public JaccardSimilarityMeasure() {
	}

	public float compute(Set<String> valueSet, Set<String> anotherValueSet) {
		int common = 0;

		for (String value : valueSet) {
			if (anotherValueSet.contains(value)) {
				++common;
			}
		}

		int total = valueSet.size() + anotherValueSet.size() - common;
		return total == 0 ? 0 : common / (float)total;
	}
}
