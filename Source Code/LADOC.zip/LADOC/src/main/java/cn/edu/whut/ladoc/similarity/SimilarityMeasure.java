package cn.edu.whut.ladoc.similarity;

import java.util.Set;

public interface SimilarityMeasure {
	float compute(Set<String> paramSet1, Set<String> paramSet2);
}
