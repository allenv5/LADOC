package cn.edu.whut.ladoc.similarity;

import java.util.Iterator;
import java.util.Set;

public class SimpleAndSimilatiryMeasure implements SimilarityMeasure {
	public float compute(Set<String> valueSet, Set<String> anotherValueSet) {
		for (String value : valueSet) {
			int intVal = Integer.parseInt(value);
			Iterator<String> iterator = anotherValueSet.iterator();
			if (iterator.hasNext()) {
				String anotherValue = iterator.next();
				int anotherIntVal = Integer.parseInt(anotherValue);
				return (intVal & anotherIntVal);
			}
		}
		return 0.0F;
	}
}
