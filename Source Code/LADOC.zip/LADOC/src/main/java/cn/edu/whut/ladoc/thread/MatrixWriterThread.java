package cn.edu.whut.ladoc.thread;

import cn.edu.whut.ladoc.SharedLibrary;
import org.apache.log4j.Logger;

public class MatrixWriterThread implements Runnable {
	public static Logger logger = Logger.getLogger(MatrixWriterThread.class);
	private float[][] matrix;
	private String file;
	private int threadId;

	public MatrixWriterThread(float[][] matrix, String file, int threadId) {
		this.matrix = matrix;
		this.file = file;
		this.threadId = threadId;
	}

	public void run() {
		logger.debug("#" + this.threadId + " thread is now running");
		String content = "";
		for (int i = 0; i < this.matrix.length; i++) {
			content = String.valueOf(content) + ((content.length() == 0) ? "" : "\n");
			if (this.matrix[i] != null)
				for (int j = 0; j < (this.matrix[i]).length; j++)
					content = String.valueOf(content) + ((j == 0) ? "" : "\t") + this.matrix[i][j];
		}
		SharedLibrary.saveToFile(content, this.file);
		logger.debug("#" + this.threadId + " thread is completed");
	}
}
