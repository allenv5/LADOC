package cn.edu.whut.overlapping_example;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.util.*;

public class GetAllComplex {
	private String database;
	private int type;   // 0: human, 1: yeast;

	public GetAllComplex(String database, int type) {
		this.database = database;
		this.type = type;
	}

	public static void main(String[] args) {
		String yeastDatabases = "data/databases/CYC2008_complex.tab.txt";
		String humanDatabases = "data/databases/corum_allComplexes.json";
		GetAllComplex g = new GetAllComplex(humanDatabases, 0);
		Map<String, Set<String>> allComplexes = g.getAllComplexes();
		System.out.println();
	}

	public Map<String, Set<String>> getAllComplexes() {
		if (this.type == 1) {
			return getYeastComplexes();
		} else {
			return getHumanComplexes();
		}
	}

	private Map<String, Set<String>> getYeastComplexes() {
		Map<String, Set<String>> yeastComplexes = new HashMap<>();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(this.database));
			String line;
			while ((line = br.readLine()) != null) {
				if (line.startsWith("ORF")) continue;
				String[] itmes = line.split("\t");
				if (!yeastComplexes.containsKey(itmes[2])) {
					Set<String> complexes = new HashSet<>();
					complexes.add(itmes[1]);
					yeastComplexes.put(itmes[2], complexes);
				} else {
					yeastComplexes.get(itmes[2]).add(itmes[1]);
				}
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return yeastComplexes;
	}

	private Map<String, Set<String>> getHumanComplexes() {
		Map<String, Set<String>> humanComplexes = new HashMap<>();
		JSONArray arrays = getJSONSArray(this.database);
		for (int i = 0; i < arrays.length(); i++) {
			JSONObject obj = arrays.getJSONObject(i);
			if (obj.getString("Organism").equals("Human")) {
				String complexName = obj.getString("ComplexName");
				String[] items = obj.getString("subunits(Gene name)").split(";");
				Set<String> complexes = new HashSet<>(Arrays.asList(items));
				humanComplexes.put(complexName, complexes);
			}
		}
		return humanComplexes;
	}

	private static JSONArray getJSONSArray(String fileName) {
		String jsonStr = "";
		try {
			File file = new File(fileName);
			Reader reader = new InputStreamReader(new FileInputStream(file), "UTF-8");
			int ch;
			StringBuffer sb = new StringBuffer();
			while ((ch = reader.read()) != -1) {
				sb.append((char) ch);
			}
			reader.close();
			jsonStr = sb.toString();
			return new JSONArray(jsonStr);
		} catch (Exception e) {
			e.printStackTrace();
			return new JSONArray();
		}
	}
}
