package cn.edu.whut.tools;

import java.io.*;
import java.util.Map;

public class ChangeClustersToLAGOInput {
	private String clustersFolder = "D:\\Users\\Vertex-Z\\Desktop\\process\\";
	private String PPINetwork = "DIP Hsapi";
	private String clustersName = "EGCPI";
	private String outputFolder = clustersFolder + PPINetwork + File.separator + clustersName + "_output\\";
	private Map<String, String> geneidMap;

	public static void main(String[] args) {
		ChangeClustersToLAGOInput c = new ChangeClustersToLAGOInput();
		c.run();
	}

	private void test() {
		TransGeneidToGeneName t = new TransGeneidToGeneName();
		t.initGeneidMap();
		this.geneidMap = t.getGeneidMap();
		StringBuilder sb = new StringBuilder();
		try {
			BufferedReader br = new BufferedReader(new FileReader(clustersFolder + PPINetwork + File.separator + clustersName));
			String line;
			while ((line = br.readLine()) != null) {
				if (!line.startsWith("Cluster")) {
					String[] items = line.split("\t");
					for (int i = 0; i < items.length; i++) {
						if (this.geneidMap.containsKey(items[i])) {
							sb.append(this.geneidMap.get(items[i])).append("\n");
						} else {
							sb.append(items[i]).append("\n");
						}
					}
				}
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(clustersFolder + PPINetwork + File.separator + "output.txt"));
			bw.write(sb.toString());
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void run() {
		TransGeneidToGeneName t = new TransGeneidToGeneName();
		t.initGeneidMap();
		this.geneidMap = t.getGeneidMap();
		File file = new File(outputFolder);
		if (!file.isDirectory()) file.mkdirs();
		try {
			BufferedReader br = new BufferedReader(new FileReader(clustersFolder + PPINetwork + File.separator +  clustersName));
			String line;
			int count = 1;
			while ((line = br.readLine()) != null) {
				if (!line.startsWith("Cluster")) {
					saveClusterToFile(line, "orfs" + count + ".txt");
					count++;
				}
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void saveClusterToFile(String clusterResult, String fileName) {
		String[] itmes = clusterResult.split("\t");
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(outputFolder + fileName));
			for (int i = 0; i < itmes.length; i++) {
				if (geneidMap.containsKey(itmes[i])) {
					bw.write(geneidMap.get(itmes[i]) + "\n");
				} else {
					bw.write(itmes[i] + "\n");
				}
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
