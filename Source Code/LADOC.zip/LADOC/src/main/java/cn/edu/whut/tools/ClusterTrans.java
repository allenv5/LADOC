package cn.edu.whut.tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.*;

public class ClusterTrans {
	public static void main(String[] args) {
		String filePath = "data/dataset/DIP-Hsapi/";
		String oldFile = "cluster-edge.txt";
		String newFile = "cluster-edge-new.txt";

		List<Set<String>> clusterList = new ArrayList<>();

		try {
			BufferedReader br = new BufferedReader(new FileReader(filePath + oldFile));
			String line;
			while ((line = br.readLine()) != null) {
				String[] items = line.split("\t");
				Set<String> cluster = new HashSet<>(Arrays.asList(items));
				clusterList.add(cluster);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(filePath + newFile));
			for (Set<String> cluster : clusterList) {
				for (String vertex : cluster) {
					bw.write(vertex + "\t");
				}
				bw.newLine();
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
