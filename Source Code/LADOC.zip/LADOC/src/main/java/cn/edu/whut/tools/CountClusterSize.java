package cn.edu.whut.tools;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

public class CountClusterSize {
	private static Map<Integer, Integer> sizeMap;

	public static void main(String[] args) {
		String clusterName = "data/dataset/Krogan/simrank_0622/0_clusters_from_matrix_1300";
		count(clusterName);
		// System.out.println(sizeMap);
		int count = 0;
		for (Integer key : sizeMap.keySet()) {
			System.out.println(key + ": " + sizeMap.get(key));
			count += sizeMap.get(key);
		}
		System.out.println(count);
	}

	private static void count(String name) {
		sizeMap = new HashMap<>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(name));
			String line;
			while ((line = br.readLine()) != null) {
				String[] items = line.split("\t");
				int length = items.length;
				if (sizeMap.containsKey(length)) {
					int size = sizeMap.get(length);
					sizeMap.put(length, size + 1);
				} else {
					sizeMap.put(length, 1);
				}
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
