package cn.edu.whut.tools;

import cn.edu.whut.overlapping_example.GetAllComplex;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;

/**
 * 2020-08-02
 * version 0.1
 */
public class FindOverlappingCluster {
	private static String folder = "D:\\Users\\Vertex-Z\\Desktop\\process\\DIP Hsapi\\";
	private static String clusterResult = "DCAFP_genename";
	// private static String databases = "data/databases/CYC2008_complex.tab.txt";
	private static String databases = "data/databases/corum_allComplexes.json";

	private static Set<Set<String>> allClusters;
	private static Map<String, Set<String>> allComplexes;

	public static void main(String[] args) {
		// 获取所有已知复合物
		GetAllComplex g = new GetAllComplex(databases, 0);
		allComplexes = g.getAllComplexes();

		initAllClusters();
		run();
		// test();
	}

	private static void run() {
		Set<Set<String>> clustersSizeGT5 = new HashSet<>();
		int count = 0;
		for (Set<String> cluster : allClusters) {
			if (cluster.size() >= 3) {
				// System.out.println(cluster);
				clustersSizeGT5.add(cluster);
				count++;
			}
		}
		System.out.println("Total: " + count);
		findOverlappingClusters(clustersSizeGT5);
	}

	private static void test() {
		for (Set<String> cluster : allClusters) {
			System.out.println(cluster);
			System.out.println(allComplexes.get(getBestMatchComplex(cluster).get("name")));
			System.out.println();
		}
	}

	private static void initAllClusters() {
		allClusters = new HashSet<>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(folder + clusterResult));
			String line;
			while ((line = br.readLine()) != null) {
				String[] items = line.split("\t");
				Set<String> cluster = new HashSet<>(Arrays.asList(items));
				allClusters.add(cluster);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void findOverlappingClusters(Set<Set<String>> allClusters) {
		List<Set<String>> clustersList = new ArrayList<>(allClusters);
		for (int i = 0; i < clustersList.size() - 1; i++) {
			for (int j = i + 1; j < clustersList.size(); j++) {
				int overLappingSize = getOverlappingSize(clustersList.get(i), clustersList.get(j));
				int minSize = Math.min(clustersList.get(i).size(), clustersList.get(j).size());
				// if (overLappingSize <= 8 && overLappingSize >= 5 && minSize > 10) {
				if (overLappingSize >= 2) {
					Set<String> clusterI = clustersList.get(i);
					Set<String> clusterJ = clustersList.get(j);

					Map<String, String> result1 = getBestMatchComplex(clusterI);
					Map<String, String> result2 = getBestMatchComplex(clusterJ);
					String complexName1 = result1.get("name");
					String complexName2 = result2.get("name");


					if (complexName1.equals("unknown") || complexName2.equals("unknown")) continue;

					Set<String> complex1 = allComplexes.get(complexName1);
					Set<String> complex2 = allComplexes.get(complexName2);
					if (complex1.equals(complex2)) continue;

					if (overLappingSize * 2 > minSize) continue;

					System.out.println("Complex #1 name: " + complexName1);
					System.out.println("Complex #1: " + complex1);
					System.out.println("Cluster #1: " + clusterI);
					System.out.println("Complex #1 size: " + complex1.size() + ", Cluster #1 size: " + clusterI.size() + ", OverlappingSize: " + result1.get("size") + ", os = " + getOverlappingScore(complex1, clusterI));
					System.out.println("Complex #2 name: " + complexName2);
					System.out.println("Complex #2: " + complex2);
					System.out.println("Cluster #2: " + clusterJ);
					System.out.println("Complex #2 size: " + complex2.size() + ", Cluster #2 size: " + clusterJ.size() + ", OverlappingSize: " + result2.get("size") + ", os = " + getOverlappingScore(complex2, clusterJ));
					System.out.println("cluster #1 and cluster #2 overlappingSize: " + overLappingSize);
					System.out.println();
				}
			}
		}


		// for (Set<String> cluster1 : allClusters) {
		// 	for (Set<String> cluster2 : allClusters) {
		// 		if (cluster1.equals(cluster2)) continue;
		// 		int overLappingSize = getOverlappingSize(cluster1, cluster2);
		// 		if (overLappingSize >= 6) {
		// 			System.out.println("Cluster #1: " + cluster1);
		// 			System.out.println("Cluster #2: " + cluster2);
		// 			System.out.println("OverlappingSize: " + overLappingSize);
		// 			System.out.println();
		// 		}
		// 	}
		// }
	}

	// private static Set<String> getKnowComplexes(Set<String> cluster) {
	// 	for (Set<String> complexes : allComplexes.values()) {
	// 		if (getOverlappingSize(complexes, cluster) >= 8) {
	// 			return complexes;
	// 		}
	// 	}
	// 	return new HashSet<>();
	// }

	// private static String getKnowComplexName(Set<String> cluster) {
	// 	float threshold = 0.1f;
	// 	for (String name : allComplexes.keySet()) {
	// 		Set<String> complex = allComplexes.get(name);
	// 		int overlappingSize = getOverlappingSize(complex, cluster);
	// 		if (complex.size() * threshold > overlappingSize || overlappingSize * threshold > complex.size()) {
	// 			return name;
	// 		}
	// 	}
	// 	return "unknown";
	// }

	private static Map<String, String> getBestMatchComplex(Set<String> cluster) {
		String bestMatchName = "unknown";
		int bestMatchSize = 0;
		for (String name : allComplexes.keySet()) {
			Set<String> complex = allComplexes.get(name);
			int overlappingSize = getOverlappingSize(complex, cluster);
			if (overlappingSize > bestMatchSize) {
				bestMatchSize = overlappingSize;
				bestMatchName = name;
			}
		}
		Map<String, String> result = new HashMap<>();
		result.put("name", bestMatchName);
		result.put("size", String.valueOf(bestMatchSize));
		return result;
	}

	private static int getOverlappingSize(Set<String> set1, Set<String> set2) {
		Set<String> newSet = new HashSet<>(set1);
		newSet.retainAll(set2);
		return newSet.size();
	}

	private static float getOverlappingScore(Set<String> aCluster, Set<String> anotherCluster) {
		int total = aCluster.size(), overlap = 0;
		for (String protein : anotherCluster) {
			if (aCluster.contains(protein)) {
				overlap++;
				continue;
			}
			total++;
		}
		return overlap / (float)total;
	}
}
