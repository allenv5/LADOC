package cn.edu.whut.tools;

import cn.edu.whut.overlapping_example.GetAllComplex;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;

/**
 * 2020-12-09
 * version 0.2
 */
public class FindOverlappingCluster_new {
	private static String folder = "D:\\Users\\Vertex-Z\\Desktop\\process\\Collins\\";
	private static String clusterResult = "EGCPI_genename";
	private static String databases = "data/databases/CYC2008_complex.tab.txt";
	// private static String databases = "data/databases/corum_allComplexes.json";

	private static Set<Set<String>> allClusters;
	private static Map<String, Set<String>> allComplexes;
	private static Map<Set<String>, String> allBestMatchComplexes;

	public static void main(String[] args) {
		// 获取所有已知复合物
		GetAllComplex g = new GetAllComplex(databases, 1);
		allComplexes = g.getAllComplexes();

		initAllClusters();
		findAllBestMatchComplex();
		findOverlappingClusters();
	}

	private static void findAllBestMatchComplex() {
		allBestMatchComplexes = new HashMap<>();
		for (Set<String> cluster : allClusters) {
			float os = 0f;
			String complexName = null;
			for (String complexKey : allComplexes.keySet()) {
				Set<String> complex = allComplexes.get(complexKey);
				float overlappingScore = getOverlappingScore(cluster, complex);
				if (overlappingScore > os) {
					os = overlappingScore;
					complexName = complexKey;
				}
			}
			if (os > 0.5) {
				allBestMatchComplexes.put(cluster, complexName);
			}
		}
	}

	private static void initAllClusters() {
		allClusters = new HashSet<>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(folder + clusterResult));
			String line;
			while ((line = br.readLine()) != null) {
				String[] items = line.split("\t");
				Set<String> cluster = new HashSet<>(Arrays.asList(items));
				allClusters.add(cluster);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void findOverlappingClusters() {
		Set<Set<String>> bestMatchClusters = allBestMatchComplexes.keySet();
		Map<Set<Set<String>>, Integer> map = new HashMap<>();

		for (Set<String> clusterI : bestMatchClusters) {
			for (Set<String> clusterJ : bestMatchClusters) {
				if (clusterI.equals(clusterJ)) continue;

				Set<Set<String>> flagKey = new HashSet<>();
				flagKey.add(new HashSet<>(clusterI));
				flagKey.add(new HashSet<>(clusterJ));

				if (map.containsKey(flagKey)) continue;
				map.put(flagKey, 1);

				float score = getOverlappingScore(clusterI, clusterJ);
				if (score > 0) {
					String complexNameI = allBestMatchComplexes.get(clusterI);
					Set<String> complexI = allComplexes.get(complexNameI);
					float complexMatchI = getOverlappingScore(clusterI, complexI);

					String complexNameJ = allBestMatchComplexes.get(clusterJ);
					Set<String> complexJ = allComplexes.get(complexNameJ);
					float complexMatchJ = getOverlappingScore(clusterJ, complexJ);

					int complexOverlappingSize = getOverlappingSize(complexI, complexJ);

					if (complexI.equals(complexJ) || complexOverlappingSize == 0) continue;

					System.out.println("Complex #1 name: " + complexNameI);
					System.out.println("Complex #1: " + complexI);
					System.out.println("Cluster #1: " + clusterI);
					System.out.println("Complex #1 size: " + complexI.size() + ", Cluster #1 size: " + clusterI.size());
					System.out.println("Complex #1 and Cluster #1 overlappingSize is " + getOverlappingSize(clusterI, complexI));
					System.out.println("Complex #1 and Cluster #1 overlappingScore is " + complexMatchI);

					System.out.println("Complex #2 name: " + complexNameJ);
					System.out.println("Complex #2: " + complexJ);
					System.out.println("Cluster #2: " + clusterJ);
					System.out.println("Complex #2 size: " + complexJ.size() + ", Cluster #2 size: " + clusterJ.size());
					System.out.println("Complex #2 and Cluster #2 overlappingSize is " + getOverlappingSize(clusterJ, complexJ));
					System.out.println("Complex #2 and Cluster #2 overlappingScore is " + complexMatchJ);

					System.out.println("===== Overlapping Result =====");
					System.out.println("Complex #1 and Complex #2 overlappingSize: " + complexOverlappingSize);
					System.out.println("Complex #1 and Complex #2 overlappingScore: " + getOverlappingScore(complexI, complexJ));
					System.out.println("cluster #1 and cluster #2 overlappingSize: " + getOverlappingSize(clusterI, clusterJ));
					System.out.println("cluster #1 and cluster #2 overlappingScore: " + score);
					System.out.println();
				}
			}
		}
	}

	private static int getOverlappingSize(Set<String> aCluster, Set<String> anotherCluster) {
		int overlap = 0;
		for (String protein : anotherCluster) {
			if (aCluster.contains(protein)) {
				overlap++;
			}
		}
		return overlap;
	}

	private static float getOverlappingScore(Set<String> aCluster, Set<String> anotherCluster) {
		int total = aCluster.size(), overlap = 0;
		for (String protein : anotherCluster) {
			if (aCluster.contains(protein)) {
				overlap++;
				continue;
			}
			total++;
		}
		return overlap / (float) total;
	}
}
