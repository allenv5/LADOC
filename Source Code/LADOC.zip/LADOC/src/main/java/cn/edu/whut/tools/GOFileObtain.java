package cn.edu.whut.tools;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;

/**
 * 2021-01-11
 */
public class GOFileObtain {
	private static final String fileName = "data/databases/file2.xlsx";
	private static final String PPIPath = "data/dataset/Collins/";
	private static Map<String, String> geneNameMap;

	public static void main(String[] args) {
		TransGeneidToGeneName t = new TransGeneidToGeneName();
		t.initGeneidMap();
		List<String> list = new ArrayList<>();
		Collections.addAll(list, "SWR1", "ARP6", "RVB2", "SWC4", "VPS71", "YAF9", "SWC3", "VPS72", "SWC7",
				"SWC5", "TAF14", "ARP8", "ARP5", "IES1", "NHP10", "INO80", "IES3", "IES4", "RVB1", "RVB2", "ACT1", "ARP4", "BDF1", "IES2", "IES5");
		// t.changeGeneNameToID(set);
		geneNameMap = t.getGeneNameMap(new HashSet<>(list));
		// System.out.println(geneNameMap.size());

		getGOInfo(list);
	}

	private static void getGOInfo(List<String> list) {
		List<String> attributeFiles = new ArrayList<>();
		Collections.addAll(attributeFiles, "attribute-1", "attribute-2", "attribute-3");
		for (String attributeFileName : attributeFiles) {
			System.out.println(attributeFileName);
			Map<String, String> attributeMap = new HashMap<>();
			try {
				BufferedReader br = new BufferedReader(new FileReader(PPIPath + attributeFileName));
				String line;
				while ((line = br.readLine()) != null) {
					String[] items = line.trim().split("\t");
					if (items.length < 2) continue;
					attributeMap.put(items[0], items[1]);
				}
				br.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			for (String node : list) {
				System.out.println(node + "\t" + attributeMap.get(geneNameMap.get(node)));
			}
			System.out.println();
		}
	}
}
