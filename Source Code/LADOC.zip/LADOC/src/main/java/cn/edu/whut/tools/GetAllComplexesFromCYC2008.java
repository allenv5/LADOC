package cn.edu.whut.tools;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class GetAllComplexesFromCYC2008 {
	private static String cycData = "data/databases/CYC2008_complex.tab.txt";
	private static Map<String, Set<String>> allComplexes = new HashMap<>();

	public static void main(String[] args) {
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(cycData));
			String line;
			while ((line = br.readLine()) != null) {
				String[] vals = line.split("\t");
				String gene = vals[1];
				String complex = vals[2];
				if (!allComplexes.containsKey(complex)) {
					allComplexes.put(complex, new HashSet<>());
				}
				allComplexes.get(complex).add(gene);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println(allComplexes.size());
	}
}
