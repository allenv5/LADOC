package cn.edu.whut.tools;

import java.io.*;
import java.util.*;

public class GraphTool {
	private String vertexFileName, clusterMatrixFileName;
	private String datasetPath;
	private List<String> vertexList;
	private float[][] clusterMatrix;

	public GraphTool(String datasetPath, String vertexFileName, String clusterMatrixFileName) {
		this.datasetPath = datasetPath;
		this.vertexFileName = vertexFileName;
		this.clusterMatrixFileName = clusterMatrixFileName;
		this.run();
	}

	public void run() {
		this.setVertexList();
		this.setClusterMatrix();
	}

	public List<String> getVertexList() {
		return this.vertexList;
	}

	public float[][] getClusterMatrix() {
		return this.clusterMatrix;
	}

	private void setVertexList() {
		this.vertexList = new ArrayList<>();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(this.datasetPath + this.vertexFileName));
			String line;
			while ((line = br.readLine()) != null && !"".equals(line)) {
				this.vertexList.add(line);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void setClusterMatrix() {
		this.clusterMatrix = new float[this.vertexList.size()][this.vertexList.size()];
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(this.datasetPath + this.clusterMatrixFileName));
			String line;
			String[] vertexLine;
			int rowCount = 0, colCount = 0;
			while ((line = br.readLine()) != null && !"".equals(line)) {
				vertexLine = line.split("\t");
				for (String vertex : vertexLine) {
					this.clusterMatrix[rowCount][colCount] = Float.parseFloat(vertex);
					colCount++;
				}
				colCount = 0;
				rowCount++;
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static List<String> getAllAttributeFilesName(String datasetPath) {
		List<String> allAttributeFilesTempList = new ArrayList<>();
		File file = new File(datasetPath);
		File[] tempList = file.listFiles();
		assert tempList != null;
		for (File f : tempList) {
			if (f.getName().startsWith("attribute")) {
				allAttributeFilesTempList.add(f.getName());
			}
		}

		List<String> allAttributeFilesList = new ArrayList<>();
		for (int i = 1; i <= allAttributeFilesTempList.size(); i++) {
			allAttributeFilesList.add("attribute-" + i);
		}
		return allAttributeFilesList;
	}

	public static Set<Set<String>> getFinalClusterSet(Set<Set<String>> clusterSet) {
		Set<Set<String>> finalClusterSet = new HashSet<>();
		for (Set<String> cluster : clusterSet) {
			Set<String> tmp = new HashSet<>();
			for (String link : cluster) {
				tmp.addAll(Arrays.asList(link.split("\t")));
			}
			finalClusterSet.add(tmp);
		}
		return finalClusterSet;
	}

	public static void saveClusterFile(String saveFolder, String saveName, Set<Set<String>> allClusterSet) {
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter(saveFolder + saveName));
			for (Set<String> cluster : allClusterSet) {
				List<String> tmp = new ArrayList<>(cluster);
				for (int i = 0; i < tmp.size(); i++) {
					if (i == tmp.size() - 1) {
						bw.write(tmp.get(i));
					} else {
						bw.write(tmp.get(i) + "\t");
					}
				}
				bw.write("\n");
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void saveClusterFile(String saveFolder, String saveName, List<List<String>> allClusterSet) {
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter(saveFolder + saveName));
			for (List<String> cluster : allClusterSet) {
				for (int i = 0; i < cluster.size(); i++) {
					if (i == cluster.size() - 1) {
						bw.write(cluster.get(i));
					} else {
						bw.write(cluster.get(i) + "\t");
					}
				}
				bw.write("\n");
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Map<Integer, String> id2VertexMap(List<String> vertexList) {
		Map<Integer, String> vertexMap = new HashMap<>();
		for (int i = 0; i < vertexList.size(); i++) {
			vertexMap.put(i, vertexList.get(i));
		}
		return vertexMap;
	}

	public static Map<Integer, String> id2EdgeMap(List<List<String>> edgeList) {
		Map<Integer, String> edgeMap = new HashMap<>();
		for (int i = 0; i < edgeList.size(); i++) {
			String edge = edgeList.get(i).get(0) + "\t" + edgeList.get(i).get(1);
			edgeMap.put(i, edge);
		}
		return edgeMap;
	}

	public static void saveVertexList(List<String> vertexList, String folderName, String fileName) {
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter(folderName + fileName));
			for (String vertex : vertexList) {
				bw.write(vertex);
				bw.newLine();
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void saveEdgeList(List<List<String>> edgeList, String folderName, String fileName) {
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter(folderName + fileName));
			for (List<String> edge : edgeList) {
				String link = edge.get(0) + "\t" + edge.get(1);
				bw.write(link);
				bw.newLine();
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void saveMatrix(float[][] matrixW, String folderName, String fileName) {
		File f = new File(folderName);
		try {
			if (!f.exists()) {
				f.mkdirs();
				// logger.info("文件夹" + folder + "创建成功");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter(folderName + fileName));
			for (int i = 0; i < matrixW.length; i++) {
				for (int j = 0; j < matrixW[i].length; j++) {
					if (j == matrixW[i].length - 1) {
						// bw.write(matrixW[i][j] + "\n");
						bw.write(String.format("%.2f\n", matrixW[i][j]));
					} else {
						// bw.write(matrixW[i][j] + "\t");
						bw.write(String.format("%.2f\t", matrixW[i][j]));
					}
				}
				// bw.newLine();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (bw != null) {
				try {
					bw.flush();
					bw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static float[][] readMatrix(int matrixLength, String fileName) {
		float[][] clusterMatrix = new float[matrixLength][matrixLength];
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(fileName));
			String line;
			String[] vertexLine;
			int rowCount = 0, colCount = 0;
			while ((line = br.readLine()) != null && !"".equals(line)) {
				vertexLine = line.split("\t");
				for (String vertex : vertexLine) {
					clusterMatrix[rowCount][colCount] = Float.parseFloat(vertex);
					colCount++;
				}
				colCount = 0;
				rowCount++;
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}

		return clusterMatrix;
	}

	public static float[][] readMatrix(String fileName) {
		List<List<String>> clusterMatrixList = new ArrayList<>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(fileName));
			String line;
			String[] vertexLine;
			while ((line = br.readLine()) != null) {
				vertexLine = line.split("\t");
				List<String> vector = new ArrayList<>(Arrays.asList(vertexLine));
				clusterMatrixList.add(vector);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		float[][] clusterMatrix = new float[clusterMatrixList.size()][clusterMatrixList.size()];
		for (int i = 0; i < clusterMatrixList.size(); i++) {
			for (int j = 0; j < clusterMatrixList.get(i).size(); j++) {
				clusterMatrix[i][j] = Float.parseFloat(clusterMatrixList.get(i).get(j));
			}
		}
		return clusterMatrix;
	}

	public static float[][] readMatrix(List<String> vertexList, String fileName) {
		float[][] clusterMatrix = new float[vertexList.size()][vertexList.size()];
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(fileName));
			String line;
			String[] vertexLine;
			int rowCount = 0, colCount = 0;
			while ((line = br.readLine()) != null && !"".equals(line)) {
				vertexLine = line.split("\t");
				for (String vertex : vertexLine) {
					clusterMatrix[rowCount][colCount] = Float.parseFloat(vertex);
					colCount++;
				}
				colCount = 0;
				rowCount++;
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return clusterMatrix;
	}

	public static void saveAdjacentVerticesMap(Map<String, Set<String>> adjacentVerticesMap, String saveFileName) {
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter(saveFileName));
			for (String key : adjacentVerticesMap.keySet()) {
				bw.write(key + "\t");
				Set<String> adjacentVerticesSet = adjacentVerticesMap.get(key);
				int n = 0;
				for (String vertex : adjacentVerticesSet) {
					if (n == adjacentVerticesSet.size() - 1) {
						bw.write(vertex);
					} else {
						bw.write(vertex + "\t");
					}
					n++;
				}
				bw.newLine();
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
