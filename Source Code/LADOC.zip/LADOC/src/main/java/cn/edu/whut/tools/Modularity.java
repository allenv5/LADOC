package cn.edu.whut.tools;


import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;

public class Modularity {
	public static Logger logger = Logger.getLogger(Modularity.class);

	public static void main(String[] args) {
		String rootFolder = "D:\\Users\\VertexZzz\\Desktop\\datasets\\Krogan\\";
		String ppiFile = rootFolder + "ppis";
		String clusterFile = rootFolder + "PEWCC";

		Map<String, Set<String>> adjacentMap = new HashMap<>();
		List<String> vertexList = new ArrayList<>();
		List<String[]> clusters = new ArrayList<>();
		List<Integer> degrees = new ArrayList<>();
		double[][] adjacentMatrix;
		double[][] clusterMatrix;
		int m = 0;

		BufferedReader br;

		try {
			br = new BufferedReader(new FileReader(ppiFile));
			String line;
			while ((line = br.readLine()) != null) {
				String[] vals = line.split("\t");
				if (!vertexList.contains(vals[0])) {
					vertexList.add(vals[0]);
				}
				if (!vertexList.contains(vals[1])) {
					vertexList.add(vals[1]);
				}
				if (!adjacentMap.containsKey(vals[0])) {
					adjacentMap.put(vals[0], new HashSet<>());
				}
				if (!adjacentMap.containsKey(vals[1])) {
					adjacentMap.put(vals[1], new HashSet<>());
				}
				adjacentMap.get(vals[0]).add(vals[1]);
				adjacentMap.get(vals[1]).add(vals[0]);
				m++;
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			br = new BufferedReader(new FileReader(clusterFile));
			String line;
			while ((line = br.readLine()) != null) {
				String[] vals = line.split("\t");
				clusters.add(vals);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		for (String v : vertexList) {
			degrees.add(adjacentMap.get(v).size());
		}

		adjacentMatrix = new double[vertexList.size()][vertexList.size()];

		for (String key : adjacentMap.keySet()) {
			int vIdx = vertexList.indexOf(key);
			for (String vertex : adjacentMap.get(key)) {
				int gIdx = vertexList.indexOf(vertex);
				adjacentMatrix[vIdx][gIdx] = 1;
			}
		}

		clusterMatrix = new double[vertexList.size()][clusters.size()];

		for (int i = 0; i < clusters.size(); i++) {
			for (String v : clusters.get(i)) {
				int idx = vertexList.indexOf(v);
				clusterMatrix[idx][i] = 1;
			}
		}

		double[][] matrixB = new double[vertexList.size()][vertexList.size()];

		for (int i = 0; i < vertexList.size(); i++) {
			for (int j = 0; j < vertexList.size(); j++) {
				matrixB[i][j] = adjacentMatrix[i][j] - degrees.get(i) * degrees.get(j) / (double)(2 * m);
			}
		}

		double sum = 0;

		for (int i = 0; i < vertexList.size(); i++) {
			for (int j = 0; j < vertexList.size(); j++) {
				for (int k = 0; k < clusters.size(); k++) {
					if (clusterMatrix[i][k] == 1 && clusterMatrix[j][k] == 1) {
						sum = sum + adjacentMatrix[i][j] - degrees.get(i) * degrees.get(j) / (double)(2 * m);
						break;
					}
				}
			}
		}

		System.out.println(sum / (double)(2 * m));

		// SimpleMatrix bMatrix = new SimpleMatrix(matrixB);
		// System.out.println(cMatrix.transpose().mult(bMatrix).mult(cMatrix).trace() / (double)(2 * m));
	}

	public static void example() {

		List<String> vertexList = new ArrayList<>();
		List<Integer> degrees = new ArrayList<>();
		double[][] adjacentMatrix;
		double[][] clusterMatrix;

		vertexList.add("a");
		vertexList.add("b");
		vertexList.add("c");
		degrees.add(2);
		degrees.add(1);
		degrees.add(1);

		adjacentMatrix = new double[][]{{0, 1, 1}, {1, 0, 0}, {1, 0, 0}};
		clusterMatrix = new double[][]{{0, 1}, {1, 0}, {0, 1}};

		double sum = 0;
		int m = 2;

		for (int i = 0; i < vertexList.size(); i++) {
			for (int j = 0; j < vertexList.size(); j++) {
				for (int k = 0; k < 2; k++) {
					if (clusterMatrix[i][k] == 1 && clusterMatrix[j][k] == 1) {
						sum = sum + adjacentMatrix[i][j] - degrees.get(i) * degrees.get(j) / (double)(2 * m);
						break;
					}
				}
			}
		}

		System.out.println(sum / (double)(2 * m));
	}


	private static double[][] getMembershipArray(Map<String, String> classificationMap, int numClusters, List<String> vertexList) {
		Map<String, Integer> cluster2IndexMap = new HashMap<>();
		double[][] matrix = new double[vertexList.size()][numClusters];
		int currClusterIndex = 0;

		for(int i = 0; i < vertexList.size(); ++i) {
			String vertex = vertexList.get(i);
			String cluster = classificationMap.get(vertex);
			if (cluster != null) {
				// boolean clusterIndex = false;
				int clusterIndex;
				if (cluster2IndexMap.containsKey(cluster)) {
					clusterIndex = cluster2IndexMap.get(cluster);
				} else {
					clusterIndex = currClusterIndex;
					cluster2IndexMap.put(cluster, currClusterIndex);
					++currClusterIndex;
				}

				matrix[i][clusterIndex] = 1.0D;
			} else {
				logger.error("The cluster label of vertex [" + vertex + "] was not found");
			}
		}

		return matrix;
	}
}
