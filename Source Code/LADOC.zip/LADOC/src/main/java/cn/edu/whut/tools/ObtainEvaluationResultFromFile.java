package cn.edu.whut.tools;

import cn.edu.whut.evaluate.FMeasureMatch;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ObtainEvaluationResultFromFile {

	private static final String rootFolder = "D:\\Users\\VertexZzz\\Desktop\\datasets\\Homo\\Homo\\cluster_result_10\\";

	public static void main(String[] args) {
		List<String> allClusterResultFilesList = getAllClusterResultFile();
		getAllEvaluationResult(allClusterResultFilesList);
	}

	private static List<String> getAllClusterResultFile() {
		String prefix = "cluster_";
		List<String> allClusterResultFilesList = new ArrayList<>();
		File file = new File(rootFolder);
		File[] tempList = file.listFiles();
		assert tempList != null;
		for (File f : tempList) {
			if (f.getName().startsWith(prefix)) {
				allClusterResultFilesList.add(f.getName());
			}
		}
		return allClusterResultFilesList;
	}

	private static void getAllEvaluationResult(List<String> allClusterResultFilesList) {
		for (String resultFileName : allClusterResultFilesList) {
			System.out.println(resultFileName);
			FMeasureMatch.calc(rootFolder, resultFileName);
			System.out.println();
		}
	}
}
