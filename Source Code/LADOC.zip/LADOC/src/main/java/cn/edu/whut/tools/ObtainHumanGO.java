package cn.edu.whut.tools;

import java.io.*;
import java.util.*;

public class ObtainHumanGO {
	static Map<String, String> id2NameMap = new HashMap<>();

	public static void main(String[] args) {
		String rootFolder = "data/dataset/Homo";
		String ppiFile = rootFolder + File.separator + "ppis";
		String humanGOFile = rootFolder + File.separator + "goa_human.gaf";
		String id2NameMapFile = rootFolder + File.separator + "id2NameMap";

		ObtainHumanGO o = new ObtainHumanGO();
		Map<String, List<List<String>>> allGOMaps = o.getAllGOMaps(humanGOFile);
		List<String> nodes = o.getNodes(ppiFile);
		setName2IDMap(id2NameMapFile);

		// 保存三种属性信息
		Map<String, Set<String>> process = new HashMap<>();
		Map<String, Set<String>> component = new HashMap<>();
		Map<String, Set<String>> function = new HashMap<>();

		for (String node : nodes) {
			String geneName = id2NameMap.get(node);
			List<List<String>> allGOAnnos = allGOMaps.get(geneName);
			if (allGOAnnos == null) {
				process.put(node, null);
				component.put(node, null);
				function.put(node, null);
				continue;
			}
			if (!process.containsKey(node)) {
				process.put(node, new HashSet<>());
			}
			if (!component.containsKey(node)) {
				component.put(node, new HashSet<>());
			}
			if (!function.containsKey(node)) {
				function.put(node, new HashSet<>());
			}
			for (List<String> goAnno : allGOAnnos) {
				if (goAnno.get(1).equals("P")) {
					process.get(node).add(goAnno.get(0));
				} else if (goAnno.get(1).equals("C")) {
					component.get(node).add(goAnno.get(0));
				} else {
					function.get(node).add(goAnno.get(0));
				}
			}
		}

		o.writeGOAnnosToFile(process, rootFolder + File.separator + "attribute-1");
		o.writeGOAnnosToFile(component, rootFolder + File.separator + "attribute-2");
		o.writeGOAnnosToFile(function, rootFolder + File.separator + "attribute-3");

		// GraphTool.saveVertexList(nodes, rootFolder + File.separator, "proteins");
		System.out.println();
	}

	public List<String> getNodes(String ppiFile) {
		List<String> nodes = new ArrayList<>();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(ppiFile));
			String line;
			while ((line = br.readLine()) != null) {
				String[] vals = line.split("\t");
				if (vals.length < 2) {
					System.out.println(Arrays.toString(vals));
				}
				if (!nodes.contains(vals[0])) nodes.add(vals[0]);
				if (!nodes.contains(vals[1])) nodes.add(vals[1]);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return nodes;
	}

	public Map<String, List<List<String>>> getAllGOMaps(String humanGOFile) {
		Map<String, List<List<String>>> allGOMaps = new HashMap<>();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(humanGOFile));
			String line;
			while ((line = br.readLine()) != null) {
				if (line.startsWith("!")) continue;
				String[] vals = line.split("\t");
				String geneName = vals[2];
				String goAnnotation =  vals[4];
				String category = vals[8];
				if (!allGOMaps.containsKey(geneName)) {
					allGOMaps.put(geneName, new ArrayList<>());
				}
				List<String> list = new ArrayList<>();
				list.add(goAnnotation);
				list.add(category);
				allGOMaps.get(geneName).add(list);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return allGOMaps;
	}

	public void writeGOAnnosToFile(Map<String, Set<String>> category, String fileName) {
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter(fileName));
			for (String node : category.keySet()) {
				Set<String> goAnnoSet = category.get(node);
				bw.write(node);
				bw.write("\t");
				if (goAnnoSet == null || goAnnoSet.size() == 0) {
					bw.write("\n");
					continue;
				}
				List<String> goAnnoList = new ArrayList<>(goAnnoSet);
				for (int i = 0; i < goAnnoList.size(); i++) {
					if (i == goAnnoList.size() - 1) {
						bw.write(goAnnoList.get(i));
						bw.write("\n");
					} else {
						bw.write(goAnnoList.get(i));
						bw.write(",");
					}
				}
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void setName2IDMap(String file) {
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(file));
			String line;
			while ((line = br.readLine()) != null) {
				String[] vals = line.split("\t");
				id2NameMap.put(vals[0], vals[1]);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
