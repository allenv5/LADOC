package cn.edu.whut.tools;

import java.io.*;
import java.util.*;

public class ObtainHumanGOToOneFile {
	static Map<String, String> id2NameMap = new HashMap<>();
	static List<List<String>> edges = new ArrayList<>();
	static Set<String> allNodes = new HashSet<>();

	public static void main(String[] args) {
		String rootFolder = "data/dataset/Homo";
		String ppiFile = rootFolder + File.separator + "ppis";
		String humanGOFile = rootFolder + File.separator + "goa_human.gaf";
		String id2NameMapFile = rootFolder + File.separator + "id2NameMap";
		String saveGOFile = rootFolder + File.separator + "Homo_extended_Functional_profile.txt";
		String inputFile = rootFolder + File.separator + "HomoEGCPI_input";

		ObtainHumanGOToOneFile o = new ObtainHumanGOToOneFile();
		Map<String, Set<String>> allGOMaps = o.getAllGOMaps(humanGOFile);
		List<String> nodes = o.getNodes(ppiFile);
		setName2IDMap(id2NameMapFile);
		// o.writeGOAnnosToFile(allGOMaps, nodes, saveGOFile);
		o.writeInputFile(allGOMaps, nodes, inputFile);
		System.out.println();
	}

	public List<String> getNodes(String ppiFile) {
		List<String> nodes = new ArrayList<>();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(ppiFile));
			String line;
			while ((line = br.readLine()) != null) {
				String[] vals = line.split("\t");
				if (vals.length < 2) {
					System.out.println(Arrays.toString(vals));
				}
				if (!nodes.contains(vals[0])) nodes.add(vals[0]);
				if (!nodes.contains(vals[1])) nodes.add(vals[1]);
				edges.add(new ArrayList<>(Arrays.asList(vals)));
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return nodes;
	}

	public Map<String, Set<String>> getAllGOMaps(String humanGOFile) {
		Map<String, Set<String>> allGOMaps = new HashMap<>();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(humanGOFile));
			String line;
			while ((line = br.readLine()) != null) {
				if (line.startsWith("!")) continue;
				String[] vals = line.split("\t");
				String geneName = vals[2];
				String goAnnotation =  vals[4];
				if (!allGOMaps.containsKey(geneName)) {
					allGOMaps.put(geneName, new HashSet<>());
				}
				allGOMaps.get(geneName).add(goAnnotation);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return allGOMaps;
	}

	public void writeInputFile(Map<String, Set<String>> allGOMaps, List<String> ids, String fileName) {
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter(fileName));
			// write GO Annotations
			for (String id : ids) {
				String node = id2NameMap.get(id);
				if (!allGOMaps.containsKey(node)) {
					bw.write("v\t" + id + "\t\n");
					continue;
				}
				List<String> annos = new ArrayList<>(allGOMaps.get(node));
				bw.write("v" + "\t" + id + "\t");
				for (int i = 0; i < annos.size(); i++) {
					if (i == annos.size() - 1) {
						bw.write(annos.get(i) + "\n");
					} else {
						bw.write(annos.get(i) + ",");
					}
				}
			}
			// write edges
			for (List<String> edge : edges) {
				bw.write("e\t" + edge.get(0) + "\t" + edge.get(1) + "\n");
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void writeGOAnnosToFile(Map<String, Set<String>> allGOMaps, List<String> ids, String fileName) {
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter(fileName));
			for (String id : ids) {
				String node = id2NameMap.get(id);
				if (!allGOMaps.containsKey(node)) {
					bw.write(id);
					bw.write("\t");
					bw.write("\n");
					continue;
				}
				Set<String> annos = allGOMaps.get(node);
				for (String anno : annos) {
					bw.write(id);
					bw.write("\t");
					bw.write(anno);
					bw.write("\n");
				}
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void setName2IDMap(String file) {
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(file));
			String line;
			while ((line = br.readLine()) != null) {
				String[] vals = line.split("\t");
				id2NameMap.put(vals[0], vals[1]);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
