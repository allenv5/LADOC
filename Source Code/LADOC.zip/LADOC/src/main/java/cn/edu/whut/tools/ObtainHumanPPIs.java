package cn.edu.whut.tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.*;

public class ObtainHumanPPIs {
	private String dataFile;
	private String saveFolder;

	private Set<String> proteins = new HashSet<>();
	private Set<List<String>> ppis = new HashSet<>();
	private Set<String> extraProteins = new HashSet<>();
	private Set<String> allProteins = new HashSet<>();
	private Set<Set<String>> verificationPPIs = new HashSet<>();
	private Map<String, String> geneIDToNameMap = new HashMap<>();

	public ObtainHumanPPIs(String dataFile, String saveFolder) {
		this.dataFile = dataFile;
		this.saveFolder = saveFolder;
	}

	public void run() {
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(dataFile));
			String line;
			while ((line = br.readLine()) != null) {
				if (line.startsWith("#")) continue;
				List<String> ppi = new ArrayList<>();
				String[] vals = line.split("\t");
				String gene_id1 = vals[1];
				String gene_id2 = vals[2];
				String gene_name1 = vals[7];
				String gene_name2 = vals[8];
				this.geneIDToNameMap.put(gene_id1, gene_name1);
				this.geneIDToNameMap.put(gene_id2, gene_name2);
				this.allProteins.add(gene_id1);
				this.allProteins.add(gene_id2);
				if (gene_id1.equals(gene_id2)) {
					System.out.println(gene_id1);
					this.extraProteins.add(gene_id1);
					continue;
				}
				ppi.add(gene_id1);
				ppi.add(gene_id2);
				this.ppis.add(ppi);
				this.verificationPPIs.add(new HashSet<>(ppi));
				this.proteins.addAll(ppi);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void save() {
		BufferedWriter bw;
		// save ppis
		try {
			bw = new BufferedWriter(new FileWriter(saveFolder + "ppis"));
			for (List<String> ppi : ppis) {
				bw.write(ppi.get(0));
				bw.write("\t");
				bw.write(ppi.get(1));
				bw.write("\n");
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		// save proteins
		try {
			bw = new BufferedWriter(new FileWriter(saveFolder + "proteins"));
			for (String protein : proteins) {
				bw.write(protein);
				bw.write("\n");
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		// save gene_name to id map
		try {
			bw = new BufferedWriter(new FileWriter(saveFolder + "id2NameMap"));
			for (String id : this.geneIDToNameMap.keySet()) {
				bw.write(id);
				bw.write("\t");
				bw.write(this.geneIDToNameMap.get(id));
				bw.write("\n");
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void verify() {
		Set<String> p = new HashSet<>();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(saveFolder + "ppis"));
			String line;
			while ((line = br.readLine()) != null) {
				String[] vals = line.split("\t");
				p.add(vals[0]);
				p.add(vals[1]);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		String dataFile = "data/databases/BIOGRID-PUBLICATION-169867-4.3.196.tab3.txt";
		String saveFolder = "data/dataset/Homo/";
		ObtainHumanPPIs o = new ObtainHumanPPIs(dataFile, saveFolder);
		o.run();
		o.save();
		o.verify();
	}
}
