package cn.edu.whut.tools;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;

public class Q {

	static String rootFolder = "D:\\Users\\VertexZzz\\Desktop\\datasets\\DIP Hsapi\\";
	static String ppiFile = rootFolder + "ppis";

	public static void main(String[] args) {
		List<String> list = new ArrayList<>(Arrays.asList("LADOC", "PC2P", "ClusterONE", "EGCPI", "GMFTP", "PEWCC"));
		// List<String> list = new ArrayList<>(Collections.singletonList("PEWCC"));
		for (String file : list) {
			calcQ(file);
		}
	}

	public static void calcQ(String fileName) {
		String clusterFile = rootFolder + fileName;

		Map<String, Set<String>> adjacencyMap = new HashMap<>();
		List<String> vertexList = new ArrayList<>();
		List<String[]> clusters = new ArrayList<>();
		List<Integer> degrees = new ArrayList<>();
		Set<String> nodes = new HashSet<>();
		float[][] adjacencyMatrix;
		float[][] clusterMatrix;
		int m = 0;

		BufferedReader br;

		try {
			br = new BufferedReader(new FileReader(ppiFile));
			String line;
			while ((line = br.readLine()) != null) {
				String[] vals = line.split("\t");
				// if (!vertexList.contains(vals[1])) {
				// 	vertexList.add(vals[1]);
				// }
				// if (!vertexList.contains(vals[0])) {
				// 	vertexList.add(vals[0]);
				// }
				if (!adjacencyMap.containsKey(vals[0])) {
					adjacencyMap.put(vals[0], new HashSet<>());
				}
				if (!adjacencyMap.containsKey(vals[1])) {
					adjacencyMap.put(vals[1], new HashSet<>());
				}
				adjacencyMap.get(vals[0]).add(vals[1]);
				adjacencyMap.get(vals[1]).add(vals[0]);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			br = new BufferedReader(new FileReader(clusterFile));
			String line;
			while ((line = br.readLine()) != null) {
				if (line.startsWith("Cluster") || line.startsWith("cluster")) {
					continue;
				}
				String[] vals = line.split("\t");
				if (vals.length < 3) continue;
				clusters.add(vals);
				nodes.addAll(Arrays.asList(vals));
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		vertexList = new ArrayList<>(nodes);

		for (String v : vertexList) {
			degrees.add(adjacencyMap.get(v).size());
		}

		adjacencyMatrix = new float[vertexList.size()][vertexList.size()];

		for (int i = 0; i < vertexList.size(); i++) {
			for (int j = i + 1; j < vertexList.size(); j++) {
				String vertexI = vertexList.get(i);
				String vertexJ = vertexList.get(j);
				if (adjacencyMap.get(vertexI).contains(vertexJ) || adjacencyMap.get(vertexJ).contains(vertexI)) {
					adjacencyMatrix[i][j] = 1;
					adjacencyMatrix[j][i] = 1;
					m++;
				}
			}
		}

		clusterMatrix = new float[vertexList.size()][clusters.size()];

		for (int i = 0; i < clusters.size(); i++) {
			for (String v : clusters.get(i)) {
				int idx = vertexList.indexOf(v);
				clusterMatrix[idx][i] = 1;
			}
		}

		float sum = 0;

		for (int i = 0; i < vertexList.size(); i++) {
			for (int j = 0; j < vertexList.size(); j++) {
				for (int k = 0; k < clusters.size(); k++) {
					if (clusterMatrix[i][k] == 1 && clusterMatrix[j][k] == 1) {
						sum = sum + adjacencyMatrix[i][j] - degrees.get(i) * degrees.get(j) / (float)(2 * m);
						break;
					}
				}
			}
		}

		System.out.println(fileName + ": " + roundWithTowDecimalPlaces(sum / (float)(2 * m)));
	}

	public static float roundWithTowDecimalPlaces(float valueToBeRounded) {
		return (float)Math.round(valueToBeRounded * 100.0F) / 100.0F;
	}
}
