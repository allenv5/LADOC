package cn.edu.whut.tools;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;


public class TransGeneidToGeneName {
	private String fileName = "data/databases/file2.xlsx";
	private Map<String, String> geneidMap;
	private String proteinsFile = "data/dataset/Collins/proteins";
	private String PPIFile = "data/dataset/Collins/ppis";
	private List<String> proteinsGeneName = new ArrayList<>();

	public static void main(String[] args) {
		TransGeneidToGeneName t = new TransGeneidToGeneName();
		t.initGeneidMap();
		List<String> proteins = t.getProteins();
		// System.out.println(t.test(proteins));
		String folder = "D:\\Users\\Vertex-Z\\Desktop\\process\\Collins\\";
		String clusterFile = "DCAFP";
		List<List<String>> processedClusters = t.processClusterReuslt(folder, clusterFile);
		// t.changeGeneNameToID();
		t.countCYC2008Gene();
		// GraphTool.saveClusterFile(folder, clusterFile + "_genename", processedClusters);
		// t.savePPIByGeneName(t.getPPIs(), folder + "ppis_genename");
		// t.saveProteinsGeneName(proteins, folder + "proteins_genename");
		// System.out.println();
		// System.out.println(proteins.size());
		// System.out.println(new HashSet<>(t.proteinsGeneName).size());
	}

	public String getGeneIDFromGeneName(String geneName) {
		for (String key : geneidMap.keySet()) {
			if (geneidMap.get(key).equals(geneName)) {
				if (key.startsWith("85")) {
					return key;
				}
			}
		}
		return "";
	}

	public void countCYC2008Gene() {
		Set<String> gene = new HashSet<>();
		try {
			BufferedReader br = new BufferedReader(new FileReader("data/databases/CYC2008_complex.tab.txt"));
			String line;
			while ((line = br.readLine()) != null) {
				String[] items = line.trim().split("\t");
				if (items[0].equals("ORF")) continue;
				gene.add(items[1]);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		Set<String> except = new HashSet<>();
		for (String geneName : proteinsGeneName) {
			if (!gene.contains(geneName)) {
				except.add(geneName);
			}
		}
		System.out.println(except.size());
	}

	public void changeGeneNameToID(String geneName) {
		for (String key : geneidMap.keySet()) {
			if (geneidMap.get(key).equals(geneName)) {
				if (key.startsWith("85")) {
					System.out.println(key + "  -->  " + geneName);
				}
			}
		}
	}

	public void changeGeneNameToID() {
		Set<String> set = new HashSet<>();
		// Collections.addAll(set, "RPS4B", "RPL18A", "RPS16A", "EFT1", "RPS24A", "RPS8B", "HHF1",
		// 		"HHT1", "RPL23B", "TEF1", "TIF1", "RPS6B", "RPS18A", "RPL12B", "RPL20B", "RPL2B", "RPS11A", "RPL1A", "RPL19B");
		Collections.addAll(set, "ACT1", "SWR1", "ARP6", "RVB2", "SWC4", "VPS71", "YAF9", "SWC3", "RVB1",
				"VPS72", "SWC7", "ARP4", "SWC5", "BDF1", "RVB2", "TAF14", "ARP8", "ARP5", "IES1", "NHP10", "INO80", "IES3", "IES4", "IES2", "IES5");
		for (String node : set) {
			this.changeGeneNameToID(node);
		}
	}

	public void changeGeneNameToID(Set<String> set) {
		for (String node : set) {
			this.changeGeneNameToID(node);
		}
	}

	public Map<String, String> getGeneNameMap(Set<String> set) {
		Map<String, String> geneNameMap = new HashMap<>();
		for (String node : set) {
			for (String key : geneidMap.keySet()) {
				if (geneidMap.get(key).equals(node)) {
					if (key.startsWith("85")) {
						geneNameMap.put(node, key);
					}
				}
			}
		}
		return geneNameMap;
	}

	public void saveProteinsGeneName(List<String> proteinsList, String saveName) {
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(saveName));
			for (String protein : proteinsList) {
				if (this.geneidMap.containsKey(protein)) {
					bw.write(this.geneidMap.get(protein) + "\n");
				}


				// bw.write(protein + "\n");
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void savePPIByGeneName(List<List<String>> PPIs, String saveName) {
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(saveName));
			for (List<String> ppi : PPIs) {
				for (int i = 0; i < ppi.size(); i++) {
					if (i == ppi.size() - 1) {
						if (geneidMap.containsKey(ppi.get(i))) {
							bw.write(geneidMap.get(ppi.get(i)) + "\n");
						} else {
							bw.write(ppi.get(i) + "\n");
						}
					} else {
						if (geneidMap.containsKey(ppi.get(i))) {
							bw.write(geneidMap.get(ppi.get(i)) + "\t");
						} else {
							bw.write(ppi.get(i) + "\t");
						}
					}
				}
				// for (String protein : ppi) {
				// 	if (this.geneidMap.containsKey(protein)) {
				// 		bw.write(this.geneidMap.get(protein) + "\t");
				// 	} else {
				// 		bw.write(protein + "\t");
				// 	}
				// }
				// bw.write("\n");
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<List<String>> getPPIs() {
		List<List<String>> PPIs = new ArrayList<>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(this.PPIFile));
			String line;
			while ((line = br.readLine()) != null) {
				String[] items = line.split("\t");
				List<String> ppi = new ArrayList<>(Arrays.asList(items));
				PPIs.add(ppi);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return PPIs;
	}

	public List<List<String>> processClusterReuslt(String folder, String clusterFile) {
		// Set<Set<String>> processedResult = new HashSet<>();
		List<List<String>> processedResult = new ArrayList<>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(folder + clusterFile));
			String line;
			List<String> cluster;
			while ((line = br.readLine()) != null) {
				if (line.startsWith("Cluster")) continue;
				cluster = new ArrayList<>();
				String[] items = line.split("\t");
				for (int i = 0; i < items.length; i++) {
					if (this.geneidMap.containsKey(items[i])) {
						cluster.add(this.geneidMap.get(items[i]));
					} else {
						cluster.add(items[i]);
					}
				}
				processedResult.add(cluster);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return processedResult;
	}

	public Map<String, String> getGeneidMap() {
		return this.geneidMap;
	}

	private int test(List<String> proteins) {
		int count = 0;
		for (String protein : proteins) {
			if (geneidMap.containsKey(protein)) {
				count++;
			}
		}
		return count;
	}

	public List<String> getProteins() {
		List<String> proteins = new ArrayList<>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(proteinsFile));
			String line;
			while ((line = br.readLine()) != null) {
				String node = line.trim();
				if (geneidMap.containsKey(node)) {
					proteinsGeneName.add(geneidMap.get(node));
				}
				proteins.add(node);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return proteins;
	}

	public void initGeneidMap() {
		this.geneidMap = new HashMap<>();
		try {
			File excel = new File(fileName);
			if (excel.isFile() && excel.exists()) {
				String[] items = excel.getName().split("\\.");
				Workbook wb;
				if ("xls".equals(items[1])) {
					FileInputStream fis = new FileInputStream(excel);
					wb = new HSSFWorkbook(fis);
				} else if ("xlsx".equals(items[1])) {
					wb = new XSSFWorkbook(excel);
				} else {
					System.out.println("文件类型错误!");
					return;
				}
				// 开始解析
				Sheet sheet = wb.getSheetAt(0); // 读取sheet 0
				int firstRowIndex = sheet.getFirstRowNum() + 1;
				int lastRowIndex = sheet.getLastRowNum();
				// System.out.println("firstRowIndex: " + firstRowIndex);
				// System.out.println("lastRowIndex: " + lastRowIndex);

				for (int i = firstRowIndex; i <= lastRowIndex; i++) {
					Row row = sheet.getRow(i);
					if (row != null) {
						Cell geneNameCell = row.getCell(2);
						Cell geneidCell = row.getCell(3);
						if (geneNameCell != null && geneidCell != null) {
							String geneName = geneNameCell.toString();
							String geneid = geneidCell.toString();
							String[] geneids = geneid.split(";");
							String[] geneNames = geneName.split(" ");
							for (int j = 0; j < geneids.length; j++) {
								geneidMap.put(geneids[j], geneNames[0]);
							}
						}
					}
				}
			} else {
				System.out.println("找不到指定文件");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}