package cn.edu.whut.tools;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;

public class VertexBasedClustering {
	public static Logger logger = Logger.getLogger(VertexBasedClustering.class);
	private int minSize;
	private int[][] incidenceMatrix;
	private float[][] matrixL;
	private Map<Integer, String> id2VertexMap;
	private Set<Set<String>> clusterSet;
	private float minWeight;
	private float minOverlappingScore;

	public VertexBasedClustering(int[][] incidenceMatrix, float[][] matrixL, Map<Integer, String> id2VertexMap, int minSize, float minWeight, float minOverlappingScore) {
		this.incidenceMatrix = incidenceMatrix;
		this.matrixL = matrixL;
		this.id2VertexMap = id2VertexMap;
		this.minSize = minSize;
		this.minWeight = minWeight;
		this.minOverlappingScore = minOverlappingScore;
	}

	public void run() {
		Set<Set<String>> iniClusters = this.getIniClusters();
		logger.info("Found #" + iniClusters.size() + " initial clusters from " + this.incidenceMatrix.length + " vertices");
		this.clusterSet = this.merge(iniClusters);
		logger.info("Found #" + this.clusterSet.size() + " final clusters");
	}

	private Set<Set<String>> merge(Set<Set<String>> iniClusters) {
		Set<Set<String>> mergedClusters = iniClusters;

		Set<Set<String>> clustersToBeMerged;
		while((clustersToBeMerged = this.getClustersToBeMerged(mergedClusters)) != null) {
			Set<String> mergedCluster = this.mergeClusters(clustersToBeMerged);
			for (Set<String> cluster : clustersToBeMerged)
				mergedClusters.remove(cluster);
			mergedClusters.add(mergedCluster);
		}
		return mergedClusters;
	}

	private Set<String> mergeClusters(Set<Set<String>> clustersToBeMerged) {
		Set<String> cluster = new HashSet<>();
		for (Set<String> aCluster : clustersToBeMerged)
			cluster.addAll(aCluster);
		return cluster;
	}

	private Set<Set<String>> getClustersToBeMerged(Set<Set<String>> mergedClusters) {
		float maxOverlappingScore = 0.0F;
		Set<Set<String>> clustersToBeMerged = new HashSet<>();
		for (Set<String> aCluster : mergedClusters) {
			for (Set<String> anotherCluster : mergedClusters) {
				if (aCluster != anotherCluster) {
					float overlappingScore = getOverlappingScore(aCluster, anotherCluster);
					if (overlappingScore > maxOverlappingScore) {
						maxOverlappingScore = overlappingScore;
						clustersToBeMerged.clear();
						clustersToBeMerged.add(aCluster);
						clustersToBeMerged.add(anotherCluster);
					}
				}
			}
		}
		return (maxOverlappingScore >= this.minOverlappingScore) ? clustersToBeMerged : null;
	}

	private float getOverlappingScore(Set<String> aCluster, Set<String> anotherCluster) {
		int total = aCluster.size();
		int overlap = 0;

		for (String protein : anotherCluster) {
			if (aCluster.contains(protein)) {
				++overlap;
			} else {
				++total;
			}
		}

		return (float)overlap / (float)total;
	}

	private Set<Set<String>> getIniClusters() {
		Set<Set<String>> iniClusters = new HashSet<>();

		for(int i = 0; i < this.matrixL.length; ++i) {
			int index = 0;
			float maxValue = 0;
			for (int j = 0; j < this.matrixL.length; j++) {
				if (i != j) {
					if (this.matrixL[i][j] > maxValue) {
						maxValue = this.matrixL[i][j];
						index = j;
					}
				}
			}
			Set<String> aCluster = this.getClusterFromMatrix(i, index);
			if (aCluster != null) {
				iniClusters.add(aCluster);
			}
		}

		return iniClusters;
	}

	private Set<String> getClusterFromMatrix(int i, int j) {
		Set<String> aCluster = new HashSet<>();
		int[] incVectorI = this.incidenceMatrix[i];
		float[] prefVectorI = this.matrixL[i];
		int[] incVectorJ = this.incidenceMatrix[j];
		float[] prefVectorJ = this.matrixL[j];

		for(int m = 0; m < incVectorI.length; ++m) {
			if (incVectorI[m] == 1 && prefVectorI[m] >= this.minWeight) {
				aCluster.add(this.id2VertexMap.get(m));
			}
		}

		for(int m = 0; m < incVectorJ.length; ++m) {
			if (incVectorJ[m] == 1 && prefVectorJ[m] >= this.minWeight) {
				aCluster.add(this.id2VertexMap.get(m));
			}
		}

		return aCluster.size() >= this.minSize ? aCluster : null;
	}

	private Set<String> getClusterFromVertex(float[] prefVector, int[] incVector) {
		Set<String> aCluster = new HashSet<>();

		for(int i = 0; i < incVector.length; ++i) {
			if (incVector[i] == 1 && prefVector[i] >= this.minWeight) {
				aCluster.add(this.id2VertexMap.get(i));
			}
		}

		return aCluster.size() >= this.minSize ? aCluster : null;
	}

	public Set<Set<String>> getClusterSet() {
		return this.clusterSet;
	}
}
