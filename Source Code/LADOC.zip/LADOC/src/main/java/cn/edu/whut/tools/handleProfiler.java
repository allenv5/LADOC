package cn.edu.whut.tools;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.*;
public class handleProfiler {
    public static void main(String[] args) {
         Map<Integer,Double> map = readCsvFile("D:\\Users\\Vertex-Z\\Desktop\\聚类结果文本\\DIP Hsapi\\GMFTP_TF.csv");
         // System.out.println("a");
         int resE2 = 0;
         int resE5 = 0;
         int resE10 = 0;
         int resE15 = 0;

         int sum = 0;
        for (Double p : map.values()) {
            sum++;
            if(p<0.01){
                resE2++;
            }
            if(p<0.00001){
                resE5++;
            }
            if(p<0.0000000001){
                resE10++;
            }
            if(p<0.000000000000001){
                resE15++;
            }
        }

        System.out.println("共" + sum + "个cluster");

        // float valueToBeRounded = resE2 / (float)sum;
        // System.out.println((float)Math.round(valueToBeRounded * 1000.0F) / 10F);

        System.out.println("E2下的复合物数量为："+resE2+"("+Math.round(resE2/(float)sum*1000F) / 10F +"%)");
        System.out.println("E5下的复合物数量为："+resE5+"("+Math.round(resE5/(float)sum*1000F) / 10F +"%)");
        System.out.println("E10下的复合物数量为："+resE10+"("+Math.round(resE10/(float)sum*1000F) / 10F +"%)");
        System.out.println("E15下的复合物数量为："+resE15+"("+Math.round(resE15/(float)sum*1000F) / 10F +"%)");

        // System.out.println("E2下的复合物数量为："+resE2+" ("+resE2/(float)369*100+"%)");
        // System.out.println("E5下的复合物数量为："+resE5+" ("+resE5/(float)369*100+"%)");
        // System.out.println("E10下的复合物数量为："+resE10+" ("+resE10/(float)369*100+"%)");
        // System.out.println("E15下的复合物数量为："+resE15+" ("+resE15/(float)369*100+"%)");

    }
    public static Map<Integer,Double> readCsvFile(String filePath){
        Map<Integer,Double> map = new HashMap<>();
        try {
            //(文件完整路径),编码格式
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "utf-8"));//GBK
//                 reader.readLine();//显示标题行,没有则注释掉
            List<Integer> indexList = new ArrayList<>();
            String title = reader.readLine();
            String titleArray[] = title.split(",");
            int temp = 1;
            for(int i=0;i<titleArray.length;i++){
//                if(titleArray[i].substring(1,titleArray[i].length()-1).equals("adjusted_p_value__Cluster #"+temp)){
                if(titleArray[i].equals("adjusted_p_value__Cluster #"+temp)){
                    indexList.add(i);
                    map.put(temp, (double) 1);
                    temp++;
                }
            }
            String line = null;
            while((line=reader.readLine())!=null){
                String item[] = line.split(",");//CSV格式文件时候的分割符,我使用的是,号
                temp=1;
                for(int i=0;i<item.length;i++){
                    if(indexList.contains((Object)i)){
//                        if(Double.parseDouble(item[i].substring(1,item[i].length()-1))==-1){
                        if(item[i].equals("") || Double.parseDouble(item[i])==-1){
                            continue;
                        }
//                        Double min = Math.min(map.get(temp),Double.parseDouble(item[i].substring(1,item[i].length()-1)));
                        Double min = Math.min(map.get(temp),Double.parseDouble(item[i]));
                        map.put(temp,min);
                        temp++;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }
}
